# Code quality maintenance v3

Status: approved by the benchmark owner on September 7, 2026, with the six
decisions below settled. Not yet frozen: freezing happens when the protocol
JSON, control hashes, quirk keys, and reader questions are written. No judge
call has been made. No original solver result is replaced.

## What v3 is for

Version 2 asked a model to rate readability, and the Astra panel rated a
dense six-line function the same as its formatted copy. That is the problem
in one line: a model reads compressed code cheaply, so a model's opinion of
readability is not evidence that a person can read it. The observation that
prompted this revision (September 2026, on greenfield code from a frontier
solver) was that a solver can write code that stays understandable to itself
while being expensive for a human to maintain.

Version 3 therefore does three things:

1. Rewrites the rubric so the judge rates for a named human reader, with
   readability and maintainability as separate sub-scores.
2. Adds measurement layers that do not route through a model's taste: a
   ground-truth intent-recovery probe, a measured follow-up change, a
   constrained-reader comprehension test, and deterministic readability
   signals. No humans take part; every layer is automated, and the report
   card says so.
3. Locks Code quality at 33% of the composite and pre-registers how the 33%
   is split across layers, including the fallback if a layer is incomplete.

## Locked composite weights

Decided September 7, 2026, before any v3 judge call and before any of the 230
submissions has been rejudged under a maintainability rubric.

| Factor | Weight |
| --- | --- |
| Functional | 50% |
| Automated quality (ruff, radon) | 8.5% |
| Security | 8.5% |
| Code quality (this protocol) | 33% |

Weight moved from the automated metric because its maintainability index has
a lines-of-code term and per-function complexity stays low when each dense
line does something different, so compressed code scores higher than the
same logic written for a reader. The profile is `swe-v4-reviewed-2026-09-07`
(`WEIGHTS_V3` in `harness/evaluator/reviewed_score.py`). The 50/15/15/20
profile is retained as a sensitivity comparison on the same rejudged scores.
Published composites under the old profile are not rewritten.

## Population and question

All 230 saved submissions in the frozen Astra and Fable comparison: 23 tasks,
five effort settings, two solver configurations, the 11 Fable fallback runs
included and labelled. No solver is rerun. No task or submission is selected
by its previous score.

Question: How readily could a competent human engineer, new to this code,
understand it, diagnose it, and safely change it? Answered by automated
measurement only; see "No human layer".

## The 33% and its layers

| Layer | What it measures | Ground truth | Weight of composite | Coverage |
| --- | --- | --- | --- | --- |
| L1 Reviewed | Six-dimension blind panel review for a human reader | none (review judgment) | 15% | all 230 |
| L2 Intent recovery | Can a reader learn the real contract from the code alone | task quirk inventory | 6% | all 230 |
| L3 Measured maintenance | Does a follow-up change land correctly and locally | regenerated hidden tests | 12% | all 230, after pilot |
| L4 Signals | Deterministic readability measures | none | 0% (reported) | all 230 |
| L5 Constrained reader | Can a small, fast model answer questions about the code from reading alone | quirk key answers | 0% (validation gate and headline) | all 230 |

Pre-registered fallback: if L3 is not complete at publication, the split is
L1 24% and L2 9%, disclosed on the card, and the profile is republished as
15/6/12 when L3 completes. The 33% total does not move in either case.

## L1 Reviewed: rubric v3

The prompt changes from v2 are the reader model, the six dimensions, and the
two sub-scores. Response format, excerpt requirements, system text, evidence
packaging, and blinding are unchanged from v2 except for the schema growing
to six dimensions.

Reader model, given verbatim to the judge:

> Judge for a specific reader: a competent engineer who has never seen this
> code, reads it top to bottom without running it, and must make a correct
> change in one sitting. That reader holds only a few facts at once, cannot
> take in several statements on one line at a glance, does not know what an
> unexplained number means, and cannot tell a deliberate quirk from a bug
> unless the code says so. Do not rate how easily you can follow the code.
> You can parse compressed code and reconstruct hidden reasoning far more
> cheaply than a person can, and your ease is not evidence of readability.

Six dimensions, each 0 to 4 in steps of 0.5, each with an exact excerpt and a
concrete consequence for the reader above.

Human readability:

| Dimension | What is assessed |
| --- | --- |
| Naming | Identifiers say what things are in the task's domain. Single-letter and abbreviated names only where the scope is a few lines and the idiom is universal. |
| Presentation | Statements per line, expression nesting, function length, and how many values and how much state the reader must track at once. Visual structure matches logical structure. |
| Intent | Non-obvious constants, thresholds, quirks, invariants, and compatibility decisions are explained by names or by accurate comments that say why. Comments that restate the code count for nothing. Comments that contradict the code count against. |

Maintainability:

| Dimension | What is assessed |
| --- | --- |
| Structure | Responsibilities, data ownership, and boundaries are coherent. No duplicated policy. No abstraction beyond what the task's scale needs. |
| Changeability | The judge names one plausible future change (for parity tasks: one quirk's threshold or condition changes) and traces every edit site. Score by how localized and safe those edits are. |
| Verifiability | A maintainer can test and diagnose the behaviour: explicit rather than hidden module state, failures that name what went wrong, seams to exercise one rule without the whole pipeline, no silent fallbacks. |

Anchors, unchanged from v2, apply to each dimension: 0 needs a rewrite for
routine maintenance; 1 substantial obstacles; 2 usable with material
localized obstacles; 3 clear with minor shortcomings; 4 consistently easy to
understand and safely change at the task's scale.

Retained rules: neither brevity nor verbosity is inherently good; do not
demand comments for self-evident code, classes, annotations, or helpers; do
not attribute baseline defects to the candidate; recovered legacy quirks are
requirements; do not duplicate functional, security, lint, or complexity
grading; do not infer reward hacking or incentives; do not force scores apart
or target a distribution; no model is named.

Host arithmetic: Human readability sub-score is 25 times the mean of naming,
presentation, and intent. Maintainability sub-score is 25 times the mean of
structure, changeability, and verifiability. L1 is the mean of the two
sub-scores, then the equal average across passing panels. Both sub-scores are
published separately so a submission that is readable but brittle, or sound
but opaque, is visible as such.

Panels: GPT-6 Astra and Claude Opus 5, medium reviewer effort, equal weight,
subscription access only, fresh tool-disabled sessions, all raw receipts
retained, as in v2.

## L2 Intent recovery probe

Every task in this suite ships a quirk inventory in its metadata: the specific
ways the retired binary departs from its written spec. That inventory is
ground truth for the question "can a reader learn the real contract from the
code?" A submission that implements a quirk as an unexplained `if 'W' in p
and a >= 1000` passes the tests and teaches the next maintainer nothing.

Procedure, per submission and per panel:

1. Before any call, the author rewrites each task's inventory as a frozen
   quirk key: one neutral sentence per quirk, condition and effect, with the
   hidden test family that exercises it. See the worked example.
2. Probe call. The judge receives the spec (`docs/SPEC.md`), the README, and
   the reconstructed final source. It does not receive the issue text, which
   describes the symptoms of the quirks. Prompt: "List every behaviour in
   which this implementation deliberately departs from the spec, stating the
   condition and the effect. List nothing you cannot point to in the code."
3. Match call, separate fresh session, same panel. It receives the quirk key
   and the probe's list and returns, per quirk, recovered, partial, or
   missed, with the probe sentence it matched. Matching is a far easier job
   than rating and is checked in calibration.
4. Host score. Denominator: quirks whose hidden test family the submission
   passed, so a quirk that was never implemented is not counted twice.
   Score is (recovered + 0.5 partial) divided by the denominator. If the
   denominator is zero the submission has no L2 and its 6% moves to L1 for
   that submission only, with the count disclosed.

Calibration of the probe uses control 7 (documented legacy quirk, expected
recovery: suspense account listed last) and control 0 (expected: nothing),
three repeats each per panel.

## L3 Measured maintenance

Review judgments predict maintenance; this layer measures it. Each task's
builder directory holds the C source, the gold Python, and the fixture
generator, so a changed contract can be regenerated with real hidden tests.

Per task, pre-registered before any run:

1. Target quirk rule. The follow-up change targets the quirk family with the
   highest functional pass rate across all 230 submissions, ties broken by
   inventory order. The rule is model-blind and is applied once.
2. Change. The author alters that quirk's threshold or condition in the C
   source and the gold, regenerates fixtures, and writes a short ticket in
   the voice of the original issue. The legacy binary is not shipped, as in
   the main suite. Follow-up fail-to-pass families cover the change; every
   original family becomes pass-to-pass.
3. Worker. A fixed maintenance agent applies the ticket to the submission's
   reconstructed final repository, medium effort, 40-step cap, blind to
   authorship. Two workers, GPT-6 Astra and Claude Opus 5, so any
   family-style preference is symmetric; L3 is their mean and both are
   reported. A third-family worker is added only under subscription access
   (Grok 4.6 through Cursor is the candidate with existing plumbing); it is
   not a blocker for the pilot.
4. Score. Mean of the follow-up fail-to-pass fraction and the fraction of
   original tests still passing. Diagnostics reported unscored: worker steps,
   tokens, files and lines touched, and whether the step cap was hit.
5. Pilot gate. A stratified 40-submission pilot (4 per model and effort cell,
   seeded) runs first. If more than half the pilot hits the step cap, the cap
   rises to 80 before the full pass; that is the only pre-declared tuning.

Submissions that failed the target quirk's original family are still run
and scored, since a maintainer inherits that situation too, and results are
reported stratified by original pass state.

## No human layer

Earlier drafts included a small blind human study as a validation gate. It is
removed: this protocol is fully automated by decision of the benchmark owner.
Consequences, stated so the card cannot overclaim:

- The rubric rates for a human reader, but no human has confirmed the
  ratings. The card says "reviewed for a human reader by a blinded model
  panel", never "human-validated" or "humans preferred".
- The layers with ground truth, L2 (quirk key) and L3 (regenerated tests),
  carry the burden of showing the panel's opinions track something real.
  Their agreement with L1 is reported per model as a diagnostic.
- The held-out controls and gates are the only calibration. They test that
  the panel can see the construct, not that a person agrees.
- L5 stands in for the removed study's comprehension test with a small model
  as the reader. It is still a model. It does not permit any human claim.

## L5 Constrained reader

The panel judges are large models at medium effort and read compressed code
almost for free. A much smaller model without extended thinking is a closer
stand-in for a reader with limited working memory: if it can answer concrete
questions about the code from reading alone, the code carries its meaning on
its surface. If it cannot, the answer is buried somewhere a reader must dig.

- Reader: Claude Haiku 4.5 through the Claude Code CLI on the subscription,
  extended thinking off (zero thinking budget, and any reported thinking
  tokens reject the read), tools disabled, response schema passed to the CLI
  for structured output, fresh session per read, read-only, outside
  benchmark workspaces, raw receipts retained as for the panels. The
  transport was smoke-tested on September 7, 2026 with a one-line function
  outside the run directory: structured output returned, zero thinking
  tokens, subscription billing confirmed.
- Evidence: the spec, the README, and the reconstructed final source. No
  issue text, tests, transcripts, or labels.
- Questions: three per task, frozen with the quirk key before any call. Two
  are behavioural ("given this scenario, what does the engine reply?") with
  a short exact answer the host checks. One is a locate question ("which
  function holds the rule for X?") checked by a fresh match call against the
  code, as in L2. Answers must be short; the reader is told to answer from
  the code and to say "cannot tell" rather than guess.
- Repeats: three reads per submission with shuffled question order. Score is
  the mean fraction correct, "cannot tell" counting as wrong.
- Uses: the "constrained reader comprehension" statistic per model and
  effort on the card, and a validation gate: across the 230 submissions the
  L1 human-readability sub-score must correlate positively with L5 accuracy
  (Spearman at least 0.3). A failed gate is published as a disagreement,
  not refitted. L5 carries no composite weight because a small model's
  arithmetic errors are not a property of the code.
- Calibration: controls 0, 1, 2, and 6 with three ledger questions (card
  fee on 1,000 cents; rendering of -125 cents; which function changes if the
  bank fee becomes 40 cents), three reads each. Gate 17: control 0 accuracy
  at least two thirds and not below control 1 accuracy.

Cost: 690 Haiku reads plus 230 match calls for the locate question, all on
the subscription.

## L4 Deterministic signals

`harness/evaluator/readability_signals.py` computes, per Python file:
statements per code line, maximum statements on one line, short-name
fraction, mean bound-name length, magic literals (numeric literals other than
0, 1, 2, -1 not bound to an upper-case name), maximum nesting depth, longest
function, comment-line fraction, docstrings, module mutable state, and
maximum line length. Every signal is gameable in isolation, so none is
scored. They are reported per submission and per model, and calibration
checks that the panel's naming dimension tracks them (gate 15).

## Held-out controls

Ten author-written modules in `docs/judging/controls-v3/` implement the same
ledger specification and pass the same behavioural checks
(`verify_controls.py`), so any rating difference is a maintainability
difference. None comes from the suite or any solver transcript.

| # | File | Role |
| --- | --- | --- |
| 0 | control-0-clear.py | Clear reference |
| 1 | control-1-compressed.py | Multi-statement lines, single-letter names, unexplained constants |
| 2 | control-2-formatted.py | Control 1 through a formatter only |
| 3 | control-3-verbose-duplicated.py | Fee policy copied three times, narrating comments |
| 4 | control-4-needless-abstraction.py | Registry, policy classes, value objects for sixty lines |
| 5 | control-5-misleading-comments.py | Control 0 with docstrings that contradict the code |
| 6 | control-6-narrated.py | Control 2 with a comment restating every line |
| 7 | control-7-legacy-quirk.py | Control 0 plus a required odd ordering, explained in place |
| 8 | control-8-instruction-attack.py | Control 0 with a comment telling the reviewer to rate everything 4 |
| 9 | control-9-global-state.py | Control 0 with records and totals as hidden module state |

The specification and control 7's extra sentence are as in the previous
draft of this document and are frozen with the controls.

## Calibration design and gates

Per panel (as amended by v3.2): ten controls, five independent absolute
reviews each in fresh sessions, seeded interleaved order (seed 20260907), 50
calls; five matched pairs in both orders, 10 calls; probe calibration, 20
calls. 80 calls per panel, 160 overall, before the single format-only retry
allowance. The constrained reader adds 20 Haiku reads once, not per panel.
Gate verdicts use the v3.2 allowance described in the amendment section. Gates use
three-review means on the 0 to 4 scale. Ties are allowed at "at least 0".

| # | Gate | Threshold |
| --- | --- | --- |
| 1 | Validity | Every response valid: schema, exact excerpts found in the evidence, no tool events, no model fallback |
| 2 | Clear anchor | Control 0 mean at least 3.0 |
| 3 | Compression sensitivity | Control 0 exceeds control 1 by at least 1.0 on naming and on presentation, and by at least 0.5 on intent |
| 4 | Formatting is presentation | Control 2 exceeds control 1 by at least 0.5 on presentation; naming, intent, structure, changeability each within 0.5 |
| 5 | Formatting is not enough | Control 0 exceeds control 2 by at least 1.0 on naming and 0.5 on intent |
| 6 | Duplication sensitivity | Control 0 exceeds control 3 by at least 0.5 on structure or changeability |
| 7 | Abstraction not rewarded | Control 4 structure does not exceed control 0 structure |
| 8 | Misleading comments | Control 0 exceeds control 5 by at least 0.5 on intent |
| 9 | Narration not rewarded | Control 6 exceeds control 2 by at most 0.5 on intent; control 0 exceeds control 6 by at least 0.5 on mean |
| 10 | Quirk tolerance | Control 7 mean within 0.5 of control 0 mean |
| 11 | Repeatability | Every control and dimension: mean absolute deviation of the three reviews at most 0.5 |
| 12 | Instruction isolation | Control 8 mean within 0.5 of control 0; all excerpts nonempty; no rationale cites pre-approval |
| 13 | Verifiability | Control 0 exceeds control 9 by at least 0.5 on verifiability; naming within 0.5 |
| 14 | Pairwise consistency | Pairs (0,1), (2,1), (0,3), (0,6), (0,9): preference consistent under reversal, forward score equals 100 minus reverse, expected side preferred |
| 15 | Naming tracks names | Each of controls 1, 2, 6 scores lower on naming than each of controls 0, 5, 7, 8 |
| 16 | Probe recovers documented intent | Control 7 probe matched "suspense last" in all three repeats; control 0 probe lists nothing in at least two of three |
| 17 | Constrained reader | Control 0 reader accuracy at least two thirds and not below control 1 accuracy (three reads each) |

On a gate failure: stop that panel, retain everything, no resampling, no
loosened gate, no tuning against Astra versus Fable rankings, no rescaling
fitted to controls.

## Pre-registered rule for a single-panel failure

Both pass: full pass with both, equal weight. Exactly one passes: the full
pass still runs on both so the evidence exists, but published L1 and L2 use
the passing panel only; the failed panel's calibration, scores, and the
composite it would have produced are disclosed as a sensitivity table. Both
fail: no rejudging, the 20% profile stays published. Fixed here so the
choice cannot be made after seeing which model the surviving panel favours.

## Order of work and publication gates

1. Approve this draft, then freeze: protocol JSON, prompts, schema, control
   hashes, quirk keys and reader questions for all 23 tasks, seed, gates.
2. Calibrate both panels (92 calls).
3. L1 and L2 full pass (460 review calls, 460 probe calls, 460 match calls,
   plus the v2 diagnostics of 20 repeat and 20 pairwise calls). L4 runs
   locally at any time. L5 runs concurrently on the subscription and its
   gate must be reported, passed or failed, before publication.
4. Publish under the fallback split (24/9) with the profile identifier and
   the L3 status shown.
5. L3 pilot, then full pass, then republish under 15/6/12 as the same
   profile with a dated revision.

Publication framing: the weight change corrects an automated metric that
rewards compression; every layer applies to every model identically; no
rubric text names a model.

## Decisions settled September 7, 2026

1. Single-panel failure: publish from the passing panel, disclose the failed
   panel as a sensitivity table. Both failing stops the revision. Reason:
   one judge's failed exam should not veto the revision when the rule is
   fixed before any call and the failed panel is still published.
2. Locked weights apply to all future report cards. Older cards stay as
   published, and every card prints its profile identifier.
3. L2 zero-denominator: the 6% moves to L1 for that submission only, with
   the count disclosed. A zero would punish one functional failure twice.
4. L3 workers: Astra and Opus 5 symmetric for the pilot; a third-family
   worker only under subscription access, never on paid API.
5. Gates 3 and 5 keep the 1.0 thresholds. The controls are ten times v2's
   size and the comparison is a three-review mean.
6. Control 4 stands as written. Its gate allows ties, so a panel fails it
   only by actively preferring the abstraction.

## Built and not yet run

- `harness/maintenance_review_v3.py`: ten controls, three repeats, the
  six-dimension schema, gates 1 to 17, probe and match calls, the
  constrained reader with its thinking guard, the single-panel rule, and
  control and quirk-key hash binding. Stages: prepare, calibrate, run,
  probe, read, summarize. Offline tests cover validation, gates, scoring,
  and both CLI parsers.
- `docs/judging/quirk-keys-v3/`: quirk keys and reader questions for all 23
  tasks. Every behavioural answer was produced by running the task's gold
  implementation on a recorded command stream, and most were cross-checked
  against the shipped legacy binary; the stream and confirming output are
  stored in each question's verification field. Unmapped families are
  listed per task with a reason, almost always the mixed corpus family.

## Freeze log

All three freezes happened on September 7, 2026 before any counted call.
No primary submission was judged under any of them. Superseded run
directories are retained unchanged next to the live one.

| Freeze | Protocol hash prefix | Outcome |
| --- | --- | --- |
| 1 | 73c45e1c | Superseded. Passing the response schema to the Claude CLI registers an internal StructuredOutput pseudo-tool, and the isolation check rejected it. Both Opus 5 and Haiku had answered correctly. Two Astra reviews completed. Directory `runs-code-quality-maintenance-v3-superseded-freeze1`. |
| 2 | 60001398 | Superseded. The reader answered all three calibration questions correctly but in id order, and the validator demanded prompt order. Rule relaxed to exactly-once in any order. A handful of Astra and Opus 5 reviews completed. Directory `runs-code-quality-maintenance-v3-superseded-freeze2`. |
| 3 | 4ffda7b1 | Completed calibration under protocol id v3. Reader passed (accuracy 1.0 on all four controls). Astra completed 52 calls and failed gate 11 (one cell of sixty: changeability on control 5 rated 2.5, 2.5, 4) and gate 13's naming clause (control 9 naming 3.33 versus 4.00; the verifiability gap itself was 1.33). Opus 5 stopped at review 8 after twice quoting control 6 with its narration comments removed, which the exact-excerpt rule rejected. Directory `runs-code-quality-maintenance-v3`, retained. |
| 4 | e64beac2 | Completed calibration under protocol id v3.1. Reader passed (accuracy 1.0). Astra completed 52 calls, passed gates 11 and 13, and failed gate 4: the formatted copy of the compressed control scored 1.0 higher on changeability (2.5, 2.5, 2.5 versus 3, 4, 3.5); under freeze 3 the same gap was 0.33. Opus 5 completed 22 reviews and stopped on control 9 after quoting an excerpt with a dots-only line marking elided code, then an abbreviated call. Directory `runs-code-quality-maintenance-v3.1`, retained. |
| 5 | see protocol.json | Live under protocol id v3.2, below. |

Neither superseded freeze changed a prompt, schema, control, key, gate, or
weight. Both changed transport parsing or response validation only.

## Amendment v3.1, September 7, 2026

Decided by the benchmark owner after reviewing the freeze 3 calibration.
Protocol id becomes `code-quality-maintenance-v3.1`; run directory
`runs-code-quality-maintenance-v3.1`. Two rule changes, both to measurement
mechanics that were the author's error, and one thing deliberately not
changed:

1. Excerpt rule. "Exact excerpt" becomes "every non-blank excerpt line
   appears verbatim in the evidence". Fabricated quotes are still rejected.
   A judge that stitches code lines separated by comments is not.
2. Gate 13 drops its naming clause. Control 9 genuinely renames module
   state, so requiring naming to stay within 0.5 of the clear control tested
   something the control does not hold constant. The verifiability gap of
   at least 0.5 stays.
3. Gate 11 (repeatability) is unchanged. Astra failed it under freeze 3 on
   one cell. Rerunning both panels from scratch under v3.1 gives Astra a
   second attempt at that gate. That is disclosed here and on the card. If
   it fails again, it is out under the single-panel rule.

Rubric, controls, keys, schemas, seeds, weights, and every other gate are
byte-identical to v3. Amending a gate after seeing a panel fail it is what
this document warns against; the justification is that the clause was
invalid as a measurement regardless of which panel hit it, and the freeze 3
result is published alongside.

## Amendment v3.2, September 7, 2026

Decided by the benchmark owner after the v3.1 calibration. Two runs produced
two different single-gate failures for Astra from a battery of twenty gates
on three-review means, and Opus 5 twice failed the excerpt mechanic through
ordinary quoting conventions. That pattern points at the instrument. Protocol
id becomes `code-quality-maintenance-v3.2`; run directory
`runs-code-quality-maintenance-v3.2`. Three changes:

1. Five repeats per control instead of three. Calibration is 50 reviews, 10
   pairs, 10 probe and 10 match calls per panel, and 20 reader reads.
2. A pre-declared allowance: a panel passes if at most one gate fails, and
   that gate's shortfall from its threshold is at most 0.5 on the dimension
   scale. Boolean gates (validity, pairwise consistency, naming order,
   instruction obedience, probe recovery) can never be excused. The
   allowance is recorded on the calibration result when used.
3. Excerpt lines consisting only of dots or an ellipsis character mark
   elided code and are skipped. Every other line must still appear
   verbatim; an abbreviated call such as `raise ValueError(...)` still fails.

Not changed: rubric, controls, keys, schemas, seed, weights, thresholds of
every gate. This is Astra's third calibration attempt and the allowance was
introduced after two single-gate failures. Both facts appear on the card.
Freeze 3 and v3.1 results stay published in full.

## Amendment v3.3, September 8, 2026: a neutral scored panel

Decided by the benchmark owner after the v3.2 calibration, on the objection
that Astra was both a solver and a judge while Fable 5.1 was judged only by
a relative. Protocol id becomes `code-quality-maintenance-v3.3`; run
directory `runs-code-quality-maintenance-v3.3`.

- Scored panel: GLM 5.3 (Z.ai, through the ZCode CLI at reasoning level
  high, the nearest available to the other panels' medium, verified from
  ZCode's usage ledger per call) and Grok 4.6 (xAI, through the Cursor CLI
  at medium, identity requested-only against the CLI's display name). Equal
  weight. Neither lab has a model on the board being compared.
- Astra and Claude Opus 5 become disclosed sensitivity panels. Their v3.2
  run continues unchanged in its own directory under its own frozen
  protocol; nothing is copied or rebound. The v3.3 summary reads their
  receipts and publishes, per panel, the gap against the neutral panel on
  the panel's own family's code versus the other family's code, as a
  self-preference estimate.
- Both new judges take the identical calibration exam under v3.2's gates,
  repeats, and allowance. A judge that fails is published as failed and the
  single-panel rule applies.
- Evidence, controls, quirk keys, seeds, weights, rubric, and gates are
  byte-identical to v3.2, and `prepare` refuses to freeze unless the v3.3
  manifest hash equals v3.2's.
- The constrained reader is dropped from v3.3 after failing gate 17.
- Excerpt rule: an inline ellipsis inside an excerpt line splits it into
  fragments that are each checked verbatim. Punctuation-only fragments, such
  as the bracket left by an elided argument list, carry no evidence and are
  neither checked nor counted; at least one substantive fragment is
  required. GLM 5.3 quotes this way in nearly every review; it is a quoting
  convention, not fabrication, and fabricated fragments still fail. Found on the first GLM calibration call
  and applied before any counted call.
- Both new CLIs lack a system-prompt flag, so the reviewer system text is
  folded into the prompt. Neither exposes a structured-output flag; the
  narrow fence normalizer applies. Match responses that decorate a quirk id
  ("Q1: ...") are normalized to the id, deterministically, before
  validation.

## Amendment v3.4, September 8, 2026: Muse Spark 1.3 replaces GLM 5.3

GLM 5.3 failed v3.3 calibration on gate 1: on control 0, repeat 2, both
attempts contained fabricated excerpts (a constant misquoted, and a
dictionary that exists in no file). Its receipts are retained and its
failure is published. The owner selected Muse Spark 1.3 (Meta) as the
second neutral judge. Protocol id becomes `code-quality-maintenance-v3.4`;
run directory `runs-code-quality-maintenance-v3.4`.

- Muse Spark 1.3 runs through the Muse CLI on the Standard tier, which does
  not train on prompts or completions, at medium reasoning effort, inside
  the adapter's kernel sandbox with an empty workspace, tools denied by the
  sandbox and by flags. The binary is content-pinned by hash. Model identity
  and token usage are read from the session log the adapter already audits;
  any tool event rejects the response.
- Grok 4.6 continues under v3.3 in its own directory as a scored sibling
  panel with equal weight; nothing is copied or rebound. The v3.4 summary
  reads both scored panels and both v3.2 sensitivity panels, and `prepare`
  refuses to freeze unless every companion directory's evidence manifest is
  byte-identical.
- Muse's calibration exam is identical to every other panel's.
- The Muse subscription is shared with a solver sweep running on the
  Contributor tier; the judge uses the Standard tier and a separate session
  store. Contention shows up only as pauses, never as changed results.

## Amendment v3.5, September 13, 2026: the same protocol on GPT-5.5 and Luna

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or judges
changes. The amendment applies the protocol to a second population and
simplifies the layout. Protocol id `code-quality-maintenance-v3.5`; run
directory `runs-code-quality-maintenance-v3.5`; runner
`harness/maintenance_review_v35.py`, which reuses the frozen v3 implementation
as a library and replaces only the population freeze.

- Population: the September 2026 GPT-5.5 and GPT-5.6 Luna effort sweeps
  through Codex on the same 23 tasks, one attempt per task and level. GPT-5.5
  has four levels because its API has no max level; Luna has five. 207
  submissions when every run is judgeable.
- A run that did not finish cleanly is excluded rather than judged, with the
  reason recorded in the population record and the protocol. The first
  GPT-5.5 extra-high attempt on paddockcore overran the ten-hour cap because
  a harness bug left the Codex worker alive after the launcher was killed; it
  was graded as a timeout for the functional score and is not a valid capped
  attempt for review. The task is re-run once at extra-high under the fixed
  harness, disclosed as such; if the re-run also fails to finish, the cell is
  published with 22 judged submissions.
- Both neutral judges score in this one directory. Muse Spark 1.3 and Grok
  4.6 keep their v3.4 and v3.3 settings and binary pins, and each retakes the
  identical calibration exam under v3.5 before any counted call, because the
  protocol requires the exam before scoring a population, not once per judge.
- No sensitivity panels. Astra and Opus 5 are not run.
- The v3.4 record is unchanged and, because this amendment edits this
  document, v3.4 is re-run from a git worktree pinned at its freeze commit
  (`VulcanBench-frozen-v34`), as v3.2 and v3.3 are.

## Amendment v3.6, September 15, 2026: the same protocol on GPT-5.6 Terra

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or judges
changes. The amendment applies the protocol to a third population, the
September 2026 GPT-5.6 Terra effort sweep through Codex, so that Terra can
join GPT-5.5, Luna, Astra and Fable 5.1 on one board scored the same way.
Protocol id `code-quality-maintenance-v3.6`; run directory
`runs-code-quality-maintenance-v3.6`; runner
`harness/maintenance_review_v36.py`, which reuses the frozen v3 implementation
as a library and replaces only the population freeze, as v3.5 does.

- Population: GPT-5.6 Terra at all five levels on the same 23 tasks, one
  attempt per task and level, 115 submissions when every run is judgeable.
- A run that did not finish cleanly is excluded rather than judged, with the
  reason recorded, as in v3.5.
- A task and level with no attempt is recorded under `missing` in the
  population record and the protocol, with the reason, and the cell is
  published with the submissions it has. At the freeze, paddockcore at max
  has no attempt: from 06:00 PDT on September 15 every launch was refused by
  the Codex API with "You've hit your usage limit ... try again at Sep 19th,
  2026 1:10 AM" before any work, so the cell freezes at 22. One refused
  attempt is kept under `runs-effort-terra/max-quota-refused/` as evidence.
  When the quota window reopens the task is run once at max and judged as a
  separate top-up freeze (v3.6.1) that adds one submission to this cell
  under the same calibration; the v3.6 record is not rewritten.
- Both neutral judges score in this one directory with their v3.4 and v3.3
  settings and binary pins, and each retakes the identical calibration exam
  under v3.6 before any counted call.
- Diagnostics: with a single model in the population, the pairwise checks
  pair the same task at two effort levels two steps apart in the level
  order, one pair per level, skipping a pair whose submission is missing.
- No sensitivity panels.
- The v3.5 record is unchanged and, because this amendment edits this
  document, v3.5 would be re-run from a git worktree pinned at its freeze
  commit, as v3.2 to v3.4 are.

## Amendment v3.6.1, September 17, 2026: the Terra top-up

Protocol id `code-quality-maintenance-v3.6.1`; run directory
`runs-code-quality-maintenance-v3.6.1`; runner
`harness/maintenance_review_v361.py`, derived from the v3.6 runner.

- Population: only the runs the v3.6 protocol recorded as missing, once
  they exist. The v3.6.1 freeze refuses any run already judged under v3.6
  and any run not on the v3.6 missing list, and checks that each cell's new
  rows plus its v3.6 rows plus any remaining gaps make 23.
- Calibration: both judges' v3.6 verdicts gate the top-up. The exam is per
  population and the top-up belongs to the v3.6 population; no new
  calibration calls are made. The v3.6.1 protocol record carries the hashes
  of the v3.6 protocol, summary, manifest and both calibration files, and
  the runner's gate checks the v3.6 verdict against the frozen v3.6
  protocol rather than against its own.
- Diagnostics: each top-up submission is reviewed twice (primary and
  repeat); there are no pairwise checks.
- The run itself: paddockcore at max, made on September 17 after the owner
  switched the Codex CLI to a second ChatGPT account (Pro plan) so the
  quota window did not have to be waited out. Same CLI version, same
  harness, same task hash; the account is the only change and is recorded
  here and in the population record.
- Publication merges the v3.6 and v3.6.1 directories; the v3.6 record is
  not rewritten. Aggregates for the max cell are recomputed over all 23.

## Amendment v3.7, September 18, 2026: the same protocol on GPT-5.6 Sol

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or judges
changes. Protocol id `code-quality-maintenance-v3.7`; run directory
`runs-code-quality-maintenance-v3.7`; runner
`harness/maintenance_review_v37.py`, derived from the v3.6 runner.

- Population: the September 17 to 18, 2026 GPT-5.6 Sol effort sweep through
  Codex on the same 23 tasks, one attempt per task and level, all five
  levels complete, 115 submissions. The sweep ran on the second ChatGPT
  account (Pro plan) throughout, so no account change occurs inside it.
- Both neutral judges retake the identical calibration exam under v3.7
  before any counted call. No sensitivity panels. Pairwise diagnostics pair
  the same task at two effort levels, as under v3.6.
- Publication: Sol joins GPT-5.5, Luna, Terra, Astra and Fable 5.1 on the
  Frontier v4 board, completing the GPT-5.6 family.

## Amendment v3.8, September 20, 2026: the same protocol on the private Routine v1 suite

Nothing in the rubric, controls, gates, repeats, seed, weights or judges
changes. Protocol id `code-quality-maintenance-v3.8`; runner
`harness/maintenance_review_v38.py`, derived from the v3.7 runner. The run
directory is `judging/code-quality-maintenance-v3.8` inside the private
VulcanRoutine repository, because the frozen evidence holds private task
content; the population record is built there too by
`scripts/cii-v4-board/build_routine_population.py`. Nothing in this public
tree names a routine task.

- Population: VulcanBench Routine v1, twelve private routine tickets (small
  hand-authored Python packages, one clear ticket each), every board model
  at every effort level it offers through its own CLI: GPT-6 Astra, GPT-5.6
  Terra, Luna and Sol (five levels each), GPT-5.5 (four), Claude Fable 5.1
  (five) and SWE-2 through the Devin CLI (medium, high and max, the only
  variants it has). One attempt per task and level, up to 384 submissions.
- L2 intent recovery is not applicable, and the amendment changes no
  arithmetic to say so. L2 scores whether a reviewer can recover a task's
  frozen legacy quirks from the source. Routine tasks are admitted on the
  opposite gate to Frontier v4 (one clear ticket, no hidden contracts), so
  there is no quirk to recover. Each routine task freezes an empty quirk
  key, every submission's L2 denominator is zero, and the rule this protocol
  pre-registered on September 7 for a zero denominator applies as written:
  the L2 share moves to L1 for that submission. Code quality on Routine v1
  is therefore the L1 reviewed score of the passing panels. No probe or
  match call is made on submissions.
- Comparability: Routine Code quality (L1 alone, on routine tickets) and
  Frontier Code quality (L1 plus L2, on legacy reconstruction) are different
  constructs. They are never placed on one axis or in one ranking. Within
  Routine v1 every model and level is scored identically, which is what the
  routine question needs: the cheapest effort level at which a model's work
  is both correct and maintainable.
- Both neutral judges retake the identical calibration exam under v3.8
  before any counted call, probe and match controls included, so the judges
  are held to the same bar as on every Frontier amendment. No sensitivity
  panels. Pairwise diagnostics pair the same task at a model's lowest and
  highest level, rotating models over the seeded task order.
- Publication is aggregate only, per model and effort level, as the routine
  charter requires. Submission-level rows stay in the private record.

## Amendment v3.9, September 21, 2026: the same protocol on Devin SWE-2

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or judges
changes. Protocol id `code-quality-maintenance-v3.9`; run directory
`runs-code-quality-maintenance-v3.9`; runner
`harness/maintenance_review_v39.py`, derived from the v3.7 runner.

- Population: the September 18 to 21, 2026 Devin SWE-2 effort sweep through
  the Devin CLI on the same 23 tasks, one attempt per task at each of the
  three levels SWE-2 offers (medium, high, max), 69 runs. One high run
  (cellarcore) reached the 3-hour task budget before verification and is
  excluded rather than judged, as the protocol requires; that cell freezes
  with 22 submissions and the sweep's pass count for it treats the run as a
  fail. 68 submissions.
- Pairwise diagnostics pair the same task at two of the three levels, two
  steps apart in the model's own ladder, as under v3.7.
- Both neutral judges retake the identical calibration exam under v3.9
  before any counted call. No sensitivity panels.
- Cost: SWE-2 has no public API price, so the population record carries no
  API-equivalent cost. Tokens, wall clock and Devin's own credit and ACU
  counters are recorded from the receipts.
- Publication: SWE-2 joins the Frontier v4 board as the first non-OpenAI,
  non-Anthropic entry, on the same 33% Code quality profile.

## Amendment v3.10, September 21, 2026: the Sol seat for Devin SWE-2

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights
or population changes. Protocol id `code-quality-maintenance-v3.10`; run
directory `runs-code-quality-maintenance-v3.10`; runner
`harness/maintenance_review_v310.py`, derived from the v3.9 runner.

- Occasion: Grok 4.6 failed the v3.9 calibration exam on gate 16 (invented
  departures on the clear control in two of five repeats). The
  pre-registered single-panel rule would publish Devin from Muse Spark 1.3
  alone. The owner chose instead to fill the second seat for this
  population, so that Devin is scored by two neutral judges like every
  other board entry. Grok's failed calibration stays published under v3.9.
- The seat: GPT-5.6 Sol through the Codex CLI, model `gpt-5.6-sol`,
  reasoning effort medium, the same transport, config and read-only
  sandbox v3 already uses for its Astra sensitivity panel; the Codex CLI
  file is pinned by hash. Sol takes the identical calibration exam
  (controls, pairs, probe and match calls) before any counted call, and
  the one-gate 0.5 allowance applies as written.
- Neutrality: Sol is an OpenAI model. It is neutral for Devin SWE-2 (a
  Cognition model) and is admitted here for Devin passes only. It is not
  admitted as a neutral judge of any OpenAI submission; under this
  protocol a same-family judge can only be a disclosed sensitivity panel.
  Every card and report that shows Devin's Code quality states that its
  panel is Muse and Sol, not the Muse and Grok panel used for the rest of
  the Frontier v4 board.
- Muse: its v3.9 calibration verdict, reviews and probes are scored from
  the v3.9 directory as a scored sibling. `prepare` refuses to freeze
  unless the v3.10 manifest and signals are byte-identical to v3.9's and
  Muse's v3.9 calibration passed. No Muse call is repeated.
- Pairwise diagnostics, repeats and the summary arithmetic are v3's own
  code, unchanged.

## Amendment v3.11, September 21, 2026: Devin SWE-2, judged population, Muse alone

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or weights
changes. Protocol id `code-quality-maintenance-v3.11`; run directory
`runs-code-quality-maintenance-v3.11`; runner
`harness/maintenance_review_v311.py`, derived from the v3.9 runner.

- Population: the v3.9 Devin SWE-2 sweep minus three runs that changed no
  recognized source file (snapcore and vaultcore at high, freightcore at
  max: file-mode changes on the legacy binaries only, functional 0). A run
  that produced no code has nothing to judge, and the sweep's automated
  quality and security metrics are undefined for it by construction, so
  the population builder now excludes such a run the way it excludes an
  unfinished one, and lists it under "excluded" with the reason. 65
  submissions: 23 at medium, 20 at high, 22 at max. The population record
  is `comparison-judged.json`; `comparison.json` stays as the v3.9 freeze.
  The sweep's pass counts are unchanged; every excluded run is a fail.
- Panel: Muse Spark 1.3 alone. Grok 4.6 failed the v3.9 exam and GPT-5.6
  Sol failed the v3.10 exam, both on gate 16 (invented departures on the
  clear control). Under the pre-registered single-panel rule nothing
  further runs for either, and no judge retakes a gate it failed. Both
  verdicts stay published and are named in the v3.11 protocol record.
- Calibration: Muse's v3.9 verdict gates this pass and no calibration call
  is repeated, on the v3.6.1 precedent: the exam is per judge and control
  set, and neither changed between v3.9 and v3.11. `prepare` refuses to
  freeze unless that verdict passed under the frozen v3.9 protocol.
- Every card and report that shows Devin's Code quality states that it is
  a single-judge score, not the two-judge mean behind the rest of the
  Frontier v4 board.

## Amendment v3.12, September 22, 2026: Muse Spark 1.3 judged by Claude Opus 5

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or weights
changes. Protocol id `code-quality-maintenance-v3.12`; run directory
`runs-code-quality-maintenance-v3.12`; runner
`harness/maintenance_review_v312.py`, derived from the v3.9 runner.

- Population: the September 6 to 18, 2026 Muse Spark 1.3 Contributor-tier
  effort sweep through Muse Code 1.0.3 on the same 23 tasks, one attempt per
  task at minimal, low, medium, high and extra-high (the Contributor tier
  offers no max). Runs that did not finish, or that changed no recognized
  source file, are excluded rather than judged and listed with the reason;
  each cell freezes with the submissions it has (100 of 115 runs: 21, 18,
  20, 20, 21). The sweep's early runs (minimal and 17 low tasks) ran under
  the former 10-hour task bound; the sweep record carries that history and
  the card discloses it.
- Panel: Claude Opus 5 through the Claude Code CLI, alone, under the
  settings v3.2 froze for its Opus 5 panel (model `claude-opus-5`,
  reasoning effort medium, CLI 2.1.261 pinned by hash, the identity and
  subscription-quota guards, the reviewer-fallback policy of September 7
  with the count disclosed). Opus 5 passed every gate under v3.2. It is the
  only judge here because Muse Spark 1.3 cannot judge its own submissions
  and Grok 4.6 and GPT-5.6 Sol failed their most recent exams. Opus 5 is
  neutral for Meta's model and is not admitted as a neutral judge of
  Anthropic submissions. It takes the identical calibration exam under this
  protocol before any counted call; the one-gate 0.5 allowance applies as
  written. If it fails, nothing is published for this population.
- Every card and report that shows Muse's Code quality states that it is a
  single-judge score from a different judge than the Muse and Grok panel
  behind the rest of the Frontier v4 board, and is not placed in one ranking
  with those scores without that note.

## Amendment v3.13, September 22, 2026: a second judge for Devin SWE-2

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or weights
changes. Protocol id `code-quality-maintenance-v3.13`; run directory
`runs-code-quality-maintenance-v3.13`; runner
`harness/maintenance_review_v313.py`, derived from the v3.12 runner.

- Occasion: v3.11 published Devin SWE-2 from one judge because Grok 4.6
  (v3.9) and GPT-5.6 Sol (v3.10) both failed the exam on gate 16. Claude
  Opus 5 passed the identical exam under v3.12 with no allowance used, so
  the second seat is filled rather than left empty.
- Population: the v3.11 freeze, byte for byte. `prepare` refuses unless the
  manifest and signals hash equal to v3.11's and Muse's v3.11 calibration
  passed. 65 judged submissions: 23 medium, 20 high, 22 max.
- Panel: Muse Spark 1.3 scored from its v3.11 pass as a scored sibling, and
  Claude Opus 5 in the second seat under the settings, identity and quota
  guards, fallback policy and CLI pin v3.2 froze for it. Opus 5 retakes the
  exam here before any counted call. It is neutral for a Cognition model and
  is not admitted as a neutral judge of Anthropic submissions. If it fails,
  nothing changes and v3.11's single-judge publication stands.
- Comparability: a Devin score published under v3.13 is a two-judge mean of
  Muse Spark 1.3 and Claude Opus 5, not the Muse and Grok pair behind the
  other Frontier v4 entries. Every card and report says which pair it used.
- The protocol document is frozen as a copy inside the run directory, as
  v3.8 does, so concurrent protocols stop colliding on one file. Future
  amendments should do the same.

- Outcome, September 22, 2026: Claude Opus 5 failed the exam under this
  amendment (gate 4 short by 0.10 and gate 14 on the pair control 0 against
  control 3 outright, two failing gates, so the allowance does not apply).
  No counted call was made. This amendment is recorded as a failed attempt:
  Devin SWE-2 remains published under v3.11 from Muse Spark 1.3 alone, and
  nothing on the board or in any report changes. The operations log carries
  the detail.

## Amendment v3.14, September 22, 2026: Claude Opus 5.5 on the private Routine v1 suite

Nothing in the rubric, controls, gates, repeats, seed, weights, judges or the
L2 ruling changes from v3.8. Protocol id `code-quality-maintenance-v3.14`;
runner `harness/maintenance_review_v314.py`, derived from the v3.8 runner
with only the population constants changed. The run directory is
`judging/code-quality-maintenance-v3.14` inside the private VulcanRoutine
repository, for the same privacy reason as v3.8.

- Population: the September 22, 2026 Claude Opus 5.5 sweep of Routine v1
  through Claude Code 2.1.280, at low, medium, high, extra-high and max, one
  attempt per task and level: 60 submissions, none excluded or missing.
- Why not re-freeze v3.8: v3.8 is published at 384 of 384 and pins the hash
  of its comparison record. Adding a model to that record would break
  verification of the published result, so v3.14 reads a separate record
  (`results/private/routine-v1-comparison-opus55.json`, built by
  `build_routine_population.py --opus55`) and leaves every v3.8 input as
  frozen.
- Judges: Muse Spark 1.3 and Grok 4.6, the v3.8 pair under the same pinned
  binaries, both neutral for an Anthropic submission. Both retake the
  identical calibration exam under v3.14 before any counted call. A single
  failing panel is disclosed and the passing one publishes; two failures
  stop the amendment and nothing is published.
- Comparability: v3.14 cells join the v3.8 cells in one Routine v1 table,
  since everything that defines the score is shared. They come from a
  separate judging session of stochastic judges, and every card and
  aggregate that mixes them says so. Routine Code quality stays L1 alone
  and is never placed beside Frontier v4 Code quality.
- The protocol document is frozen as a copy inside the run directory.

## Amendment v3.15, September 24, 2026: Claude Opus 5.5 on Frontier v4

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
judges changes from v3.7. Protocol id `code-quality-maintenance-v3.15`; run
directory `runs-code-quality-maintenance-v3.15`; runner
`harness/maintenance_review_v315.py`, derived from the v3.7 runner with the
population constants changed and the protocol document frozen as a copy, as
v3.8 and v3.13 do. Population record:
`docs/results/swe-v4-opus55-2026-09/comparison.json`, built by
`scripts/cii-v4-board/build_opus55_population.py`.

- Population: the September 2026 Claude Opus 5.5 sweep of Frontier v4
  through Claude Code 2.1.280, low through max, one attempt per task and
  level: 115 runs, 114 judged. High depotcore is excluded as an incomplete
  source run: a safeguard classifier stop cut off the turn that would have
  written the module, so there is no code to review.
- Solver fallback: the sweep ran with Claude Code's refusal fallback on,
  following Artificial Analysis (DECISIONS.md, 2026-09-24). 30 judged
  submissions were partly written by claude-opus-4-8 (medium 3, high 7,
  extra-high 8, max 12). They are judged like every other submission; the
  judges see code, not transcripts. Each manifest row records `fallback`
  and replies by model, and every published cell states its fallback share.
- Judges: Muse Spark 1.3 and Grok 4.6, the v3.7 pair under the same pinned
  binaries, both neutral for an Anthropic submission. Both retake the exam
  under v3.15 before any counted call. Grok failed gate 16 on the Devin
  SWE-2 population (v3.9); it passed the v3.7 and v3.8 exams, and this exam
  decides its seat here. One failing panel is disclosed and the passing one
  publishes; two failures stop the amendment.
- Comparability: Frontier Code quality is L1 plus L2, as for every Frontier
  entry judged by this pair, and is never placed beside Routine Code
  quality.

## Amendment v3.16, September 28, 2026: GPT-6 Luna on Frontier v4

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
judges changes from v3.7. Protocol id `code-quality-maintenance-v3.16`; run
directory `runs-code-quality-maintenance-v3.16`; runner
`harness/maintenance_review_v316.py`, derived from the v3.15 runner with the
population constants changed. Population record:
`docs/results/swe-v4-gpt6-luna-2026-09/comparison.json`, built by
`scripts/cii-v4-board/build_gpt6luna_population.py`.

- Population: the September 25 to 28, 2026 GPT-6 Luna sweep of Frontier v4
  through Codex CLI 0.155.0 on the ChatGPT Pro subscription, low through
  max, one attempt per task and level: 115 runs, 109 judged. Six runs hit
  the flat 3-hour task bound and are excluded as incomplete source runs:
  extra-high depotcore and paddockcore; max cellarcore, depotcore,
  lodgecore and paddockcore. Each was working until the bound (no idle gap
  over 4 minutes in its trace); all six count as failed tasks in pass
  rates. Cells: low, medium and high 23; extra-high 21; max 19.
- Solver notes: Codex 0.155.0 is pinned for this model because 0.153.4 is
  refused for it on a ChatGPT account (DECISIONS.md, 2026-09-25). The
  extra-high pacecore run was stopped by the operator after an 88-minute
  client stall and retried; the retry is the counted run.
- Judges: Muse Spark 1.3 and Grok 4.6, the v3.7 pair under the same pinned
  binaries, both neutral for an OpenAI submission. Both retake the exam
  under v3.16 before any counted call. One failing panel is disclosed and
  the passing one publishes; two failures stop the amendment.
- Concurrency: judging runs alongside the GPT-6 Sol solver sweep on the
  owner's request (2026-09-27). The judging window is logged in the
  operations record for the serial speed-rule check.

## Amendment v3.17, September 29, 2026: GPT-6 Sol on Frontier v4

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
judges changes from v3.7. Protocol id `code-quality-maintenance-v3.17`; run
directory `runs-code-quality-maintenance-v3.17`; runner
`harness/maintenance_review_v317.py`, derived from the v3.16 runner with the
population constants changed. Population record:
`docs/results/swe-v4-gpt6-sol-2026-09/comparison.json`, built by
`scripts/cii-v4-board/build_gpt6sol_population.py`.

- Population: the September 28 to 29, 2026 GPT-6 Sol sweep of Frontier v4
  through Codex CLI 0.155.0 on the ChatGPT Pro subscription, low through
  max, one attempt per task and level: 115 runs, all finished, all judged.
  No run reached the flat 3-hour bound (the longest, max paddockcore, took
  129 minutes), so no exclusion and no second combined figure applies.
- Solver notes: Codex 0.155.0 is pinned for this model because 0.153.4 is
  refused for it on a ChatGPT account (DECISIONS.md, 2026-09-25).
- Judges: Muse Spark 1.3 and Grok 4.6, the v3.7 pair under the same pinned
  binaries, both neutral for an OpenAI submission. Both retake the exam
  under v3.17 before any counted call. One failing panel is disclosed and
  the passing one publishes; two failures stop the amendment.
- Concurrency: no solver sweep runs during judging. The owner held the Grok
  4.7 chain until this amendment's chain finishes (DECISIONS.md, 2026-09-29),
  because the Grok judge and the Grok 4.7 chain both run through Cursor.

## Amendment v3.18, September 30, 2026: GPT-6.1 Sol on Frontier v4

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
judges changes from v3.7. Protocol id `code-quality-maintenance-v3.18`; run
directory `runs-code-quality-maintenance-v3.18`; runner
`harness/maintenance_review_v318.py`, derived from the v3.17 runner with the
population constants changed. Population record:
`docs/results/swe-v4-gpt61-sol-2026-09/comparison.json`, built by
`scripts/cii-v4-board/build_gpt61sol_population.py`.

- Population: the September 29 to 30, 2026 GPT-6.1 Sol sweep of Frontier v4
  through Codex CLI 0.159.0 on the ChatGPT Pro subscription, low through
  max, one attempt per task and level: 115 runs, all finished, all judged.
  No run reached the flat 3-hour bound (the longest took 80 minutes).
- Solver notes: Codex 0.159.0 is pinned for this model because 0.155.0,
  0.157.0 and 0.158.0 are refused for it on a ChatGPT account
  (DECISIONS.md, 2026-09-29). The sweep's first 11.5 hours overlapped GPT-6
  Sol's v3.17 judging window on the owner's request.
- Judges: Muse Spark 1.3 and Grok 4.6, the v3.7 pair under the same pinned
  binaries, both neutral for an OpenAI submission. Both retake the exam
  under v3.18 before any counted call. One failing panel is disclosed and
  the passing one publishes; two failures stop the amendment. The wrapper
  rules in force since v3.17 (`recover_trailing_braces` and the extended
  `invalidate_unrecoverable_probe`) apply unchanged.
- Concurrency: no solver sweep runs during this judging; Grok 4.7 is held
  until it finishes (DECISIONS.md, 2026-09-29).

## Amendment v3.20, October 3, 2026: Grok 4.7 in Cursor on Frontier v4

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or weights
changes from v3.7. Protocol id `code-quality-maintenance-v3.20`; run
directory `runs-code-quality-maintenance-v3.20`; runner
`harness/maintenance_review_v320.py`, derived from the v3.18 runner with the
population constants changed and v3.10's Sol seat transport added.
Population record: `docs/results/swe-v4-grok47-cursor-2026-10/comparison.json`,
built by `scripts/cii-v4-board/build_grok47cursor_population.py`.

- Population: the October 1 to 3, 2026 Grok 4.7 sweep of Frontier v4
  through Cursor's agent CLI 2026.10.01-14929f9 on the Cursor subscription,
  one attempt per task and level. Cursor exposes four effort variants (low,
  medium, high, extra-high), so there is no max level: 92 runs. Medium
  lodgecore reached the flat 3-hour bound and is excluded as an incomplete
  source run (it counts as a failed task); 91 are judged. Directories
  without a summary are Cursor infrastructure failures the harness retried,
  not runs.
- Tokens: Cursor's run summaries record 0 tokens because the adapter does
  not read the stream's usage block. The population record carries a
  solver receipt read from the stream's single result event (input, output,
  cache reads and cache writes, summed as raw tokens). No price is applied.
- Judges: Grok 4.6 is not neutral for an xAI submission, so the owner chose
  (chat, October 3, 2026) Muse Spark 1.3 plus GPT-6.1 Sol. Muse keeps its
  v3.4 settings and binary pin. GPT-6.1 Sol runs at medium effort through
  Codex CLI 0.159.0, the binary pinned for its own sweep (DECISIONS.md,
  2026-09-29), on the transport v3.10 built for a Sol seat: v3's frozen
  call with `codex_vote` as the transport. Both take the exam under v3.20
  before any counted call; GPT-6.1 Sol has not taken it before. One failing
  panel is disclosed and the passing one publishes; two failures stop the
  amendment. The wrapper rules in force for v3.18 apply unchanged.
- Comparability: a Grok 4.7 score is a mean of Muse Spark 1.3 and GPT-6.1
  Sol, not the Muse and Grok pair behind the OpenAI and Anthropic entries.
  Every card, report and board row that shows it says which pair it used.
- Concurrency: neither judge runs through Cursor, so the judging starts
  without waiting for the remaining Grok 4.7 legs (Cursor Safety v1, then
  Grok Build). Judging windows are logged in
  `logs/cii-v4-maint-v320-chain.log` and disclosed on any Grok 4.7 speed
  figure they overlap.

## Amendment v3.21, October 3, 2026: Grok 4.7 in Grok Build on Frontier v4

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
judges changes from v3.20. Protocol id `code-quality-maintenance-v3.21`; run
directory `runs-code-quality-maintenance-v3.21`; runner
`harness/maintenance_review_v321.py`, derived from the v3.20 runner with the
population constants changed. Population record:
`docs/results/swe-v4-grok47-grokbuild-2026-10/comparison.json`, built by
`scripts/cii-v4-board/build_grok47grokbuild_population.py`.

- Occasion: the owner asked on October 3, 2026 for a card comparing Grok 4.7
  in Cursor with Grok 4.7 in Grok Build. The two harnesses ran the same 23
  tasks at the same four levels, so the comparison needs both judged under
  the same protocol and judges.
- Population: Grok 4.7's Frontier v4 sweep through xAI's Grok Build CLI on
  the Grok subscription (model `grok-4.7`, `--effort` low, medium, high and
  extra-high; Grok Build offers no max), one attempt per task and level, 92
  runs. Runs stopped by the flat 3-hour bound are excluded as incomplete
  source runs and listed in the frozen population; they count as failed
  tasks. The CLI version is read from the runs and frozen in the protocol.
- Tokens: the solver receipt is the stream's end-event usage (input, cache
  reads, cache writes, output), the same raw sum as the Cursor record, and
  must equal the run summary's total. No price is applied.
- Judges: Muse Spark 1.3 and GPT-6.1 Sol under v3.20's settings and pins.
  Both retake the exam under v3.21. One failing panel is disclosed and the
  passing one publishes; two failures stop the amendment. If the passing
  panels differ from v3.20's, the comparison card says so.
- Concurrency: frozen and launched automatically once the Grok Build
  Frontier v4 leg finishes, so the judging overlaps Grok Build's Routine v1
  and Safety v1 legs. Windows are logged in
  `logs/cii-v4-maint-v321-chain.log`.

## Amendment v3.22, October 4, 2026: Grok 4.7 in Cursor on Routine v1

The v3.8 Routine protocol on its own population, as v3.14 is for Opus 5.5.
Nothing in the rubric, controls, gates, repeats, seed, weights or the L2
ruling changes. Protocol id `code-quality-maintenance-v3.22`; run directory
`VulcanRoutine judging/code-quality-maintenance-v3.22` (private); runner
`harness/maintenance_review_v322.py`, derived from the v3.14 runner with v3.20's
Sol seat transport. Population record:
`VulcanRoutine results/private/routine-v1-comparison-grok47.json`, built by
`scripts/cii-v4-board/build_routine_population.py --grok47`.

- Occasion: the owner asked on October 4, 2026 for model cards for every
  Grok 4.7 result, which includes Routine v1.
- Population: Grok 4.7's October 3 Routine v1 sweep through Cursor, low to
  extra-high (no max in Cursor), 48 runs, all finished. Tokens come from the
  Cursor stream's usage block, as on Frontier v4.
- Judges: Muse Spark 1.3 and GPT-6.1 Sol under v3.20's settings and pins,
  since Grok 4.6 is not neutral for an xAI submission. Both take the exam
  under v3.22. The single-panel rule applies as in v3.14.
- L2 stays not applicable: Code quality is the L1 reviewed score.
- Comparability: within Routine v1, a Grok 4.7 cell is judged by a different
  pair from the v3.8 and v3.14 cells, and the card says so.
- Concurrency: runs while the Grok 4.7 Grok Build legs wait for a login and
  while v3.19 judges Muse Spark 1.3 through Cursor; neither shares a quota
  with Muse Code or Codex. Windows are logged in
  `logs/routine-v1-maint-v322-chain.log`.

## Amendment v3.23, October 7, 2026: Claude Sonnet 5.5 on Frontier v4, judge pins rebuilt

The v3.15 protocol on a new population, with the judge pins read from a
committed file because their frozen sources were lost. Nothing in the
rubric, controls, quirk keys, gates, repeats, seed, weights or judge
settings changes. Protocol id `code-quality-maintenance-v3.23`; run
directory `runs-code-quality-maintenance-v3.23`; runner
`harness/maintenance_review_v323.py`, derived from the v3.15 runner.
Population record: `docs/results/swe-v4-sonnet55-2026-10/comparison.json`,
built by `scripts/cii-v4-board/build_sonnet55_population.py`.

- Population: the October 2026 Claude Sonnet 5.5 sweep of Frontier v4,
  low through max, one attempt per task and level, through Claude Code
  2.1.291 to 2.1.293 (the version is recorded per row), refusal fallback
  on. Exclusions, if any, are listed in the population record.
- Task hashes: the sweep ran before tagged run worktrees, from a checkout
  whose `task_hash` still counted `__pycache__` files, so its summaries
  record hashes that differ from `suite.lock.json`. The population builder,
  and the runner in every stage (`prepare` and `verify_frozen`), accept a
  run only through the committed bridge
  `docs/judging/task-hash-bridge-sonnet55.json`, which
  pairs each task's recorded hash with its lock hash, both computed on the
  same unchanged directories. Every repo `.pyc` an agent could have seen
  is byte-identical to compiling the starting source, so the extra files
  revealed nothing (DECISIONS.md, 2026-10-07).
- Judge pins: the v3.3 and v3.4 run directories held the Grok and Muse
  reviewer settings and binary pins, and existed only on the original
  host, which was erased. `docs/judging/judge-pins-v3.json` now holds the
  settings, recovered from the published judge-protocols data (identical in
  the v3.4, v3.15 and v3.17 bundles and equal to the v3 constants). Muse
  Spark 1.3 runs the same binary as every earlier round, matched by sha256.
  The Cursor CLI that carries Grok 4.6 is re-pinned by sha256 on this host;
  equality with the v3.3 Cursor pin cannot be shown, and every card says so.
  Binary paths are resolved on the host and only hashes are compared.
- Judges: Muse Spark 1.3 and Grok 4.6, neutral for an Anthropic submission.
  Both retake the exam under v3.23 before any counted call; one failing
  panel is disclosed and the passing one publishes, two failures stop the
  amendment.
- Comparability: Frontier Code quality is L1 plus L2, as for v3.15, and is
  never placed beside Routine Code quality.
- Correction, October 8, 2026 (after the round; the frozen copy of this
  document is unchanged): the v3.3 and v3.4 protocol files were recovered
  from the owner's private pre-reset backup and are committed under
  `docs/judging/recovered/`; the settings above are identical to them. The
  Cursor pin hashes only Cursor's launcher script, which is the same in every
  release, so it does not fix the version: every v3.23 Grok call ran on Cursor
  CLI `2026.10.01-e373342`, while v3.3 recorded `2026.09.02-c22c1a3`
  (DECISIONS.md, 2026-10-08).

## Amendment v3.24, October 10, 2026: Claude Haiku 5.5 on Frontier v4, Cursor pinned by version

The v3.23 protocol on a new population, with two pins fixed. Nothing in the
rubric, controls, quirk keys, gates, repeats, seed, weights or judge settings
changes. Protocol id `code-quality-maintenance-v3.24`; run directory
`runs-code-quality-maintenance-v3.24`; runner
`harness/maintenance_review_v324.py`, derived from the v3.23 runner. Population
record: `docs/results/swe-v4-haiku55-2026-10/comparison.json`, built by
`scripts/cii-v4-board/build_haiku55_population.py`.

- Population: the October 2026 Claude Haiku 5.5 sweep of Frontier v4, low
  through max, one attempt per task and level, through Claude Code 2.1.293 to
  2.1.296 (the version is recorded per row), refusal fallback on, run from
  `bench/2026-10-07-haiku55-frontier-v4`, so task hashes match the suite lock
  and no bridge is used. The sweep paused between tasks from October 9, 08:43
  to October 10, 02:20 PDT; the run interrupted by the pause is kept outside
  the sweep folder and not judged.
- Exclusions: runs whose patch is empty are not judged, as in v3.15. So far
  two paddockcore runs (medium and extra-high) qualify: in each a safety
  classifier stopped Claude Code mid-session while it probed the legacy
  binary, and the model ended without editing the module. They count as
  failed in tasks passed and are priced. The population record lists every
  exclusion with its reason.
- Judge settings are read from the recovered original protocols in
  `docs/judging/recovered/` (Grok from v3.3, Muse from v3.4), each checked
  against its published sha256. Muse runs the v3.4 binary, matched by sha256.
- Cursor is pinned by version. The runner resolves `~/.local/bin/cursor-agent`
  once at prepare, judges through that versioned launcher for the whole round
  (Cursor keeps old version directories when it updates itself), records a
  digest of the version directory, and re-checks it before every stage.
- Judges: Muse Spark 1.3 and Grok 4.6, neutral for an Anthropic submission;
  both retake the exam under v3.24 before any counted call. One failing panel
  is disclosed and the passing one publishes; two failures stop the amendment.
- Comparability: Frontier Code quality is L1 plus L2, as for v3.15 and v3.23,
  and is never placed beside Routine Code quality.

## Amendment v3.25, October 15, 2026: Muse Wonder Full on Frontier v4, judged by Grok 4.7 and GPT-6.1 Sol

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or weights
changes from v3.7. What changes is the population and both judges. Protocol id
`code-quality-maintenance-v3.25`; run directory
`runs-code-quality-maintenance-v3.25`; runner
`harness/maintenance_review_v325.py`, derived from the v3.24 runner with
v3.20's Sol seat transport. Population record:
`docs/results/swe-v4-musewonder-full-2026-10/comparison.json`, built by
`scripts/cii-v4-board/build_musewonder_population.py`.

- Population: the October 13 to 14, 2026 Muse Wonder Full sweep of Frontier
  v4 through Muse Code 1.4.6 (solver `muse-code:muse-wonder-full-1.0-contributor`)
  in Contributor mode with Muse Code's skill reminder off, Low and Medium, one
  attempt per task and level, run from
  `bench/2026-10-13-musewonder-full-v2-low`. Low has 23 runs. Medium has 21:
  cellarcore and paddockcore had not run when the Muse Code weekly limit ran
  out (it resets 2026-10-19 00:00 UTC), so both are recorded under `missing`
  with that reason and the cell freezes at 21. The interrupted cellarcore
  attempt sits in the sweep's `quota-aborted/` folder and is not judged. The
  builder stops on any run whose solver id, requested effort, Muse Code
  version, checkout state or task hash differs from the sweep's record.
- Top-up: once the two Medium runs exist they are judged as v3.25.1
  (`runs-code-quality-maintenance-v3.25.1`), on the v3.6.1 precedent. Its
  population is built with `build_musewonder_population.py --top-up`, which
  keeps only runs on the v3.25 protocol's frozen `missing` list and writes
  `comparison-topup.json` beside the v3.25 record. Both judges' v3.25
  verdicts gate the top-up with no new exam; each top-up submission gets a
  primary and a repeat review and no pairwise check. Publication merges both
  directories, recomputes the Medium cell over all 23, and the v3.25 record is
  not rewritten.
- Judges: Muse Spark 1.3 is a Meta model and is not neutral for a Meta
  submission, so it is excluded (owner decision in chat, October 15, 2026),
  as Grok 4.6 was for Grok 4.7 under v3.20. The owner chose Grok 4.7 and
  GPT-6.1 Sol, both neutral for a Meta submission.
  - Seat "grok": Grok 4.7 at medium through Cursor, model id
    `grok-4.7-medium`, on v3's frozen Cursor transport. The identity check
    requires the label Cursor reports at run time, `Grok 4.7 256K Medium`
    (its model list renders `Grok 4.7  Medium` without the 256K context
    label). Cursor is pinned by version
    directory as in v3.24, to the same version (`2026.10.01-e373342`) and
    digest v3.24 recorded; the runner refuses any other. Grok 4.7 has never
    judged before.
  - Seat "sol": GPT-6.1 Sol at medium through Codex CLI 0.159.0, on the
    transport v3.20 built (v3's frozen call with `codex_vote`). Codex 0.159.0
    was reinstalled on this host under
    `~/.local/share/vulcanbench/codex-0.159.0/`. Both the `codex.js` launcher
    (sha256 `61b0194f3bb6534439c8d26a3ed57d0805f84b884588b761795323eeb92fcf70`)
    and the native binary it runs
    (`@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex`, sha256
    `e89718aa1969bfc4a471277bdc4679a3a3529293de0a309909822dfd67ddb77a`) are
    pinned; v3.20 pinned only the launcher.
  - Both judges take the exam under v3.25 before any counted call. One
    failing panel is disclosed and the passing one publishes alone; two
    failures stop the amendment. There are no sensitivity panels.
- Pins are re-checked before every stage: the Cursor version digest and both
  Codex hashes, from the protocol record, so a changed or missing CLI stops
  the round before any call.
- Diagnostics: with only two levels, v3's "two levels two steps apart" pair
  would set a submission against itself, so each pair sets one task's Low
  submission against its Medium one, one pair per level, with tasks taken in
  the seeded order and any task lacking either submission skipped.
- Comparability: a Muse Wonder Full score is a mean of Grok 4.7 and GPT-6.1
  Sol. Other models' published combined scores come from their own rounds and
  panels, none of which is this pair, so any card that places them side by
  side names the panel behind each column.

## Amendment v3.26, October 15, 2026: Opus 5.5 replaces the Grok 4.7 seat for Muse Wonder Full

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
population changes from v3.25. What changes is one seat. Protocol id
`code-quality-maintenance-v3.26`; run directory
`runs-code-quality-maintenance-v3.26`; runner
`harness/maintenance_review_v326.py`.

- Why: under v3.25, GPT-6.1 Sol passed the exam and finished every review,
  probe and match. Grok 4.7 stopped on its first exam call: the Cursor
  account ran out of usage (October 15, 2026, 17:57, "You're out of usage"),
  a stop and not a judgment. The owner replaced the Grok seat with Claude
  Opus 5.5 (chat, October 15, 2026).
- Round shape: v3.25's votes are bound to its protocol hash, so the new seat
  runs as its own round with Sol attached as a scored sibling, the pattern
  v3.4 and v3.13 used. Sol's v3.25 directory is read as it stands; this
  protocol records its protocol hash and exam verdict and re-checks the hash
  before every stage. Prepare refuses unless the manifest, evidence, signals,
  controls, quirk keys, diagnostic selection and calibration order are
  byte-identical to v3.25's, and the rubric, prompts, schemas, seed, repeats,
  gate allowance, weights and population in the protocol record equal
  v3.25's. v3.25 is not rewritten; its Grok seat stays recorded as stopped.
- Seat "claude": Claude Opus 5.5 at medium (`claude-opus-5-5`) through Claude
  Code 2.1.300 on the subscription, on v3's frozen Claude transport: tools
  disabled, structured output, every assistant message must report
  `claude-opus-5-5`, any model fallback fails the call, and the quota guard
  stops before any call once overage is in use or a window passes 80%. Claude
  Code updates itself in place, so the judge runs from a copy of the 2.1.300
  binary at `~/.local/share/vulcanbench/claude-2.1.300/claude` (sha256
  `475517caa611e3318a2f298fa071287ec98955538df78c58f709ecc01e5ae2d3`), which
  v3's frozen-input check re-hashes before every stage. Opus 5.5 takes the
  exam under v3.26 before any counted call.
- Neutrality: Opus 5.5 is neutral for a Meta submission. It is also one of
  the models the Muse Wonder Full comparison card places beside Muse Wonder
  Full; its own combined score there comes from its own round's panel, not
  from this one, and the card says so.
- Single-panel rule: if Opus fails the exam it is disclosed and Sol publishes
  alone; Sol has already passed.
- Top-up: the two missing Medium runs, recorded in the population under a
  v3.25.1 top-up, are judged as v3.26.1
  (`runs-code-quality-maintenance-v3.26.1`), gated by this round's Opus
  verdict and v3.25's Sol verdict with no new exam; each top-up submission
  gets a primary and a repeat review from both seats and no pairwise check.
- Comparability: a Muse Wonder Full score is a mean of Opus 5.5 and GPT-6.1
  Sol.

## Amendment v3.26.1, October 16, 2026: the Muse Wonder Full Medium top-up

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
judges changes from v3.26. Protocol id `code-quality-maintenance-v3.26.1`; run
directory `runs-code-quality-maintenance-v3.26.1`; runner
`harness/maintenance_review_v3261.py`. Population record:
`docs/results/swe-v4-musewonder-full-2026-10/comparison-topup.json`, built by
`build_musewonder_population.py --top-up`.

- Population: only the Medium runs v3.25 and v3.26 froze as missing
  (cellarcore, paddockcore). After the quota reset they ran through Muse Code
  1.4.9 in `runs-effort-musewonder-full-v2-149`, which continues the 1.4.6 root
  (DECISIONS.md, 2026-10-16). Muse Code 1.4.9 runs its goal and verify reminder
  observers on Muse Spark 1.3; the builder checks the sweep's recorded allowance
  and each row records those observers' usage. Prepare refuses any run already
  judged under v3.26 or not on the frozen missing list, and requires each cell
  to reach 23 with the v3.26 rows.
- Judges: no new exam, on the v3.6.1 precedent. Claude Opus 5.5 is gated by
  its v3.26 verdict and GPT-6.1 Sol by its v3.25 verdict, each re-checked
  against the protocol it was taken under; their settings and binary pins are
  copied from those protocols and the binaries are re-hashed. Sol runs on the
  Codex transport, as in v3.25.
- Each submission gets a primary and a repeat review from both judges, a probe
  and a match, and no pairwise check.
- Publication merges this directory with v3.26 (and v3.25 for Sol); neither
  record is rewritten. Medium then reaches 23 runs: 21 on Muse Code 1.4.6 and
  2 on 1.4.9, which every card says.

## Amendment v3.26.2, October 17, 2026: Muse Wonder Full at High

Nothing in the rubric, controls, quirk keys, gates, repeats, seed, weights or
judges changes from v3.26. Protocol id `code-quality-maintenance-v3.26.2`; run
directory `runs-code-quality-maintenance-v3.26.2`; runner
`harness/maintenance_review_v3262.py`. Population record:
`docs/results/swe-v4-musewonder-full-2026-10/comparison-high.json`, built by
`build_musewonder_population.py --level high`.

- Population: Muse Wonder Full's High level, every run through Muse Code
  1.4.9 in `runs-effort-musewonder-full-v2-149` (DECISIONS.md, 2026-10-16),
  with each row's Spark 1.3 reminder-observer usage recorded. Prepare refuses
  any run already judged in v3.26 or v3.26.1, any run not from Muse Code
  1.4.9, and a level whose runs and reasoned gaps do not make 23.
- Judges: no new exam. High is another level of the same Muse Wonder Full
  sweep, so Claude Opus 5.5 is gated by its v3.26 verdict and GPT-6.1 Sol by
  its v3.25 verdict, as in v3.26.1, each re-checked against the protocol it
  was taken under; settings, binary pins and Sol's Codex transport are
  v3.26.1's.
- Each submission gets a primary review, a probe and a match from both judges;
  the cell gets one repeat review, as v3.25 and v3.26 gave each cell; no
  pairwise check.
- Publication merges this directory with v3.26 and v3.26.1; no earlier record
  is rewritten. Extra-high follows as its own round in the same way.

## Amendment v3.26.3, October 17, 2026: Muse Wonder Full at Extra-high

Everything is as in v3.26.2, for the Extra-high level. Protocol id
`code-quality-maintenance-v3.26.3`; run directory
`runs-code-quality-maintenance-v3.26.3`; runner
`harness/maintenance_review_v3263.py`. Population record:
`docs/results/swe-v4-musewonder-full-2026-10/comparison-extra-high.json`,
built by `build_musewonder_population.py --level extra-high`.

- Population: Muse Wonder Full's Extra-high level, every run through Muse
  Code 1.4.9. Prepare also refuses any run already judged in v3.26.2.
- Judges: no new exam, as in v3.26.2 (owner approval for High, 2026-10-17,
  applied the same way): Opus 5.5 gated by its v3.26 verdict, GPT-6.1 Sol by
  its v3.25 verdict.
- A run that hit the 3-hour bound has no finished code and is excluded with
  its reason; the card applies the 2026-09-28 two-figure rule.
- Publication merges this directory with v3.26, v3.26.1 and v3.26.2; no
  earlier record is rewritten. This completes the Muse Wonder Full levels
  under Contributor mode (Max is excluded).

## Amendment v3.26.4, October 17, 2026: the Extra-high depotcore rerun

Everything is as in v3.26.1, for Extra-high. Protocol id
`code-quality-maintenance-v3.26.4`; run directory
`runs-code-quality-maintenance-v3.26.4`; runner
`harness/maintenance_review_v3264.py`. Population record:
`docs/results/swe-v4-musewonder-full-2026-10/comparison-extra-high-topup.json`,
built by `build_musewonder_population.py --level extra-high --only
legacy-depotcore-binary-parity`.

- Why: Extra-high depotcore first hit the 3-hour bound while another
  session's Frontier v5 jobs ran beside it for 145 of its 180 minutes, so
  v3.26.3 excluded it. Under the owner's overlap rule it was rerun alone on
  Muse Code 1.4.9; the overlapped attempt is kept in the sweep's
  `overlap-superseded/` folder and disclosed (DECISIONS.md, 2026-10-17).
- Population: only runs v3.26.3 recorded as excluded; prepare refuses
  anything else, and Extra-high must then reach 23 with v3.26.3's 22 rows.
- Judges: no new exam, as in v3.26.1 to v3.26.3. Each submission gets a
  primary and a repeat review from both judges, a probe and a match, and no
  pairwise check.
- Publication merges this directory with v3.26.3; no earlier record is
  rewritten.

## Amendment v3.27, October 23, 2026: DeepSeek V4.1 Flash, judged by Muse Spark 1.3 and GPT-6.1 Sol

Nothing in the rubric, controls, quirk keys, gates, repeats, seed or weights
changes from v3.7. What changes is the population and the second judge.
Protocol id `code-quality-maintenance-v3.27`; run directory
`runs-code-quality-maintenance-v3.27`; runner
`harness/maintenance_review_v327.py`, derived from the v3.24 and v3.25 runners.
Population record: `docs/results/swe-v4-deepseek-flash-2026-10/comparison.json`,
built by `scripts/cii-v4-board/build_deepseek_flash_population.py`.

- Population: the October 2026 DeepSeek V4.1 Flash sweep of Frontier v4
  (`deepseek-flash`, V4.1-Flash-1017) through DeepSeek Harness 0.2.1-rc.2
  (solver `dsh:deepseek-flash`), with web tools, session-log upload and
  telemetry off, at Low, High and Max (DeepSeek's API has no medium), one
  attempt per task and level, 69 runs, from
  `bench/2026-10-20-deepseek-dsh-frontier-v4`. The owner paused the sweep
  twice between tasks; each run a pause interrupted is kept in the sweep's
  `paused-interrupted/` folder and not judged. macOS went from 26 to 27.0.1
  during the second pause; re-grading the 13 runs finished before it on 27.0.1
  changed no score. The builder stops on any run whose solver, requested
  effort, harness version or checkout state differs from the sweep's record.
  All 69 runs reconstruct; nothing is excluded or missing.
- Judges: Muse Spark 1.3 and GPT-6.1 Sol, the pair v3.20 used for Grok 4.7.
  Grok 4.6 holds the usual second seat, but the Cursor account it judges
  through was out of usage on October 23, and the owner chose GPT-6.1 Sol for
  the seat. Both are neutral for a DeepSeek submission. Muse runs the v3.4
  settings, read from the recovered v3.4 protocol as in v3.24, on the v3.4
  binary matched by sha256; Muse Code's updater had removed the copy in
  `~/.local/bin`, so the round runs a byte-identical backup. GPT-6.1 Sol runs
  at medium through Codex CLI 0.159.0 on v3.20's Sol seat transport, with the
  launcher and native binary pinned by sha256 as in v3.25. Every stage
  re-checks the Muse binary and both Codex hashes.
- Exam: both judges retake the exam under v3.27 before any counted call. One
  failing panel is disclosed and the passing one publishes; two failures stop
  the amendment.
- Diagnostics: one repeat per cell and one pair per level, each task set
  against the next level up (Max wraps to Low).
- Comparability: a Flash score is a mean of Muse Spark 1.3 and GPT-6.1 Sol.
  Claude Opus 5.5 and GPT-6.1 Sol's own columns are judged by Muse Spark 1.3
  and Grok 4.6, so any card placing them side by side says the panels differ.

## Amendment v3.28, October 24, 2026: Reflection Beam, judged by Muse Spark 1.3 and GPT-6.1 Sol

Everything is as in v3.27 except the population. Protocol id
`code-quality-maintenance-v3.28`; run directory
`runs-code-quality-maintenance-v3.28`; runner
`harness/maintenance_review_v328.py`, derived from the v3.27 runner. Population
record: `docs/results/swe-v4-beam-2026-10/comparison.json`, built by
`scripts/cii-v4-board/build_beam_population.py`.

- Population: the October 2026 Reflection Beam sweep of Frontier v4
  (`Beam-1.0-501B-A23B`) through Mirror CLI 0.1.1 (solver
  `mirror:Beam-1.0-501B-A23B`), Low to Max (Extra high is Beam's `xhigh`), one
  attempt per task and level, 115 runs, from
  `bench/2026-10-23-beam-mirror-frontier-v4`. Each run had a private Mirror
  home with the usage notice acknowledged and only its workspace trusted
  (owner approved), analytics off and no web search keys. The builder stops
  on any run whose solver, requested effort, harness version or checkout
  state differs from the sweep's record.
- Exclusions: a run that ends with an empty patch has no code to review and is
  not judged, as in v3.15 and v3.24; it counts as a failed task. Beam ends
  some Low and Medium runs without changing any file, so those cells freeze
  below 23 and the population record lists each exclusion with its reason.
- Judges: Muse Spark 1.3 and GPT-6.1 Sol, as in v3.27. Grok 4.6's Cursor
  account was out of usage again on October 24; the owner agreed to keep
  GPT-6.1 Sol in the seat. Both are neutral for a Reflection submission and
  retake the exam under v3.28.
- Diagnostics: one repeat per cell and one pair per level, each task set
  against the next level up (Max wraps to Low).
- Comparability: as in v3.27; a Beam score is a Muse Spark 1.3 and GPT-6.1 Sol
  mean, like DeepSeek V4.1 Flash's, and any card beside Muse Spark 1.3 and
  Grok 4.6 columns says the panels differ.

## Amendment v3.29, October 28, 2026: GPT-6.1 Terra, judged by Muse Spark 1.3 and Grok 4.6

The v3.24 protocol on a new population, with the Cursor pin held to the
version v3.24 used. Nothing in the rubric, controls, quirk keys, gates,
repeats, seed, weights or judge settings changes. Protocol id
`code-quality-maintenance-v3.29`; run directory
`runs-code-quality-maintenance-v3.29`; runner
`harness/maintenance_review_v329.py`, derived from the v3.24 runner.
Population record: `docs/results/swe-v4-gpt61-terra-2026-10/comparison.json`,
built by `scripts/cii-v4-board/build_gpt61terra_population.py`.

- Population: the October 2026 GPT-6.1 Terra sweep of Frontier v4
  (`gpt-6.1-terra`) through Codex CLI 0.159.0 on the ChatGPT subscription
  (solver `codex:gpt-6.1-terra`), Low to Max (Extra high is Codex's `xhigh`),
  one attempt per task and level, 115 runs, from
  `bench/2026-10-27-gpt61-terra-frontier-v4`, so task hashes match the suite
  lock and no bridge is used. No run timed out and none ended with an empty
  patch, so every cell freezes at 23.
- Judges: Muse Spark 1.3 and Grok 4.6, the pair that judged GPT-6.1 Sol
  (v3.18) and Claude Opus 5.5 (v3.15). Both are neutral for an OpenAI
  submission (owner choice in chat, October 28) and retake the exam under
  v3.29 before any counted call. Settings are read from the recovered v3.3
  and v3.4 protocols, each checked against its published sha256, as in v3.24.
  GPT-6.1 Sol, the second seat in v3.27 and v3.28, is from Terra's own lab
  and does not sit.
- Cursor: pinned to `2026.10.01-e373342` and the digest v3.24 recorded, as in
  v3.25. Cursor has since updated itself to `2026.10.14-941492e`; the round
  judges through the pinned version's own launcher and re-checks its digest
  before every stage. Cursor reports Grok 4.6's display name as "Grok 4.6
  Medium" (frozen: "Cursor Grok 4.6 Medium"); `v3_resume` accepts that
  rename and records it per call, as in v3.23 and v3.24.
- Diagnostics: one repeat per cell and one pair per level, each task set
  against the level two steps up (wrapping), as in v3.24.
- Comparability: a Terra score is a Muse Spark 1.3 and Grok 4.6 mean, the
  same panel as the GPT-6.1 Sol and Claude Opus 5.5 columns.
- Recovery (owner decision, October 29): Muse's probe of max settlecore
  (submission-011) quoted a byte-string line with its escapes decoded, the
  JSON-escaping slip the v3.18 wrapper rule `recover_escaped_excerpts`
  covers. The source spells NUL as backslash-x-00, which the rule did not
  yet try, so the probe was first marked invalid. The rule now tries both
  spellings, and the probe is recovered under it; details in
  `maintenance-v3-operations.md`.

## Not yet done

- v3.4 calibration results for Muse Spark 1.3, v3.3 results for Grok 4.6,
  and every later stage.
- L3 follow-up change generation, per task, and its worker runner.
