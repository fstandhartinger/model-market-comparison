PRIMARY USER REQUIREMENTS: Phase7 rebrand Benchmark Heaven, new primary https://benchmarkheaven.com, retain https://model-market-comparison.app.mintapis.com. Apply README header, API docs, fork-sync prompt, Telegram templates. Document loudly in CHANGELOG/API: new base URL, old still valid, nothing else moved. Keep daily cron working. Commit trailer must be Co-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>. Never invent scores/sources.

SCOPE: exact documentation semantics, names/URLs, compatibility, fork brand handling, Telegram template branding/quiet policy, script User-Agent-only changes and installed prompt/runner equality. The doc target is the intended release. Publication is withheld until separate DNS/TLS/release checks pass. TLS is not accepted by this review; a primary CA outage is currently being resolved. Previous dated history should stay historical. Saved preferences are per origin, keys unchanged.

{
  "artifact_id": "phase07-consumer-docs-ops",
  "round": 2,
  "files": {
    "README.md": "4c206d6c26c61a0c36e2c64b0b9db871fe1164a67f7aaa13439c627d26fd5c8a",
    "API.md": "820e48eb557424d843ad236c389663f43c228a5cc1de175eb96b5f64baccda14",
    "CHANGELOG.md": "e229cb2e57c622ac25d7332302d63fcc30df89788b610fee2dd45749d7b83fc3",
    "DEPLOYMENT.md": "3aa8278ae5cf06c73132558c1646f7f45a3f285dccfebbc38d5726fc76e51a1d",
    "PRD.md": "135af6b5312fe670620ded3863b36d4321b70490f8ca78558675395cf132ddfc",
    "MSG-SPINOFF-STARTER-PROMPT.md": "9320c7dce24a0d6bbc62dafa3a6682c7dc03085516b1b45a158cd139ffbdae27",
    "MSG-UPSTREAM-SYNC-PROMPT.md": "c2f14effed40e3785e77a627f2634e7ecd2229944ae6160f5124c119ccbcbde5",
    "ops/daily/run.sh": "39a9ee2c0c62880eedd29bed24aaa2ef4a77ff63fa2cc41470532d5761dcb34f",
    "ops/daily/prompt.md": "943ac99621b0c69ba3a6df8bf7217c7554a50e3760db0198f0ac4f6c7deabe3a",
    "ops/daily-refresh-prompt.md": "943ac99621b0c69ba3a6df8bf7217c7554a50e3760db0198f0ac4f6c7deabe3a",
    "ops/rebuild-2026-09/daily-refresh-prompt.md": "943ac99621b0c69ba3a6df8bf7217c7554a50e3760db0198f0ac4f6c7deabe3a",
    "scripts/fetch-live.mjs": "a0ba3996374da6146f90d544ce4a83b26ca9a6fcca3623c0b03508da2f342850",
    "scripts/fetch-aa-efficiency.mjs": "fffe97b0c2bbc12817f7bae08e8049b87ef07487c7147a57ddaa0a03110ef795",
    "scripts/fetch-aa-coding-agents.mjs": "b8bd5c8a36d090c5d14fdacd85ad42f466d107ef6d52e1a700e8dbf5ef1d90e2"
  },
  "artifact_sha256": "ad1a5d45da3f31f029bf553093fd1ca65ad222c57e1bfe2fd83756a34618cff7"
}
FILE README.md
![Benchmark Heaven](public/brand/wordmark.svg)

Benchmarks in perspective. Costs in context.

> Benchmark Heaven (formerly Model Market Comparison) has its primary base URL at
> **[benchmarkheaven.com](https://benchmarkheaven.com)** (2026-09-11). The previous host
> **[model-market-comparison.app.mintapis.com](https://model-market-comparison.app.mintapis.com)
> remains valid** and serves the same app and API endpoints. The GitHub repo, file paths,
> data schema, IDs, units, Composite and settings keys did not move. Browser preferences are stored per hostname
> and are not automatically transferred to the new domain.

Compare **open-source and frontier LLMs** by capability and price in one place.
Capability comes from [ArtificialAnalysis](https://artificialanalysis.ai) (Coding,
Coding Agent & Intelligence indices) and [Intelligence.ai / DesignArena](https://intelligence.ai)
(Agentic Web Dev Frontend & Full-Stack Elo). Prices are aggregated across **OpenRouter**
inference providers, **AWS Bedrock**, **Azure AI Foundry**, **Google Vertex AI**,
**Nebius**, **Inceptron**, **TensorX**, **Scaleway**, **IONOS**, **Mistral**, **Chutes**,
**OVHcloud**, **STACKIT**, **T-Systems LLM Hub**,
**GitHub Copilot**, and the **Anthropic / Claude Code** list price — normalized to
USD per 1M tokens.

> 📋 Product spec: [PRD.md](PRD.md) · 🗂️ Data schema: [data/SCHEMA.md](data/SCHEMA.md) ·
> 🔄 Data collection & refresh: [data/SCRAPING.md](data/SCRAPING.md) ·
> 🔌 Public API: [API.md](API.md) · 🚀 Deploy / migrate / env vars: [DEPLOYMENT.md](DEPLOYMENT.md) · 📜 Data/URL changes for consumers: [CHANGELOG.md](CHANGELOG.md)


## Benchmark exploration

Explore [benchmark rankings](https://benchmarkheaven.com/benchmarks), compare up to four exact model configurations on [Compare](https://benchmarkheaven.com/compare), or use the standalone [Radar](https://benchmarkheaven.com/radar). Model pages include complete benchmark sheets, source links and dates, missing coverage, and explainable profile signals. Every comparison keeps benchmark versions separate. [Methodology and limitations](docs/benchmark-explorer.md).


## Features

- **Price & provider filters** (apply to price comparisons and model offers; benchmark exploration uses its own filters, persisted): selectable **score**,
  min-score, **One variant for Reasoning models** (collapse GPT/Claude/GLM/Kimi to one),
  **Featured**, **Hide deprecated** (on by default), **Exclude Chinese providers**, **EU-hosted / approved equivalent only**, **Non-US provider only**,
  **TEE / confidential only**, plus
  provider- and model-checklist filters.
- **Selectable scores**: **Composite** (five percentile slots with model-mean imputation plus a dominance-safe projection, 0–100, default), ArtificialAnalysis
  **Coding Index**, **Coding Agent Index** (median across published harnesses for the exact model/effort variant), **Intelligence Index**,
  and DesignArena **Frontend** / **Full-Stack** Elo.
- **Overview** — fully sortable table with per-column filters, **Has benchmark evidence**
  for Composite (or **Has score** for a direct metric) / **Has provider**
  toggles, and Excel-style **data bars** on score & cost.
- **Compare** — pick two models (A/B) head-to-head; scores & cheapest price shown big with
  the winner highlighted, plus each model's cheapest providers side by side.
- **Cost vs Capability** — scatter: **x = cost** (cheapest 10:1 blended $/1M, axis inverted
  so cheaper is right), **y = capability**, circle = closed / square = open, with a
  **Pareto frontier** line of best-value models.
- **Charts** — capability leaderboard, cheapest-model ranking, open vs closed comparisons.
- **Model detail** — top-5 cheapest providers and all offers by platform within the
  active global filter scope, full benchmark breakdown, reasoning-variant comparison,
  current GitHub Copilot token/AI-Credit prices and legacy per-request cost.
- **Providers per Model** — searchable model picker → that model's providers ranked by price.
- **Provider explorer** — pick one provider → every model it offers; click a model to compare
  that provider's price against all others (ranked, with its price-rank in the field).
- **Gateways** — 35+ LLM gateways/routers/aggregators compared on EU routing capability,
  self-host/local, open-source license, HQ and pricing.
- **EU & Sovereign** — which providers are EU-hosted/sovereign and which SOTA models they
  actually serve (incl. TEE/confidentiality notes + a separate dedicated/BYOC-only list).
  Interactive EU filtering requires evidence on the exact model offer; provider-level
  dedicated/BYOC capability alone never turns a global route into an EU-hosted one. The
  only policy exceptions are Azure Direct Global DeepSeek V4 Pro and Kimi K2.7 Code:
  they qualify as company-approved equivalents without being relabeled as technically EU-resident.
- **Public read-only JSON API** (CORS-enabled) — `/api/dataset` (full export),
  `/api/models`, `/api/models/[id]`, `/api/providers`, `/api/meta`, `/api/health`. See [API.md](API.md).

Featured models include **GPT-6 Astra**, **GLM-5.3 Flash**, **Qwen3.8 Max** (including the separately priced 0902 release), Muse Spark 1.3, and GPT-5.6 Sol/Terra/Luna, GPT-5.5 / GPT-5.4 (with Mini and
low/medium/high/xhigh settings), Claude Opus 4.8 / 4.7 / 4.6, Sonnet 4.6 / 5,
**Fable 5**, Kimi K2.5 / K2.6 /
K2.7-Coding, GLM 5.1 / 5.2, MiniMax M2.5 / M2.7 / M3, Xiaomi MiMo-V2.5-Pro and
DeepSeek V4 Pro.

## Stack

Next.js (App Router, TypeScript) · Recharts · PostgreSQL · live at [benchmarkheaven.com](https://benchmarkheaven.com) (Sandy/Coolify, snapshot mode); the former host [model-market-comparison.app.mintapis.com](https://model-market-comparison.app.mintapis.com) remains valid and serves the same app.

The app reads from Postgres when `DATABASE_URL` is set (seeded from
`data/dataset.json`) and otherwise serves the committed snapshot, so it always
renders even without a database.

## Local development

```bash
npm install
npm run dev          # http://localhost:3000  (uses bundled data/dataset.json)
```

### Refresh the data

```bash
export ARTIFICIAL_ANALYSIS_API_KEY=aa_…    # for the AA fetch
npm run data:refresh                        # fetch live APIs + rebuild dataset.json
# with a database:
export DATABASE_URL=postgres://…
npm run db:seed
```

See [data/SCRAPING.md](data/SCRAPING.md) for per-source details (incl. how to update
the manually scraped AWS / Azure / Copilot / Claude snapshots).

## Deploy / migrate

Full guide incl. **required env vars / secrets**, Postgres setup, Docker and **Azure**
hosting: [DEPLOYMENT.md](DEPLOYMENT.md). In short — the only runtime secret is the
optional `DATABASE_URL` (the app falls back to the bundled `data/dataset.json` snapshot
without it); `ARTIFICIAL_ANALYSIS_API_KEY` is needed only to refresh data, not at runtime.
A [`render.yaml`](render.yaml) Blueprint and a [`Dockerfile`](Dockerfile) are included.

## Methodology & caveats

10:1 blended cost = `(10·input + 1·output) / 11` per 1M tokens. EU residency is
audited per offer/model/region; an EU-capable provider does not make its US or global
routes EU-hosted. Separately, `eu_policy_equivalent` admits only Azure Direct Global
DeepSeek V4 Pro and Kimi K2.7 Code to the EU filter under this company&apos;s legal/business
classification; inference may occur outside the EU and the flag is not a technical residency
guarantee. The Composite uses five capability slots: AA Coding,
source-matched AA Coding Agent, AA Intelligence, DesignArena Frontend and DesignArena
Full-Stack. AA values are clamped to 0–100. A DesignArena board qualifies with at least
200 battles (an app minimum aligned with the source&apos;s typical preliminary/reliability threshold) and its Elo is converted to the expected score against a fixed Elo 1000
opponent: `100 / (1 + 10^((1000 − Elo) / 400))`. Each observed slot is then converted
to its empirical percentile among the current catalog&apos;s unique observed values. Every
missing slot is assigned that model&apos;s mean percentile across its observed slots. The
base is therefore exactly the mean of its available percentiles, so missing slots cannot
move it. A deterministic least-squares projection then enforces shared-evidence dominance:
if one model covers every reliable slot of another measured model and is
no worse in any shared slot (strictly better in at least one), it remains at least 0.1 points
ahead. This is the smallest symmetric catalog-wide adjustment satisfying those constraints;
the base and adjustment are exposed separately in model details and the models API. A model
with no reliable observed slot receives the neutral fallback 50. Coverage
is tracked separately so this fallback is not mistaken for benchmark evidence when choosing
a family representative, applying **Has benchmark evidence**, or building capability charts and the
Pareto frontier. GitHub Copilot&apos;s
current token/AI-Credit rates and legacy annual-plan
request multipliers are kept separate from provider API offers.
Model identities are joined conservatively across sources; modes, releases, pricing tiers
and hosting routes remain separate unless a stable source id/repository proves equivalence.
When Intelligence.ai publishes only a bare product identity, that family-scoped result is
attached exactly once to the deterministic active representative used by collapsed views,
with an explicit provenance note that it does not identify the tested effort setting.
Figures may still change upstream —
**verify before relying on them**. Not affiliated with any provider.

Brand: [direction, usage and assets](docs/brand.md) · [three visual concepts](public/brand/variants.svg).

FILE API.md
# Benchmark Heaven public API

> **2026-09-11 — New domain:** Benchmark Heaven at benchmarkheaven.com
>
> The product is now **Benchmark Heaven** (formerly Model Market Comparison). Its
> **new primary base URL is `https://benchmarkheaven.com`**.
> The previous base URL **`https://model-market-comparison.app.mintapis.com` remains
> valid as a compatibility URL and serves the same endpoints and dataset** — existing
> consumers do NOT have to migrate.
> **Nothing else moved**: API routes, JSON shapes, schema, model/offer/benchmark IDs,
> units, the Composite definition, settings keys, the GitHub repo and file paths
> are all unchanged.
> Browser preferences are stored per origin; the old hostname’s saved filters/theme
> do not automatically transfer to the new hostname.

All endpoints are **read-only**, return JSON, and are **CORS-enabled** (`Access-Control-Allow-Origin: *`), so they can be called from any site or tool — including directly from a browser.

Base URL (primary): `https://benchmarkheaven.com`
Base URL (compatibility, unchanged, same endpoints): `https://model-market-comparison.app.mintapis.com`

The data is served from Postgres when `DATABASE_URL` is configured, otherwise from the committed `data/dataset.json` snapshot — the API shape is identical either way.

## Endpoints

### `GET /api/benchmarks`

All exact versioned registry entries, source/metric definitions, collection status and
per-benchmark coverage. No family-only version aliases are accepted.

### `GET /api/benchmark-scores`

Filters: `benchmark_id`, `model_id`, `basis` (`measured`, `self_reported`, `derived`),
`offset` (default 0), `limit` (default 100, maximum 500). Returns observations, total,
stored divergences, coverage and collection status. Both identity filters also return
the sparse cell status. Unknown exact versions/models return 404; bad parameters 400.
Derived observations include `source_basis` and formula/inputs. Every score includes
its source URL, dates, immutable hash and locator. Unmatched source subjects have null
catalog model IDs and remain queryable by benchmark.

The full dataset now includes `benchmark_results` with the registry, observations,
missing cells, collection attempts, rejections, divergences and coverage. Model detail
also returns `benchmark_observations`, `benchmark_divergences`, `benchmark_coverage`.
See [ingestion and missing-value contract](docs/benchmark-ingestion.md). Composite
scores and their five existing slots retain their previous API behavior.

### `GET /api/dataset`
The **full dataset** in one response — the canonical machine-readable feed: every model (with benchmarks, scores, all provider offers), the provider directory, source collection dates and counts. Cached 5 min (`Cache-Control: public, max-age=300`).

```jsonc
{
  "generated_at": "2026-07-12T…",
  "counts": { "models": 758, "families": 600, "providers": 85, "offers": 2368 },
  "sources": { "artificialanalysis": "2026-07-12", "openrouter": "2026-07-12", … },
  "models": [ { "id": "glm-5.2::max", "family_key": "glm-5.2", "family_name": "GLM 5.2",
    "org": "Z.ai", "variant": "max", "open_weights": true, "featured": true,
    "benchmarks": { "aa_coding_index": 68.8, "aa_coding_agent_index": 57.9,
      "aa_intelligence_index": 51.1, "aa_livecodebench": …, "aa_scicode": … },
    "designarena": { "frontend": { "elo": 1276, "battles": 4923 },
      "fullstack": { "elo": 1296, "battles": 1848 } },
    "offers": [ { "source": "Inceptron", "provider": "Inceptron", "platform": "Inceptron",
      "input_per_1m": 0.95, "output_per_1m": 3.04, "region": "eu", "unit": "per_1m_token",
      "eu_hosted": true, "non_us": true, "tee": false } ],
    "copilot": null } ],
  "providers": [ { "platform": "Nebius", "provider": "Nebius", "model_count": 25,
    "eu_hosted": true, "non_us": true, "country": "Netherlands" } ]
}
```

### `GET /api/models`
List of models with a single chosen score, the cheapest 10:1-blended cost, and the top-5 cheapest providers per model.
Every row also includes `composite_base` (the pre-projection mean-imputed value) and
`composite_coverage` from 0 to 5 so clients can distinguish the neutral Composite fallback
50 at 0/5 from a measured score.

Query params:
- `score` — one of `composite` | `aa_coding_index` | `aa_coding_agent` | `aa_intelligence_index` | `designarena_frontend` | `designarena_fullstack` (default `aa_coding_index`).
- `featured=1` — only the curated featured set.
- `hasBenchmark=1` — only models with source benchmark evidence. This excludes
  zero-evidence rows even though their `composite` fallback is the neutral 50.

### `GET /api/models/{id}`
One model by `id` (e.g. `glm-5.2::max`) or by `family_key` (e.g. `glm-5.2`): full benchmarks, all token offers, sibling reasoning variants, and the top-5 cheapest providers.

### `GET /api/providers`
The provider/platform directory with per-provider model counts and the `eu_hosted` / `non_us` / `country` flags.

### `GET /api/meta`
Dataset `generated_at`, `counts`, per-source collection dates, and whether the data is served from `postgres` or the bundled snapshot.

### `GET /api/health`
`{ "ok": true, "db": true|false }` — liveness + whether a database is wired.

## Pricing / score conventions
- Token prices are **USD per 1M tokens**, input and output separately. EUR-native snapshots retain the original EUR fields and store the audited ECB conversion rate/date used for USD normalization. An active catalog row may have `null` prices when the provider publishes no per-model rate. Context tiers, OpenRouter endpoint tiers, and managed routes such as Azure Direct versus Fireworks remain separate offers. Current GitHub Copilot usage is token-metered and converted to AI Credits at $0.01/credit; its `current` rates stay on the separate Copilot product axis. `multiplier` / `usd_per_request` apply only to eligible legacy annual Pro/Pro+ request billing.
- **10:1 blended cost** = `(10·input + 1·output) / 11`.
- Score scales: `composite` and the AA indices are 0–100; raw DesignArena score keys return Elo (~1000–1400). The **Coding Agent Index** is the median across all published harnesses for the exact model/reasoning-effort variant (Claude Code / Codex / Cursor CLI / …); every harness result is retained and results are never copied to sibling variants. This existing field retains the dated **v1.4** snapshot. AA's current **v1.5** has different benchmark components and is collected separately at `data/raw/aa-coding-agents-v1.5.json`; it does not replace the Composite input.
- `composite` uses five slots: AA Coding, source-matched AA Coding Agent, AA Intelligence, DesignArena Frontend and DesignArena Full-Stack. AA values are clamped to 0–100. Each DesignArena board needs at least 200 battles and is converted from Elo to its expected score against a fixed Elo 1000 opponent: `100 / (1 + 10^((1000 − Elo) / 400))`. Each observed slot is percentile-normalized over the current catalog's unique observed values. Every missing slot is assigned that model's mean observed percentile, making `composite_base` exactly the arithmetic mean of its available percentiles. With no reliable observed slot the fallback is 50; this fallback is not treated as benchmark evidence for family-representative selection. The returned `composite` adds a deterministic least-squares projection: if a model covers all reliable slots of another measured model and is no worse in each, the final scores preserve that dominance with a 0.1-point margin. `composite_base` exposes the pre-projection value. Family-scoped Intelligence.ai results attach exactly once to the deterministic collapsed-view representative and are labeled with `designarena_attachment_note`.
- Offer-level `eu_hosted` says that this specific model offer is served from an audited EU location. `eu_policy_equivalent` is a separate company-specific classification that makes an offer eligible for the product&apos;s EU filter without asserting technical EU residency; it is currently set only on Azure Direct Global DeepSeek V4 Pro and Kimi K2.7 Code, whose inference may occur outside the EU. Provider-level `eu_hosted` only says the provider has at least some EU-hosted capacity; it must not be used by itself to infer residency for every offer.

## Consumer update — 2026-09-08

At this September 8 release, the reference host became `https://model-market-comparison.app.mintapis.com`;
it remains valid alongside the new primary host announced above.
the former Render host is suspended. All route paths remain unchanged.
The reference deployment serves **bundled JSON**, with no runtime database.
No database migration or credentials are needed to consume the public feed.

Prefer `GET /api/dataset` or the Git-tracked `data/dataset.json` for ingestion.
Use `GET /api/models?score=composite` for computed scores (Composite is computed
by app code, not stored as a scalar in the raw dataset). Check **each** date in
`sources`; `generated_at` only proves that a build ran, not that every source refreshed.
The daily job refreshes AA, AA Coding Agents, OpenRouter and DesignArena; curated
provider snapshots have separate audit dates. Do not assume every source refreshes daily.

Additive fields under each AA-backed model's `aa_metadata`:
`available` (boolean), `is_open_weights` and `deprecated` (boolean or null).
During a small upstream publication lag, benchmark rows are retained with null
metadata. Existing top-level booleans remain compatible: `open_weights:false`
means open weights are not established, and `deprecated:false` means not known
retired. Inspect the nullable fields to distinguish unknown from confirmed false.
Do not infer an open license from a lab name.

Exact model IDs and effort variants remain distinct. In particular, scores for
`qwen3.8-max` must not be copied to `qwen3.8-max-0902`, whose current evidence
is pricing only. Nullable direct Azure Astra prices are not zero; OpenRouter's
Azure offers are separate priced routes.

See [CHANGELOG.md](CHANGELOG.md) and [September audit](data/research/refresh-2026-09-08.md).

### Phase 01 additions (2026-09-10)

Existing URLs, file paths and score meanings remain unchanged. `sources.aa_coding_agents`
is the actual last collection date of the retained v1.4 snapshot, not today's date.
`sources.aa_coding_agents_v1_5` tracks the newly collected version. `source_status`
explains this separation. The v1.5 raw rows carry exact source IDs, components and
provenance; they will enter versioned benchmark views in phases 04–06.

`models[].aa_metadata.retained_fields` records `source`, `collected_at` and `reason`
for each metadata field retained from an older AA publication after the current
leaderboard stopped providing it. A snapshot refresh does not advance those field dates.

### Phase 02 additions — token and caching evidence (2026-09-10)

**All existing URLs, files, fields, prices and Composite inputs retain their meanings.**
Read the additions from `GET /api/dataset` or `data/dataset.json`. The full model
returned by `/api/models/{id}` includes `token_efficiency`; the compact `/api/models`
listing keeps its existing shape. Adjusted-cost computation/UI is a later phase.

An observation has `{ value, source, url, collected_at, basis }`. `value` can be a
number or the documented token-count object. `basis` is `measured` (AA benchmarks
or OpenRouter workload telemetry), `self_reported` (Chutes' own counters or catalog
prices), `derived` (explicit arithmetic), or `assumed` (applying a global workload
ratio to a different model). `source_basis` records the input classification for
derived/assumed values. Missing observations are **null**, never zero.

| JSON path | Meaning |
|---|---|
| `models[].token_efficiency.aa.tokens_per_task.value` | AA `intelligenceIndexOutputTokensPerTask`: `{ reasoning, answer, output }`, output tokens per Intelligence Index task for the exact AA UUID/effort. |
| `models[].token_efficiency.aa.canonical_token_counts.value` | AA `canonicalIntelligenceIndexTokenCount`: `{ input, output, answer, reasoning }`, totals over its canonical benchmark run. |
| `models[].token_efficiency.aa.benchmark_input_output_ratio` | Canonical input/output quotient, explicitly `interpretation: benchmark_proxy`. It is not observed user usage and is not the workload fallback. |
| `models[].token_efficiency.input_output_ratio` | Preferred empirical OpenRouter workload ratio, otherwise the Chutes global fallback. Includes `fallback`, `scope`, `window`, and a `fallback_reason`/`evidence_ref` when assumed. |
| `models[].token_efficiency.attempts` | Source attempts/outcomes, including missing API usage fields, exact-ID gaps, uncollected pages, incomplete windows and fallback evidence. Null attempt dates mean no fetch occurred. |
| `efficiency.global_io_ratio` | Chutes ratio plus source totals, seven completed UTC dates, cohort selection and returned/included/excluded-row coverage. |
| `efficiency.openrouter_endpoints[or_model_id][endpoint_tag]` | Exact pair registry: provider name, endpoint UUID when verified, cache-hit observation and cache read/write price observations. |
| `efficiency.aa_unmatched.value` | Collected AA rows whose UUID is not yet in the model catalog. Kept with provenance; never attached to a similarly named model. |
| `efficiency.coverage` | Explicit model/pair denominators and coverage counts. `schema_version` is 1. |

Workload selection uses exact published OpenRouter IDs or an unambiguous sole
offered SKU. Model pages provide `appStats.state.data.model_chart`; weekly rankings
extend coverage through an **exact canonical-slug join**, with `:free` kept separate.
Both use `sum(total_prompt_tokens) / sum(total_completion_tokens)`. The seven-day
page window excludes today; incomplete windows remain unavailable. These statistics
cover all apps/effort configurations on that SKU, not an isolated coding-agent cohort.
No family-name join or AA benchmark ratio substitutes for workload observations.

The Chutes ratio uses token-positive chute/day rows from `/invocations/stats/llm`
over the previous seven completed UTC days, including published anonymized aggregates.
It sums input and output independently, rather than averaging ratios. Raw counters
are self-reported; the global quotient is derived; its assignment to another model
is assumed. This is general Chutes traffic, not a coding-agent-only sample.

An endpoint entry's `cache_hit_rate.value` is a fraction from 0 to 1, taken from
OpenRouter `providerSummaries[].cacheHitRate`. The source `endpointId` is joined to
the model page's endpoint `id`, then to its exact `provider_slug` routing tag. The
effective-pricing API's **base** `providerSlug` is not an endpoint tag. Display names
such as Fireworks, Fireworks US and Fireworks Fast cannot establish equivalence.
Duplicate tags or identity conflicts get null cache observations and an explicit
status. Missing statistics are sparse coverage, not a zero hit rate.

OpenRouter does not publish the underlying cache-rate numerator/denominator or
the exact summary interval in this response. `summary_window` is null;
`chart_date_range` describes the accompanying chart only. Do not assume it defines
the summary interval. Cache read/write observations use **USD per million tokens**,
converted from the dated public endpoint catalog. Existing offer prices remain
unchanged; page-scraped price observations also remain in the raw snapshot.

New sources: `aa_efficiency`, `openrouter_efficiency`, `chutes_efficiency`.
The OpenRouter source date is the collector run, **not** a claim that every page
was refreshed. Individual dates survive rotation and failed fetches. Workload
observations older than 30 days fall back to Chutes; retained cache observations
and a stale Chutes fallback expose `stale: true` after 30 days. Consumers should
inspect observation dates/status, not just `generated_at`.

```js
const ds = await (await fetch('/api/dataset')).json();
const model = ds.models.find(m => m.id === selectedModelId);
const io = model.token_efficiency.input_output_ratio;
const offer = model.offers.find(o => o.or_model_id && o.endpoint_tag);
const cache = offer && ds.efficiency.openrouter_endpoints[offer.or_model_id]?.[offer.endpoint_tag];
// io.value = input tokens per output token; io.fallback says whether it is assumed.
// cache?.cache_hit_rate?.value is null/absent when unknown, with status explaining why.
```

Raw files: `data/raw/aa-efficiency.json`, `openrouter-efficiency.json`,
`chutes-efficiency.json`. Run `npm run data:efficiency` for independent refreshes.
`fetch-live.mjs aa` also refreshes AA efficiency; `fetch-live.mjs or` refreshes the
weekly ranking, four model pages in rotation and the Chutes fallback. The three
recipes are under `ops/rebuild-2026-09/skills/` for phase-09 installation.

Production continues to use bundled JSON. Optional Postgres installations should
run `node scripts/seed-db.mjs`: its idempotent `dataset_meta.extensions` JSONB
addition preserves the new top-level fields (and existing source-status metadata).
An old seed falls back to the bundled snapshot until reseeded.

### Effective-cost UI (phase 03)

The UI now defaults to modeled **USD/task**. Raw API `input_per_1m`, `output_per_1m` and cache fields retain their existing USD/million units and paths; no raw field was renamed or silently converted. Consumers can import the pure `effectiveCost` / `fixedCost` functions from `lib/effective-cost.mjs`. `effective_cost_per_task` and `effective_cost_per_1m_tokens` are separate return fields, with resolved inputs, dollar terms and explicit assumptions. See [effective-cost policy](docs/effective-cost.md) for all fallbacks and workload limitations. The UI settings key is now `mmc.settings.v6`; adjusted costs and the retained fixed-blend alternatives are global and persisted.

### Benchmark exploration (phase 06)

The canonical dataset/benchmark endpoints keep their existing fields. `GET /api/benchmark-scores` additionally accepts `observation_id` for exact row lookup, composable with `benchmark_id`, `model_id` and pagination.

`GET /api/benchmark-view?model=<id>` (repeat up to four) supplies a bounded UI projection with versioned axes, sources and fixed catalog peer statistics. `?axis=<id>` instead selects one published evaluation group including unmatched source identities. These presentation IDs include version, unit and harness/configuration and may change if source protocol metadata changes; use registry IDs and observation IDs from the canonical APIs for integrations. The view is additive and never changes Composite. See [explorer methodology](docs/benchmark-explorer.md).

FILE CHANGELOG.md
# Changelog

For downstream consumers (forks, apps syncing data from this repo or the live API):
the **data locations have not moved**. What changed recently is the hosting URL and
some app internals — details per release below.

## 2026-09-11 — New domain: Benchmark Heaven at benchmarkheaven.com

- **The product is renamed Benchmark Heaven** (formerly Model Market Comparison).
- **New primary base URL: `https://benchmarkheaven.com`.**
- **The previous base URL `https://model-market-comparison.app.mintapis.com` remains
  valid as a compatibility URL and serves the same endpoints and dataset.** No consumer
  migration is required; both hosts stay attached.
- **Nothing else moved:** the GitHub repo, repo file paths, JSON schema, model/offer/
  benchmark IDs, units, the Composite definition and settings storage keys are unchanged. Browser preferences are per origin, so
  saved filters/theme on the old hostname are not transferred to the new hostname.
- The fetch scripts' HTTP User-Agent now identifies the collector as Benchmark Heaven;
  the contacted GitHub project URL inside it is unchanged.
- New Observatory mark, favicon, touch icon, light/dark identity, serif display typography,
  social card, metadata, README header, and branded fork-sync/Telegram templates.
- Older entries below keep the previously correct hostnames as their historical record.

## 2026-09-10 — Phase 04: benchmark discovery

- Added a versioned benchmark registry with verified publication routes, scoring semantics,
  provenance and an exclusion ledger, including public and independent writing/RP boards.
- Retained AA's previously discarded benchmark fields as raw observations with a fail-closed
  extractor. Coding Agent Index v1.4 and v1.5 remain separate; the legacy date is unchanged.
- Dataset builds validate registry evidence. Public API scores and Composite inputs are unchanged.

## 2026-09-10 — Phase 03: effective task costs

- Comparisons default to modeled USD/task, combining exact-variant task tokens, usage I/O and exact-endpoint cache statistics, with every fallback explained.
- Raw list prices and six fixed I/O scenarios remain selectable; settings move to `mmc.settings.v6`.
- The explorer starts at cheapest adjusted cost and measured task-token data; minimum benchmark scores make the cost/capability question directly filterable.
- Every selected price has a keyboard/touch explainer; charts and averages expose their constituent prices.
- Retired a Sol override that mixed first-party list rates with OpenRouter cached rates. Raw API units and data paths remain unchanged. See [cost policy and five-model checks](docs/effective-cost.md).

## Where to find the data (canonical, stable)

- **In the repo** (updated ~daily by an automated refresh commit to `main`):
  - `data/dataset.json` — the full built dataset (models, families, offers, scores, sources).
  - `data/raw/*.json` — per-source snapshots (ArtificialAnalysis, OpenRouter, DesignArena, per-provider catalogs, `manual.json` overrides).
  - `data/gateways.json` — gateway comparison data.
- **Live API** (same JSON shapes as the repo, CORS `*`; see [API.md](API.md)):
  - Base URL: **`https://model-market-comparison.app.mintapis.com`**
  - `GET /api/dataset` · `GET /api/models` · `GET /api/providers` · `GET /api/meta` · `GET /api/health`

## 2026-09-10 — rebuild phase 02

- Add `models[].token_efficiency` with dated AA output-tokens-per-task/canonical benchmark counts and workload I/O evidence. Exact OpenRouter usage takes priority; the Chutes global fallback is explicitly assumed. AA ratios remain benchmark proxies.
- Add `efficiency.openrouter_endpoints[or_model_id][endpoint_tag]` with provider names, exact endpoint identities, cache-hit statistics, dated cache read/write prices and sparse-coverage statuses. Base provider labels never join endpoint telemetry.
- Add explicit coverage, unmatched AA rows, provenance and failed/uncollected-attempt records. Preserve all historical metadata field dates, existing prices, score meanings, URLs and file locations.
- Add three atomic collectors, parser/identity/failure tests and reusable collection skills. Daily refresh gains AA efficiency, one weekly OpenRouter ranking plus four model pages in rotation, and seven completed days of Chutes aggregate usage.
- Optional Postgres seeding adds `dataset_meta.extensions` to retain additive metadata; production continues to serve bundled JSON. See [API.md](API.md#phase-02-additions--token-and-caching-evidence-2026-09-10) for the full schema. Adjusted costs and UI follow in subsequent phases.

## 2026-09-10 — rebuild phase 01

- Repair AA metadata parsing for slug-based Flight records and retain historical identifiers/licensing with their original per-field source dates. Refresh AA, OpenRouter and DesignArena; restore all 68 v1.4 Coding Agent rows.
- AA changed the Coding Agent benchmark to v1.5. Collect it into `data/raw/aa-coding-agents-v1.5.json` with strict validation and atomic writes. Preserve the existing Composite and v1.4 collection date; explain the separation in `/about` and `source_status`.
- Track daily runner/prompt in `ops/daily/`; use the tested collector and subscription-only Codex auth. No data URLs or existing score fields moved.

## 2026-09-08

- **New featured models:** GPT-6 Astra, GLM-5.3 Flash, Muse Spark 1.3, Qwen3.8 Max 0902
  (`FEATURED_RE` in `scripts/build-dataset.mjs`).
- Provider catalogs refreshed, including the previously unfinished AWS/Azure/Vertex,
  Claude direct, Copilot and T-Systems checks. AA / DesignArena / OpenRouter /
  Coding-Agent snapshots refreshed. See [audit details](data/research/refresh-2026-09-08.md).
- `scripts/fetch-live.mjs`: the ArtificialAnalysis fetch now tolerates up to 3 API models
  whose leaderboard metadata hasn't rolled out yet (ships them with null metadata instead
  of aborting the refresh). Empty/broken feeds and larger mismatches still fail.
  `aa_metadata.available`, `aa_metadata.is_open_weights` and `aa_metadata.deprecated`
  expose missing metadata; existing top-level booleans stay compatible.
- Cron was active at 05:17 UTC daily; today's failed fetch was the blocker. Its server
  prompt now builds before testing, so production prerender checks use current output.
- **Auto-deploy verified:** GitHub pushes now trigger Coolify via webhook; older
  documentation saying pushes do not deploy was stale. Explicit redeploy is a fallback.
- **No DB/schema migration**: production serves bundled JSON without `DATABASE_URL`.
  Routes and repo file paths are unchanged. Check individual `sources` dates, not
  just `generated_at`. The daily cron refreshes the four live benchmark/router sources;
  manual provider catalogs retain separate audit dates.
- Copilot: 29 current token entries / 19 legacy multiplier entries. Claude direct:
  13 callable models; Opus 4.1 retired, Fable/Mythos 5.1 cache pricing captured,
  cancelled Sonnet 5 price increase removed.
- Azure Astra is documented but direct prices remain null until a named Retail meter
  is published. OpenRouter Azure prices remain separate. Qwen3.8 Max 0902 has prices
  but no exact benchmark yet; no score copied from bare Qwen3.8 Max.

## 2026-08-26

- **Hosting/base URL changed:** the reference deployment moved from Render
  (`model-market-comparison.onrender.com`, suspended 2026-08-25) to
  **`https://model-market-comparison.app.mintapis.com`** (Sandy/Coolify). All API routes
  and JSON shapes are unchanged — only the host is new. See [DEPLOYMENT.md](DEPLOYMENT.md).
- **Filters removed:** the "Hide GPT-5.5 / Opus 4.8" and "Hide Fable" global toggles are
  gone; `isHiddenModel` no longer exists in `lib/cost.ts`. Persisted settings key bumped
  `mmc.settings.v4` → **`mmc.settings.v5`**.
- Deep catalog audit (AWS Bedrock EU-Geo Claude prices corrected, FX refresh, delistings);
  featured-set regex hardened with `(?!-)` lookaheads; `scripts/top5.mjs` added
  (top-5-by-Composite snapshot used by the daily refresh notifier).

## Earlier

The daily data-refresh commits ("Refresh …") only touch `data/` (and occasionally test
pins) and never change API routes or file locations. For app-level history before this
file existed, see `git log`.

## 2026-09-11 — Phase 06 benchmark explorer

- Added `/benchmarks` rankings, a standalone `/radar`, and up to four exact configurations on `/compare`, with source scales, versioned evaluation groups, selectable axes and explicit sparse coverage.
- Added complete per-model benchmark sheets, conservative explainable profile signals, and protocol-compatible divergence displays.
- Revamped navigation, light/dark themes, keyboard focus and disclosures; retained adjusted-cost and provider comparisons. Coding Agent v1.4 and its September 9 Composite source remain unchanged; v1.5 is separately visible.
- Added the compact benchmark presentation endpoint and exact observation lookup; canonical source/dataset fields and paths remain compatible. No benchmark value was changed or invented.

- Phase 06 release follow-up: update Next.js to 15.5.25 and compatible PostCSS 8 resolution; clean npm audit reports no remaining findings. Benchmark data and Composite definitions are unchanged.

FILE DEPLOYMENT.md
# Deployment & migration guide

This app is intentionally **portable**: it's a standard Next.js (App Router) Node service with one optional Postgres database. It runs anywhere that can run Node 20 + (optionally) Postgres — Render, Vercel, Azure, AWS, a plain VM, Docker, etc.

## Required secrets / environment variables

There is **exactly one runtime secret**, and even that is optional:

| Variable | Needed for | Required? | Notes |
|---|---|---|---|
| `DATABASE_URL` | Runtime DB-backed data | **Optional** | Postgres connection string. **If unset, the app serves the committed `data/dataset.json` snapshot** and runs fully without a database. SSL is auto-enabled for non-localhost hosts. |
| `ARTIFICIAL_ANALYSIS_API_KEY` | The data refresh (`npm run data:fetch`) only | Build/ops only | **Not used at runtime.** Only needed if you re-pull ArtificialAnalysis data. Header `x-api-key`. |
| `PORT` | Serving | Provided by host | `npm start` binds `next start -p ${PORT:-3000}`. |
| `NODE_VERSION` | Build | Recommended | Set to `20`. |
| `FORCE_SEED` | Re-seeding | Optional | `=1` forces `db:seed` to re-load even if the snapshot is unchanged. |

**No keys are required for the other data sources** — OpenRouter, DesignArena, AWS Bedrock (Price List API), Azure (Retail Prices API), Google Vertex, Nebius and Inceptron are all scraped from public/unauthenticated endpoints (see [data/SCRAPING.md](data/SCRAPING.md)).

So to host the app you need **nothing secret** for a snapshot-only deployment, and only `DATABASE_URL` to back it with Postgres. To refresh data you additionally need `ARTIFICIAL_ANALYSIS_API_KEY`.

## Build & run

```bash
npm install
npm run build
npm start            # serves on $PORT (default 3000)
```

## Database (optional)

The schema is created and seeded by `scripts/seed-db.mjs` from `data/dataset.json`:

```bash
export DATABASE_URL=postgres://user:pass@host/db
npm run db:seed       # creates tables + loads the snapshot (idempotent)
```

The app reads Postgres when `DATABASE_URL` is set and falls back to the bundled snapshot otherwise. On the former Render deployment `npm run db:seed` runs as the pre-deploy command, followed by `npm start`, so the new snapshot is loaded before traffic moves to the release.

## Refreshing the data

```bash
export ARTIFICIAL_ANALYSIS_API_KEY=aa_…
npm run data:refresh   # fetch live (AA + DesignArena + OpenRouter) → rebuild dataset.json
npm run db:seed        # (if using Postgres) reload it
```
Provider catalogs (AWS/Azure/Vertex/Nebius/Inceptron) remain curated — see [data/SCRAPING.md](data/SCRAPING.md). Collect AA Coding Agent v1.5 with `node scripts/fetch-aa-coding-agents.mjs`; v1.4 stays dated and separate for Composite. The daily wrapper and prompt are tracked in `ops/daily/` and installed at `/opt/mmc-daily/`.

## Current deployment (Sandy / Coolify)

Since 2026-08-26 the reference instance runs on Florian's private Sandy PaaS (Coolify on the Hetzner server) at
`https://benchmarkheaven.com` (since 2026-09-11; also `https://www.benchmarkheaven.com`).
The compatibility URL `https://model-market-comparison.app.mintapis.com` remains valid. The app is built from this repo's `Dockerfile` in snapshot mode (no `DATABASE_URL`).
The Coolify health check is disabled because `node:20-slim` ships neither `curl` nor `wget`. A GitHub webhook is now active (verified from Coolify deployment history on 2026-09-08):
pushes to `main` auto-deploy. The daily refresh cron on the server (`/opt/mmc-daily/run.sh`,
Codex CLI, 05:17 UTC) pulls, refreshes the data and pushes. Its explicit redeploy helper
(`/opt/mmc-daily/redeploy.sh`) remains a fallback if the pushed snapshot does not become live;
do not queue a second build while a webhook deployment is already progressing.
The former Render instance (`model-market-comparison.onrender.com`) was suspended by Render on 2026-08-25 (free-tier usage exceeded).

## Alternative: Render Blueprint

`render.yaml` provisions a Node web service + managed Postgres:
- Build: `npm install && npm run build`
- Pre-deploy: `npm run db:seed`
- Start: `npm start`
- `DATABASE_URL` wired from the managed DB; `healthCheckPath: /api/health`.

## Hosting on Microsoft Azure

The same artifact maps cleanly onto Azure:
- **Azure App Service** (Linux, Node 20) or **Azure Container Apps** (build the included Dockerfile) for the web service.
- **Azure Database for PostgreSQL – Flexible Server** for `DATABASE_URL` (enable SSL; the client already sends `ssl: { rejectUnauthorized: false }` for non-localhost).
- App settings: `DATABASE_URL`, `NODE_VERSION=20`, optionally `ARTIFICIAL_ANALYSIS_API_KEY`.
- Run `npm run db:seed` once (or as a startup/release step) to load the snapshot.
- No other cloud services are required.

## Public read-only API

All `/api/*` routes are CORS-enabled read-only JSON (incl. `/api/dataset` for the full export). See [API.md](API.md). This means a deployment can also serve as a **public data API** for this dataset.

## Daily refresh recovery (2026-09-08)

The server cron is enabled at `17 5 * * *` (05:17 UTC; 07:17 Berlin during summer).
Its run on September 8 stopped at an AA metadata mismatch; see the source-fetch
fix in `lib/aa-metadata.mjs`. Before pulling a recovery commit, preserve any failed
run's uncommitted snapshots (`git stash push` or an external backup), then use
`git pull --ff-only`. Do not discard or force-push them. Build before testing:
`npm run data:build && npm run build && npm test`. Deploy only a passing revision.
The server prompt must include the production build because prerender tests inspect
`.next/prerender-manifest.json`. Logs and summary: `/opt/mmc-daily/cron.log`,
`/opt/mmc-daily/last-summary.txt`. Neither a healthy cron daemon nor a fresh
`generated_at` proves the update reached production: verify `/api/meta` source dates
and compare `/api/dataset` with the committed snapshot after deployment.

## Benchmark Heaven domain configuration (2026-09-11)

Namecheap Advanced DNS has A records for `@` and `www`, both pointing to `65.109.49.103` (TTL 30 minutes). The former parking CNAME/URL redirect were replaced; mail records were preserved. Coolify application `ggbs6upie6tqsousmrkw0vja` keeps all three HTTPS domains, with the same container port 3000 and automatic certificates. No GitHub repository, route, data file, schema, ID, unit, Composite input or settings key moved.

Verify each hostname with normal TLS validation and compare `/api/dataset` against the committed snapshot. Certificate and release receipts live in `ops/rebuild-2026-09/evidence/phase-07/`. A successful deployment alone is not a certificate check.

FILE PRD.md
# PRD — Benchmark Heaven

## 1. Problem & goal

Pricing for LLMs is scattered across inference marketplaces (OpenRouter), the
hyperscalers (AWS Bedrock, Azure AI Foundry), IDE bundles (GitHub Copilot), and
first-party APIs (Anthropic / Claude Code). Capability lives in yet other places
(ArtificialAnalysis, DesignArena). Nobody can answer "which model gives me the most
capability per dollar, and who is the cheapest place to run it?" in one view.

**Goal:** a single web app that, for open-source and frontier LLMs, shows capability
(benchmark scores) next to price (across every provider), and ranks models by value.

## 2. Users & key questions

- *"For coding, what's the best model I can afford?"* → sort by AA Coding Index, read cost.
- *"I picked model X — who runs it cheapest?"* → top-5 cheapest providers per model.
- *"Open weights vs the closed frontier — how big is the price/quality gap?"* → charts.
- *"How expensive is this model inside GitHub Copilot or AWS Bedrock specifically?"* → model detail.

## 3. Data sources (see `data/SCRAPING.md`)

| Source | What it provides | Access |
|---|---|---|
| OpenRouter | Model catalog + per-provider token prices | Live API |
| ArtificialAnalysis | Coding, Coding Agent and Intelligence indices, sub-benchmarks | Live API + public leaderboard payload |
| Intelligence.ai / DesignArena | Agentic Web Dev Frontend & Full-Stack Elo | Live API (POST) |
| AWS Bedrock | On-demand token prices, EU regions | Price List API + page |
| Azure AI Foundry | Token prices and per-model serving scope | Retail Prices API + model docs |
| Google Vertex AI | Gemini and Model Garden partner-model prices/locations | Pricing + location docs |
| Direct APIs | Nebius, Inceptron, TensorX, Scaleway, IONOS, Mistral, Chutes, OVHcloud, STACKIT, T-Systems LLM Hub | Catalog/pricing APIs and docs |
| GitHub Copilot | Current AI-Credit token catalog + legacy Pro/Pro+ request multipliers | Billing/model docs |
| Anthropic / Claude Code | All currently callable API models, promotions and Enterprise terms | Official pricing/lifecycle docs |

## 4. Functional requirements

1. **Model overview** — table of models with a **selectable score** (AA Coding,
   model-mean-imputed percentile Composite, AA Coding, AA Coding Agent, AA Intelligence,
   DesignArena Frontend, DesignArena Full-Stack), the cheapest
   10:1 blended cost, and the top providers. Filter by featured / open-weights /
   org / search; hide deprecated model rows by default; sort by score, cost, name, org.
2. **Cheapest providers per model** — model detail lists the **top-5 cheapest
   providers** (10:1 blended) plus all token offers grouped by platform.
3. **Cost vs Capability scatter** — x = cost (cheapest 10:1 blended $/1M), y =
   selected capability score; colored by org; log-cost toggle; click → detail.
   *Best value = upper-right* because the displayed cost axis is inverted.
4. **Charts** — capability leaderboard, cheapest-model ranking, open-vs-closed
   comparisons (avg capability and avg cost).
5. **Providers** — every provider/platform and how many model families it prices.
6. **Featured models** (brief): GPT-5.6 Sol/Terra/Luna, GPT-5.5 / GPT-5.4 (+ Mini,
   reasoning settings), Opus 4.8/4.7/4.6, Sonnet 4.6/5, Fable 5, Kimi K2.5/K2.6/K2.7-Coding, GLM 5.1/5.2,
   MiniMax M2.5/M2.7/M3, MiMo-V2.5-Pro, DeepSeek V4 Pro.
7. **Backend + DB** — Postgres is the source of truth (seeded from `dataset.json`);
   the app falls back to the bundled snapshot when no DB is configured. JSON API at
   `/api/models`, `/api/models/[id]`, `/api/providers`, `/api/meta`, `/api/health`.

## 5. Non-goals

- Real-time per-request billing or usage metering.
- Estimating a user's actual Copilot request token count or included-credit burn (published unit rates are shown on their own axis).
- Authentication — the data is public; the app is read-only.

## 6. Pricing methodology

- All token prices normalized to **USD per 1M tokens**, input and output separately.
- **10:1 blended cost** = `(10·input + 1·output) / 11`, approximating a read-heavy
  workload (the brief's "10:1 input/output token mix"). The cost axis uses each
  model's cheapest such offer across all providers.
- EU residency is determined per model offer and serving location. Provider capability,
  resource/billing region, or a global endpoint is not sufficient evidence of EU hosting.
  A separate company-policy overlay treats only Azure Direct Global DeepSeek V4 Pro and
  Kimi K2.7 Code as EU-filter equivalents; their technical region remains Global and inference
  may occur outside the EU.
- The Composite uses five capability slots: AA Coding, source-matched
  AA Coding Agent, AA Intelligence, DesignArena Frontend and DesignArena Full-Stack.
  AA values are clamped to 0–100. DesignArena boards require at least 200 battles and
  their Elo is converted to the expected score against a fixed Elo 1000 opponent.
  Every observed slot is percentile-normalized across the current catalog's unique
  observed values. Every missing slot inherits that model's mean observed percentile;
  equivalently, the base Composite is the arithmetic mean of its available percentiles.
  With no reliable observed slot the fallback is 50, while evidence coverage remains
  zero and is tracked separately. A deterministic least-squares projection then makes the
  smallest symmetric adjustment required to preserve strict evidence-superset dominance
  (at least one observed slot, 0.1-point visible margin). Base and adjustment remain visible.
  Family-scoped Intelligence.ai / DesignArena results attach exactly once to the deterministic
  active representative used by collapsed views and carry explicit effort-scope provenance.
- Current GitHub Copilot billing uses published model token rates converted to AI
  Credits at $0.01/credit. The old `multiplier × $0.04` request calculation is shown
  separately and labeled legacy annual Pro/Pro+ only; neither is mixed into API-provider cost rankings.

## 7. Architecture

Next.js (App Router, TypeScript) single service on Render + managed Postgres.
Data pipeline: `fetch-live.mjs` → `build-dataset.mjs` → `dataset.json` →
`seed-db.mjs` → Postgres. Charts via Recharts. See `README.md` and `data/SCHEMA.md`.

## 8. Caveats

Figures can go stale and naming is normalized heuristically across sources; the app
is informational and not affiliated with any provider. GLM 5.2 and other just-released
models may carry estimated or pending pricing (flagged in the UI and `data/raw/manual.json`).

FILE MSG-SPINOFF-STARTER-PROMPT.md
# Starter prompt — msg-branded spin-off

Copy the prompt below into a fresh **Claude Code** session running inside msg's
environment (with the copied source as the working directory). It bootstraps the
re-branded, msg-hosted fork.

---

You are setting up an **msg systems ag–branded fork** of an existing open-source-LLM
price/benchmark comparison web app. The original is a Next.js (App Router, TypeScript) +
Postgres app that aggregates LLM prices across many providers and benchmark scores
(ArtificialAnalysis, DesignArena) into one comparable UI plus a public read-only JSON API.
The current working directory contains a copy of that source.

**Read first:** `README.md`, `DEPLOYMENT.md`, `API.md`, `data/SCHEMA.md`, `data/SCRAPING.md`.
Note especially: the only runtime secret is the optional `DATABASE_URL` (the app falls
back to the bundled `data/dataset.json` if absent); `ARTIFICIAL_ANALYSIS_API_KEY` is only
needed to refresh data, not at runtime.

Do this, checking in with me at each milestone:

1. **New repo.** Initialize a fresh git history and create a new **private repo in msg's
   GitHub org** (ask me for the exact org/name and use the `gh` CLI). Push `main`. Keep the
   original MIT/usage notices; add an msg copyright header.

2. **Re-brand to msg's corporate identity.** Apply msg systems ag's official CI — do NOT
   guess colors; pull them from msg's brand portal / design system (ask me for the brand
   guide or a link if you don't have it). Concretely:
   - Replace product name/title/metadata ("Benchmark Heaven" → the msg product name
     I give you) in `app/layout.tsx`, `components/Nav.tsx`, `app/icon.svg`, README.
     msg's brand color is its signature red — confirm the exact hex with me.
   - Update the theme tokens in `tailwind.config.ts` (`ink`, `panel`, `line`, `accent`,
     `accent2`, `warn`) and `app/globals.css` to msg's palette; swap the logo/favicon
     (`app/icon.svg`) for the msg logo; set msg's brand font.
   - Re-skin the org/vendor color palette in `lib/format.ts` only if it clashes with msg CI
     (keep vendor colors distinguishable).
   - Add an msg footer / "internal tool" disclaimer as appropriate.

3. **Keep all functionality and data.** Don't change the data pipeline, scores, filters,
   or API behavior — this is a re-skin + re-host, not a rewrite. The committed
   `data/dataset.json` works out of the box; `npm install && npm run build && npm start`
   must render with no external dependencies.

4. **Host on msg's Azure.** Follow `DEPLOYMENT.md` → "Hosting on Microsoft Azure":
   - Provision **Azure Database for PostgreSQL – Flexible Server**; set `DATABASE_URL`
     (SSL enabled).
   - Deploy via **Azure Container Apps** using the included `Dockerfile` (preferred), or
     **Azure App Service** (Linux, Node 20). Set app settings `DATABASE_URL`,
     `NODE_VERSION=20`, and (only if data refresh runs here) `ARTIFICIAL_ANALYSIS_API_KEY`.
   - Run `npm run db:seed` once (or as a startup step) to load the snapshot.
   - Wire CI/CD from the msg repo (GitHub Actions → Azure) if I ask for it.

5. **Verify** the deployed site renders, `/api/health` returns `{ok:true, db:true}`, and
   `/api/dataset` returns data. Report the URL.

Constraints: ask me before anything that spends money or creates cloud resources; never
commit secrets; keep changes minimal and on-brand. Start by reading the docs above and
proposing the rebrand checklist + the exact list of files you'll touch.

FILE MSG-UPSTREAM-SYNC-PROMPT.md
# Sync prompt — pull upstream developments into the msg-branded fork

Paste this into the Claude Code session working on the **msg-branded fork** whenever you
want to pull the latest data + features from the original project (new providers like
**TensorX**, new models like **Claude Sonnet 5**, new tabs, filter fixes, price/score
refreshes). The upstream repo is public.

---

You maintain an **msg-branded fork** of the open-source "Benchmark Heaven" app (formerly "Model Market Comparison"). The
original ("upstream") lives at **https://github.com/fstandhartinger/model-market-comparison**
(public). I want you to pull upstream's latest **data and feature developments** into our
fork **without losing our msg branding** (colours, logo, product name, fonts, footer, repo,
Azure hosting).

Brand change to know about (2026-09-11): upstream is now the **Benchmark Heaven**
product with primary base URL **https://benchmarkheaven.com**; the previous base URL
https://model-market-comparison.app.mintapis.com **remains valid** with identical
endpoints. Upstream gained brand assets and metadata for the new name/wordmark (e.g.
files under `public/brand/` such as `wordmark.svg`, updated `app/layout.tsx` metadata,
README header/branding). These are **branding, not data or logic**: keep OURS (msg
branding) for all of them. Preserve the new upstream brand assets/metadata **only as
needed** to understand their structure or resolve conflicts; never let them overwrite
our product name, colours, logo, fonts, footer or metadata, and never let branding
resolution overwrite functional logic.

Earlier upstream changes (2026-09-08): a **CHANGELOG.md** now exists
at the repo root summarising exactly this kind of change — read it first on every sync.
Highlights since your last sync: the reference deployment moved from Render to
**https://model-market-comparison.app.mintapis.com** (all `/api/*` routes and JSON shapes
unchanged — update any hardcoded onrender.com base URL); the "Hide GPT-5.5 / Opus 4.8"
and "Hide Fable" toggles were **removed** (`isHiddenModel` is gone, settings storage key
is now `mmc.settings.v5`); new featured frontier models (GPT-6 Astra, Claude Opus 5 /
Fable 5, Kimi K3, GLM-5.3 + Flash, Grok 4.6, Qwen3.8 Max, Muse Spark 1.2/1.3, MiniMax M3,
DeepSeek V4 Pro); all provider catalogs re-audited (AWS Bedrock EU-Geo Claude prices
corrected, FX refreshes, delistings); `scripts/top5.mjs` added; the AA fetch in
`scripts/fetch-live.mjs` tolerates mid-rollout metadata gaps. Data still lives in
`data/dataset.json` + `data/raw/*.json`, refreshed by a daily automated commit to `main`.

Do this:

1. **Add upstream + fetch.**
   ```bash
   git remote add upstream https://github.com/fstandhartinger/model-market-comparison.git 2>/dev/null || true
   git fetch upstream
   git log --oneline HEAD..upstream/main    # review what's new since our fork
   ```

2. **Merge, preferring OUR branding but THEIR data + logic.** Create a branch, then
   `git merge upstream/main`. Resolve conflicts on this rule:
   - **Keep OURS (msg branding)** for: `app/layout.tsx` (title/metadata), `components/Nav.tsx`
     (product name/labels), `app/icon.svg`, `tailwind.config.ts` + `app/globals.css` (theme
     tokens/palette/fonts), any msg footer/disclaimer, `README.md` header, any new upstream
     brand assets/metadata introduced by the Benchmark Heaven rename (e.g. `public/brand/`,
     wordmark/og assets, `components/BrandMark.tsx`, `app/apple-icon.png`, `app/manifest.ts`), and CI/Azure config.
   - **Take THEIRS (upstream)** for everything else — especially **all of `data/`**
     (`data/raw/*.json`, `data/dataset.json`, `data/gateways.json`), `scripts/build-dataset.mjs`,
     `lib/`, and any new/changed files under `app/` and `components/` that are functional
     (new tabs, filter logic, API routes). When unsure and it's not a branding file, take theirs.
   - If a conflict mixes branding + logic in one file, hand-merge: keep our visual tokens,
     take their behavior.

3. **If the merge is too tangled, do a data-first sync instead** (fast path — data changes
   are the bulk of upstream churn and are branding-free):
   ```bash
   git checkout upstream/main -- data/ scripts/build-dataset.mjs lib/ data/gateways.json
   ```
   Then manually re-apply any *new-tab / new-component* files from `git diff HEAD..upstream/main --stat`
   (e.g. `app/gateways/`, `app/provider-explorer/`, `components/GatewaysView.tsx`,
   `components/ProviderExplorer.tsx`) and the small settings/filter changes in
   `components/SettingsContext.tsx`, `components/GlobalFilters.tsx`, `components/ui.tsx`,
   `lib/cost.ts`. Re-skin any new UI to msg's palette before shipping.

4. **Rebuild + verify locally.**
   ```bash
   npm install
   npm run data:build     # regenerates data/dataset.json from the merged raw snapshots
   npm test               # must stay green (5 passing)
   npm run build
   npm start              # spot-check: TensorX + Sonnet 5 appear; Gateways & Provider-explorer tabs load
   ```
   Confirm via the API: `/api/meta` shows the new source dates; `/api/dataset` contains
   `claude-sonnet-5` and a `TensorX` provider (`eu_hosted: true`).

5. **Re-seed + redeploy on msg's Azure** (per our DEPLOYMENT.md): run `npm run db:seed`
   against the msg `DATABASE_URL`, then deploy the container/App Service. Verify the live
   msg site renders the new data and `/api/health` returns `{ok:true, db:true}`.

6. **Report** what you merged (commit range), any conflicts you resolved and how, and the
   live msg URL. Do NOT push msg secrets; keep our branding intact.

Notes:
- Upstream prices/scores refresh often — re-running this sync periodically is expected; the
  `git remote add` only needs doing once.
- The provider filter now persists under localStorage key `mmc.settings.v3` (blocklist
  semantics) — that's intentional; don't revert it to an older key.
- Upstream is USD-priced and EU-focused; keep that intact (msg's EU/data-residency angle
  aligns with it).

FILE ops/daily/run.sh
#!/bin/bash
# Daily Benchmark Heaven refresh driven by Codex CLI (headless). Cron-safe:
# loads secrets itself, runs fully non-interactive, no windows, logs to cron.log.
set -u
# The root cron delegates to the subscription-authenticated account before loading secrets.
if [ "$(id -u)" = 0 ]; then exec runuser -u flori -- bash "$0"; fi
LOG=/opt/mmc-daily/cron.log
exec >> "$LOG" 2>&1
echo "=== $(date -u '+%F %T') UTC start ==="
for f in "$HOME/.config/dev-secrets.env" /root/.config/dev-secrets.env; do
  [ -r "$f" ] && . "$f" && break
done
[ -f /etc/profile.d/telegram.sh ] && . /etc/profile.d/telegram.sh
export ARTIFICIAL_ANALYSIS_API_KEY="${ARTIFICIAL_ANALYSIS_API_KEY:-${ARTIF_ANALYSIS_API_KEY:-}}"
export RENDER_API_KEY TG_BOT_TOKEN TG_CHAT_ID
export PATH="$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin"
# Codex must bill against the ChatGPT Pro subscription, not an API key.
unset OPENAI_API_KEY OPENAI_BASE_URL
case "$(codex login status 2>&1 | head -1)" in
  *ChatGPT*) : ;;
  *) echo "ABORT: codex not on ChatGPT subscription"; exit 1 ;;
esac
cd /opt/model-market-comparison || exit 1
AUTH="$(codex login status 2>&1)"
case "$AUTH" in
  *ChatGPT*) ;;
  *) printf 'STATUS: problem\nCodex auth is not ChatGPT; refusing API billing.\n' > /opt/mmc-daily/last-summary.txt; exit 1 ;;
esac
timeout 45m codex exec -m gpt-5.6-sol --dangerously-bypass-approvals-and-sandbox -C /opt/model-market-comparison "$(cat /opt/mmc-daily/prompt.md)"
rc=$?
echo "=== $(date -u '+%F %T') UTC end rc=$rc ==="
# --- Notification policy: quiet by default. Telegram only when
#  (a) a new family enters the top 5 by Composite (state in top5-state.json), or
#  (b) the refresh failed — at most once per 7 days (failure-alert.stamp).
python3 - "$rc" << 'PY'
import os, sys, json, subprocess, time, urllib.request
rc = int(sys.argv[1]); D = '/opt/mmc-daily'
def tg(text):
    t, c = os.environ.get('TG_BOT_TOKEN'), os.environ.get('TG_CHAT_ID')
    if not (t and c): return
    req = urllib.request.Request(f'https://api.telegram.org/bot{t}/sendMessage', data=json.dumps({'chat_id': c, 'text': text}).encode(), headers={'Content-Type': 'application/json'})
    urllib.request.urlopen(req, timeout=30).read()
summary = open(f'{D}/last-summary.txt').read().strip() if os.path.exists(f'{D}/last-summary.txt') else ''
problem = rc != 0 or not summary.startswith('STATUS: ok')
# (a) top-5 entrants
try:
    top = json.loads(subprocess.check_output(['node', 'scripts/top5.mjs', '5'], cwd='/opt/model-market-comparison', timeout=120))
    sp = f'{D}/top5-state.json'
    prev = json.load(open(sp)) if os.path.exists(sp) else None
    if prev is not None:
        old = {r['family_key'] for r in prev}
        new = [r for r in top if r['family_key'] not in old]
        if new:
            lines = [f"🏆 Benchmark Heaven: Neu in den Top 5 (Composite): " + ", ".join(f"{r['name']} ({r['composite']})" for r in new), ""]
            lines += [f"{i+1}. {r['name']} — {r['composite']}" for i, r in enumerate(top)]
            lines.append("https://benchmarkheaven.com")
            tg("\n".join(lines)); print('telegram: top5 entrant sent')
        else: print('top5 unchanged: ' + ', '.join(r['family_key'] for r in top))
    else: print('top5 state initialised')
    json.dump(top, open(sp, 'w'), indent=1)
except Exception as e:
    print('top5 check failed:', e); problem = True
# (b) rate-limited failure alert
if problem:
    st = f'{D}/failure-alert.stamp'
    last = os.path.getmtime(st) if os.path.exists(st) else 0
    if time.time() - last > 7 * 86400:
        tg(f"⚠️ Benchmark Heaven Daily-Refresh (Sandy) hat Probleme (rc={rc}). Nächste Warnung frühestens in 7 Tagen. Log: /opt/mmc-daily/cron.log\n\n{summary[:1500]}")
        open(st, 'w').close(); print('telegram: failure alert sent')
    else: print('failure alert suppressed (rate limit)')
PY
# keep log bounded (~2MB)
if [ "$(stat -c%s "$LOG")" -gt 2000000 ]; then
  tail -c 1000000 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
fi
exit "$rc"

FILE ops/daily/prompt.md
You are the daily data-refresh agent for Benchmark Heaven (this repo, /opt/model-market-comparison). Do the full refresh, commit, push, deploy. Work non-interactively; never ask questions. Do NOT send Telegram messages yourself — the wrapper script decides whether anything is worth notifying. Instead, write your final summary to /opt/mmc-daily/last-summary.txt (overwrite; German; max 15 lines: what moved, tests/deploy/freshness status, problems).

Environment variables are already exported: ARTIFICIAL_ANALYSIS_API_KEY, TG_BOT_TOKEN, TG_CHAT_ID. Never print secret values.

STEPS
1. git pull --ff-only origin main (abort and write the reason to /opt/mmc-daily/last-summary.txt if it fails).
2. node scripts/fetch-live.mjs aa && node scripts/fetch-live.mjs da && node scripts/fetch-live.mjs or
   AA also refreshes data/raw/aa-efficiency.json from one full model-page payload. OR also collects four model pages in oldest-attempt rotation (OpenRouter empirical I/O and exact-endpoint cache statistics), then the seven-completed-day Chutes global I/O fallback. These write data/raw/openrouter-efficiency.json and data/raw/chutes-efficiency.json. Do not crawl every OpenRouter model daily. Page observations retain individual dates; sparse or failed attempts are explicit. Source failures that exit nonzero abort publication and preserve the previous good source snapshot. Never treat AA benchmark token ratios as observed user workloads or copy cache rates between provider labels/tags. The standalone recovery command is npm run data:efficiency.
3. Run node scripts/fetch-aa-coding-agents.mjs. It validates the full AA Coding Agent v1.5 board and atomically writes data/raw/aa-coding-agents-v1.5.json. The dated v1.4 snapshot data/raw/aa-coding-agents.json is retained for the unchanged Composite: do not replace it with v1.5, relabel its date, or reimplement the scrape. A failure must abort the refresh and preserve the good snapshot.
3b. Versioned benchmark results use docs/benchmark-ingestion.md and data/raw/benchmarks/collection-plan.json. Reuse the AA model-page capture for extract-aa-benchmark-fields; stage public captures once per source using capture-benchmark-sources.py and collect-public-benchmarks.py --plan CANDIDATE_PLAN CANDIDATE_RESULTS. Preserve exact task/version/split/harness and all immutable source receipts; source access failure must never erase good dated results. The reviewed ingestion-lock binds the AA field snapshot and immutable coding copies. Stage a fresh v1.5 copy and review before changing its lock; never change v1.4. Public results and vendor release/HF/report claims require actual primary evidence, a different-family GAUNTLET critic and owner acceptance; every self-reported observation fingerprint must match score-approvals.json. Every X interaction uses xplainervideo and the existing account/browser gates. Never auto-approve claims, infer missing scores or comparison keys, or relabel stale scores as fresh. Unverified candidates stay outside accepted raw inputs. After accepted updates, run node scripts/ingest-benchmark-scores.mjs and then the normal dataset build. If no review can be completed, retain the prior accepted benchmark snapshot/dates and explicitly report the skipped benchmark refresh. Phase 08 will install the unattended review orchestration; do not invent it here.
4. node scripts/build-dataset.mjs. If it fails with missing provider metadata, verify the provider against a primary source before adding an entry; do not invent a country or residency flag. If unverifiable, report the error and do not push.
5. Override check: GET https://openrouter.ai/api/v1/models/openai/gpt-5.6-luna/endpoints. If the endpoint tagged exactly "openai" now prices at the official standard ($0.20/$1.20 for Luna; sibling Terra $2/$12), remove the offer_overrides entries from data/raw/manual.json and rebuild; if it still shows the flex price ($0.10/$0.60), keep them.
6. npm run build && npm test && npx tsc --noEmit -p . && node --test test/production/prerender.mjs. The production build is required before testing because test/production/prerender.mjs reads .next/prerender-manifest.json; stale manifests are not valid evidence. Fix a failing test ONLY when it pins a benchmark value, price, date floor or catalog presence that legitimately changed upstream (update the pin, add a dated comment like "// <date>: AA re-scored X -> Y"). Anything else: do not touch app code; report it in the summary file instead and skip the commit if the suite is red.
7. If the working tree changed: git add -A; git commit with a concise summary of what actually moved (new models, notable score/price moves, catalog changes), ending with the trailer line: Co-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>. Then git push origin main. Never force-push; on conflict report it in the summary file.
8. Deploy: the app is hosted on this server via Coolify (Render is no longer used). GitHub pushes now trigger an automatic webhook deployment (verified 2026-09-08). The primary public URL is https://benchmarkheaven.com; the previous hostname remains valid. After pushing, poll the compatibility URL https://model-market-comparison.app.mintapis.com/api/dataset with TLS verification and a cache-busting query for up to 10 minutes, comparing generated_at and source dates with the committed snapshot. Do not trigger another deployment while the webhook build is progressing. If the snapshot has not become live, inspect deployment state; only when no deployment is queued/running, use bash /opt/mmc-daily/redeploy.sh as fallback. Report failures rather than queueing duplicate builds. Only deploy if you pushed a new commit.
9. Verify the live /api/dataset with TLS verification: generated_at and all source dates must match the committed snapshot. artificialanalysis/designarena/openrouter/aa_coding_agents_v1_5 must be today; aa_coding_agents remains the explicitly retained v1.4 date, with source_status explaining why. Never require an invented fresh date for the historical source.
   aa_efficiency/openrouter_efficiency/chutes_efficiency must record today's collector run. For rotated OpenRouter pages inspect each observation's collected_at, not just the run date; inspect efficiency.coverage and per-model token_efficiency.attempts for gaps. Preserve metadata.retained_fields and aa_metadata.retained_fields with their original dates.
10. Write the summary file /opt/mmc-daily/last-summary.txt as described above. Its FIRST line must be exactly "STATUS: ok" if everything (fetch, build, tests, push/deploy when there were changes) succeeded, otherwise "STATUS: problem".

FILE ops/daily-refresh-prompt.md
You are the daily data-refresh agent for Benchmark Heaven (this repo, /opt/model-market-comparison). Do the full refresh, commit, push, deploy. Work non-interactively; never ask questions. Do NOT send Telegram messages yourself — the wrapper script decides whether anything is worth notifying. Instead, write your final summary to /opt/mmc-daily/last-summary.txt (overwrite; German; max 15 lines: what moved, tests/deploy/freshness status, problems).

Environment variables are already exported: ARTIFICIAL_ANALYSIS_API_KEY, TG_BOT_TOKEN, TG_CHAT_ID. Never print secret values.

STEPS
1. git pull --ff-only origin main (abort and write the reason to /opt/mmc-daily/last-summary.txt if it fails).
2. node scripts/fetch-live.mjs aa && node scripts/fetch-live.mjs da && node scripts/fetch-live.mjs or
   AA also refreshes data/raw/aa-efficiency.json from one full model-page payload. OR also collects four model pages in oldest-attempt rotation (OpenRouter empirical I/O and exact-endpoint cache statistics), then the seven-completed-day Chutes global I/O fallback. These write data/raw/openrouter-efficiency.json and data/raw/chutes-efficiency.json. Do not crawl every OpenRouter model daily. Page observations retain individual dates; sparse or failed attempts are explicit. Source failures that exit nonzero abort publication and preserve the previous good source snapshot. Never treat AA benchmark token ratios as observed user workloads or copy cache rates between provider labels/tags. The standalone recovery command is npm run data:efficiency.
3. Run node scripts/fetch-aa-coding-agents.mjs. It validates the full AA Coding Agent v1.5 board and atomically writes data/raw/aa-coding-agents-v1.5.json. The dated v1.4 snapshot data/raw/aa-coding-agents.json is retained for the unchanged Composite: do not replace it with v1.5, relabel its date, or reimplement the scrape. A failure must abort the refresh and preserve the good snapshot.
3b. Versioned benchmark results use docs/benchmark-ingestion.md and data/raw/benchmarks/collection-plan.json. Reuse the AA model-page capture for extract-aa-benchmark-fields; stage public captures once per source using capture-benchmark-sources.py and collect-public-benchmarks.py --plan CANDIDATE_PLAN CANDIDATE_RESULTS. Preserve exact task/version/split/harness and all immutable source receipts; source access failure must never erase good dated results. The reviewed ingestion-lock binds the AA field snapshot and immutable coding copies. Stage a fresh v1.5 copy and review before changing its lock; never change v1.4. Public results and vendor release/HF/report claims require actual primary evidence, a different-family GAUNTLET critic and owner acceptance; every self-reported observation fingerprint must match score-approvals.json. Every X interaction uses xplainervideo and the existing account/browser gates. Never auto-approve claims, infer missing scores or comparison keys, or relabel stale scores as fresh. Unverified candidates stay outside accepted raw inputs. After accepted updates, run node scripts/ingest-benchmark-scores.mjs and then the normal dataset build. If no review can be completed, retain the prior accepted benchmark snapshot/dates and explicitly report the skipped benchmark refresh. Phase 08 will install the unattended review orchestration; do not invent it here.
4. node scripts/build-dataset.mjs. If it fails with missing provider metadata, verify the provider against a primary source before adding an entry; do not invent a country or residency flag. If unverifiable, report the error and do not push.
5. Override check: GET https://openrouter.ai/api/v1/models/openai/gpt-5.6-luna/endpoints. If the endpoint tagged exactly "openai" now prices at the official standard ($0.20/$1.20 for Luna; sibling Terra $2/$12), remove the offer_overrides entries from data/raw/manual.json and rebuild; if it still shows the flex price ($0.10/$0.60), keep them.
6. npm run build && npm test && npx tsc --noEmit -p . && node --test test/production/prerender.mjs. The production build is required before testing because test/production/prerender.mjs reads .next/prerender-manifest.json; stale manifests are not valid evidence. Fix a failing test ONLY when it pins a benchmark value, price, date floor or catalog presence that legitimately changed upstream (update the pin, add a dated comment like "// <date>: AA re-scored X -> Y"). Anything else: do not touch app code; report it in the summary file instead and skip the commit if the suite is red.
7. If the working tree changed: git add -A; git commit with a concise summary of what actually moved (new models, notable score/price moves, catalog changes), ending with the trailer line: Co-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>. Then git push origin main. Never force-push; on conflict report it in the summary file.
8. Deploy: the app is hosted on this server via Coolify (Render is no longer used). GitHub pushes now trigger an automatic webhook deployment (verified 2026-09-08). The primary public URL is https://benchmarkheaven.com; the previous hostname remains valid. After pushing, poll the compatibility URL https://model-market-comparison.app.mintapis.com/api/dataset with TLS verification and a cache-busting query for up to 10 minutes, comparing generated_at and source dates with the committed snapshot. Do not trigger another deployment while the webhook build is progressing. If the snapshot has not become live, inspect deployment state; only when no deployment is queued/running, use bash /opt/mmc-daily/redeploy.sh as fallback. Report failures rather than queueing duplicate builds. Only deploy if you pushed a new commit.
9. Verify the live /api/dataset with TLS verification: generated_at and all source dates must match the committed snapshot. artificialanalysis/designarena/openrouter/aa_coding_agents_v1_5 must be today; aa_coding_agents remains the explicitly retained v1.4 date, with source_status explaining why. Never require an invented fresh date for the historical source.
   aa_efficiency/openrouter_efficiency/chutes_efficiency must record today's collector run. For rotated OpenRouter pages inspect each observation's collected_at, not just the run date; inspect efficiency.coverage and per-model token_efficiency.attempts for gaps. Preserve metadata.retained_fields and aa_metadata.retained_fields with their original dates.
10. Write the summary file /opt/mmc-daily/last-summary.txt as described above. Its FIRST line must be exactly "STATUS: ok" if everything (fetch, build, tests, push/deploy when there were changes) succeeded, otherwise "STATUS: problem".

FILE ops/rebuild-2026-09/daily-refresh-prompt.md
You are the daily data-refresh agent for Benchmark Heaven (this repo, /opt/model-market-comparison). Do the full refresh, commit, push, deploy. Work non-interactively; never ask questions. Do NOT send Telegram messages yourself — the wrapper script decides whether anything is worth notifying. Instead, write your final summary to /opt/mmc-daily/last-summary.txt (overwrite; German; max 15 lines: what moved, tests/deploy/freshness status, problems).

Environment variables are already exported: ARTIFICIAL_ANALYSIS_API_KEY, TG_BOT_TOKEN, TG_CHAT_ID. Never print secret values.

STEPS
1. git pull --ff-only origin main (abort and write the reason to /opt/mmc-daily/last-summary.txt if it fails).
2. node scripts/fetch-live.mjs aa && node scripts/fetch-live.mjs da && node scripts/fetch-live.mjs or
   AA also refreshes data/raw/aa-efficiency.json from one full model-page payload. OR also collects four model pages in oldest-attempt rotation (OpenRouter empirical I/O and exact-endpoint cache statistics), then the seven-completed-day Chutes global I/O fallback. These write data/raw/openrouter-efficiency.json and data/raw/chutes-efficiency.json. Do not crawl every OpenRouter model daily. Page observations retain individual dates; sparse or failed attempts are explicit. Source failures that exit nonzero abort publication and preserve the previous good source snapshot. Never treat AA benchmark token ratios as observed user workloads or copy cache rates between provider labels/tags. The standalone recovery command is npm run data:efficiency.
3. Run node scripts/fetch-aa-coding-agents.mjs. It validates the full AA Coding Agent v1.5 board and atomically writes data/raw/aa-coding-agents-v1.5.json. The dated v1.4 snapshot data/raw/aa-coding-agents.json is retained for the unchanged Composite: do not replace it with v1.5, relabel its date, or reimplement the scrape. A failure must abort the refresh and preserve the good snapshot.
3b. Versioned benchmark results use docs/benchmark-ingestion.md and data/raw/benchmarks/collection-plan.json. Reuse the AA model-page capture for extract-aa-benchmark-fields; stage public captures once per source using capture-benchmark-sources.py and collect-public-benchmarks.py --plan CANDIDATE_PLAN CANDIDATE_RESULTS. Preserve exact task/version/split/harness and all immutable source receipts; source access failure must never erase good dated results. The reviewed ingestion-lock binds the AA field snapshot and immutable coding copies. Stage a fresh v1.5 copy and review before changing its lock; never change v1.4. Public results and vendor release/HF/report claims require actual primary evidence, a different-family GAUNTLET critic and owner acceptance; every self-reported observation fingerprint must match score-approvals.json. Every X interaction uses xplainervideo and the existing account/browser gates. Never auto-approve claims, infer missing scores or comparison keys, or relabel stale scores as fresh. Unverified candidates stay outside accepted raw inputs. After accepted updates, run node scripts/ingest-benchmark-scores.mjs and then the normal dataset build. If no review can be completed, retain the prior accepted benchmark snapshot/dates and explicitly report the skipped benchmark refresh. Phase 08 will install the unattended review orchestration; do not invent it here.
4. node scripts/build-dataset.mjs. If it fails with missing provider metadata, verify the provider against a primary source before adding an entry; do not invent a country or residency flag. If unverifiable, report the error and do not push.
5. Override check: GET https://openrouter.ai/api/v1/models/openai/gpt-5.6-luna/endpoints. If the endpoint tagged exactly "openai" now prices at the official standard ($0.20/$1.20 for Luna; sibling Terra $2/$12), remove the offer_overrides entries from data/raw/manual.json and rebuild; if it still shows the flex price ($0.10/$0.60), keep them.
6. npm run build && npm test && npx tsc --noEmit -p . && node --test test/production/prerender.mjs. The production build is required before testing because test/production/prerender.mjs reads .next/prerender-manifest.json; stale manifests are not valid evidence. Fix a failing test ONLY when it pins a benchmark value, price, date floor or catalog presence that legitimately changed upstream (update the pin, add a dated comment like "// <date>: AA re-scored X -> Y"). Anything else: do not touch app code; report it in the summary file instead and skip the commit if the suite is red.
7. If the working tree changed: git add -A; git commit with a concise summary of what actually moved (new models, notable score/price moves, catalog changes), ending with the trailer line: Co-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>. Then git push origin main. Never force-push; on conflict report it in the summary file.
8. Deploy: the app is hosted on this server via Coolify (Render is no longer used). GitHub pushes now trigger an automatic webhook deployment (verified 2026-09-08). The primary public URL is https://benchmarkheaven.com; the previous hostname remains valid. After pushing, poll the compatibility URL https://model-market-comparison.app.mintapis.com/api/dataset with TLS verification and a cache-busting query for up to 10 minutes, comparing generated_at and source dates with the committed snapshot. Do not trigger another deployment while the webhook build is progressing. If the snapshot has not become live, inspect deployment state; only when no deployment is queued/running, use bash /opt/mmc-daily/redeploy.sh as fallback. Report failures rather than queueing duplicate builds. Only deploy if you pushed a new commit.
9. Verify the live /api/dataset with TLS verification: generated_at and all source dates must match the committed snapshot. artificialanalysis/designarena/openrouter/aa_coding_agents_v1_5 must be today; aa_coding_agents remains the explicitly retained v1.4 date, with source_status explaining why. Never require an invented fresh date for the historical source.
   aa_efficiency/openrouter_efficiency/chutes_efficiency must record today's collector run. For rotated OpenRouter pages inspect each observation's collected_at, not just the run date; inspect efficiency.coverage and per-model token_efficiency.attempts for gaps. Preserve metadata.retained_fields and aa_metadata.retained_fields with their original dates.
10. Write the summary file /opt/mmc-daily/last-summary.txt as described above. Its FIRST line must be exactly "STATUS: ok" if everything (fetch, build, tests, push/deploy when there were changes) succeeded, otherwise "STATUS: problem".

DIFF scripts/fetch-live.mjs
diff --git a/scripts/fetch-live.mjs b/scripts/fetch-live.mjs
index 1cae34f..b4f1942 100644
--- a/scripts/fetch-live.mjs
+++ b/scripts/fetch-live.mjs
@@ -16,7 +16,7 @@ const __dirname = dirname(fileURLToPath(import.meta.url));
 const RAW = join(__dirname, "..", "data", "raw");
 
 const AA_KEY = process.env.ARTIFICIAL_ANALYSIS_API_KEY || process.env.ARTIF_ANALYSIS_API_KEY || "";
-const UA = "model-market-comparison/1.0 (+https://github.com/fstandhartinger/model-market-comparison)";
+const UA = "BenchmarkHeaven/1.0 (+https://github.com/fstandhartinger/model-market-comparison)";
 
 const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
 

DIFF scripts/fetch-aa-efficiency.mjs
diff --git a/scripts/fetch-aa-efficiency.mjs b/scripts/fetch-aa-efficiency.mjs
index b33c00b..c3d5bcf 100644
--- a/scripts/fetch-aa-efficiency.mjs
+++ b/scripts/fetch-aa-efficiency.mjs
@@ -10,7 +10,7 @@ import { fileURLToPath } from "node:url";
 import { AA_EFFICIENCY_MODEL_SLUGS, aaModelPageURL, parseAaEfficiency } from "../lib/aa-efficiency.mjs";
 import { writeJSONAtomic } from "../lib/snapshot.mjs";
 
-const UA = "model-market-comparison/1.0 (+https://github.com/fstandhartinger/model-market-comparison)";
+const UA = "BenchmarkHeaven/1.0 (+https://github.com/fstandhartinger/model-market-comparison)";
 const POLITE_DELAY_MS = 2500;
 const HASH_TAG = /[/.:?=&]/g;
 const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

DIFF scripts/fetch-aa-coding-agents.mjs
diff --git a/scripts/fetch-aa-coding-agents.mjs b/scripts/fetch-aa-coding-agents.mjs
index fa5f944..39ce6ec 100644
--- a/scripts/fetch-aa-coding-agents.mjs
+++ b/scripts/fetch-aa-coding-agents.mjs
@@ -11,7 +11,7 @@ export async function refreshCodingAgents({ html, target, fetcher = fetch }) {
   catch (error) { if (error.code !== "ENOENT") throw error; }
   if (html === undefined) {
     const response = await fetcher(CODING_AGENT_URL, {
-      headers: { "User-Agent": "model-market-comparison/1.0 (+https://github.com/fstandhartinger/model-market-comparison)" },
+      headers: { "User-Agent": "BenchmarkHeaven/1.0 (+https://github.com/fstandhartinger/model-market-comparison)" },
       signal: AbortSignal.timeout(60_000),
     });
     if (!response.ok) throw new Error(`AA Coding Agent HTTP ${response.status}`);

COMPATIBILITY PRIMARY FILES: API route tree
app/api/benchmarks/route.ts
app/api/dataset/route.ts
app/api/providers/route.ts
app/api/health/route.ts
app/api/benchmark-view/route.ts
app/api/meta/route.ts
app/api/benchmark-scores/route.ts
app/api/price-comparison/route.ts
app/api/models/[id]/route.ts
app/api/models/route.ts

PRIMARY SOURCE middleware.ts
import { NextResponse } from "next/server";

// Make every /api/* route a public, read-only, CORS-enabled JSON API so other
// sites/tools can consume the data directly from the browser.
export function middleware(req: Request) {
  if (req.method === "OPTIONS") {
    return new NextResponse(null, { status: 204, headers: CORS });
  }
  const res = NextResponse.next();
  for (const [k, v] of Object.entries(CORS)) res.headers.set(k, v);
  return res;
}

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export const config = { matcher: "/api/:path*" };

PRIMARY SOURCE components/SettingsContext.tsx
"use client";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ScoreKey } from "../lib/types";
import { DEFAULT_SCORE, defaultMinFor, FIXED_BLENDS, SCORE_OPTIONS, type PriceMode } from "../lib/cost";

interface SettingsState {
  score: ScoreKey;
  collapse: boolean;       // one variant per GPT/Claude family
  featured: boolean;
  hideDeprecated: boolean; // hide benchmark-source rows marked deprecated (on by default)
  excludeChinese: boolean;  // hide Chinese-based inference providers (not their models)
  euHostedOnly: boolean;    // only exact offers hosted in the EU or explicitly policy-equivalent
  nonUsOnly: boolean;       // only providers whose company is not US-based
  openOnly: boolean;        // only open-weights models (off by default)
  minScore: number;         // hide models scoring below this (score-aware default)
  teeOnly: boolean;         // only models with a TEE / confidential-compute offer
  providersExcluded: string[]; // BLOCKLIST of deselected provider keys; empty = all included (incl. future providers)
  families: string[];      // selected model family keys; empty = all
  priceMode: PriceMode;    // adjusted $/task (default) vs raw fixed-blend list prices
  inputWeight: number;     // raw mode's fixed input:output blend; persists while adjusted
}

interface SettingsCtx extends SettingsState {
  setScore: (s: ScoreKey) => void;
  setCollapse: (b: boolean) => void;
  setFeatured: (b: boolean) => void;
  setHideDeprecated: (b: boolean) => void;
  setExcludeChinese: (b: boolean) => void;
  setEuHostedOnly: (b: boolean) => void;
  setNonUsOnly: (b: boolean) => void;
  setOpenOnly: (b: boolean) => void;
  setMinScore: (n: number) => void;
  setTeeOnly: (b: boolean) => void;
  setProvidersExcluded: (k: string[]) => void;
  setFamilies: (k: string[]) => void;
  setPriceMode: (m: PriceMode) => void;
  setInputWeight: (n: number) => void;
  excludedSet: Set<string> | null; // null = nothing excluded
  familySet: Set<string> | null;   // null = all
}

const DEFAULTS: SettingsState = { score: DEFAULT_SCORE, collapse: true, featured: true, hideDeprecated: true, excludeChinese: true, euHostedOnly: false, nonUsOnly: false, openOnly: false, minScore: defaultMinFor(DEFAULT_SCORE), teeOnly: false, providersExcluded: [], families: [], priceMode: "adjusted", inputWeight: 10 };
// v3: the provider filter is now a BLOCKLIST (persisted `providersExcluded`) instead of
// an inclusion list. An inclusion list is a snapshot of the providers that existed when
// the user last touched the filter, so any provider added later (e.g. TensorX) was
// silently excluded — and with the EU eligibility filter on, models whose only matching route is a new
// provider vanished. A blocklist includes future providers by default. Bumping v2→v3
// discards the old (inclusion-shaped) persisted `providers` array.
// v5: dropped hideGptOpus/hideFable (toggles removed; nothing is hidden by them anymore).
// v6: added priceMode/inputWeight; stored values are validated on load (below).
const KEY = "mmc.settings.v6";

const BLEND_VALUES = new Set(FIXED_BLENDS.map((b) => b.value));

/** Only known keys with a plausible type survive a load; anything else falls
 *  back to DEFAULTS so a corrupted or stale payload cannot wedge the UI. */
function sanitizeSettings(input: unknown): Partial<SettingsState> {
  if (!input || typeof input !== "object") return {};
  const raw = input as Record<string, unknown>;
  const out: Partial<SettingsState> = {};
  const bool = (v: unknown): v is boolean => typeof v === "boolean";
  const strArr = (v: unknown): v is string[] => Array.isArray(v) && v.every((x) => typeof x === "string");
  if (typeof raw.score === "string" && (SCORE_OPTIONS as string[]).includes(raw.score)) out.score = raw.score as ScoreKey;
  if (bool(raw.collapse)) out.collapse = raw.collapse;
  if (bool(raw.featured)) out.featured = raw.featured;
  if (bool(raw.hideDeprecated)) out.hideDeprecated = raw.hideDeprecated;
  if (bool(raw.excludeChinese)) out.excludeChinese = raw.excludeChinese;
  if (bool(raw.euHostedOnly)) out.euHostedOnly = raw.euHostedOnly;
  if (bool(raw.nonUsOnly)) out.nonUsOnly = raw.nonUsOnly;
  if (bool(raw.openOnly)) out.openOnly = raw.openOnly;
  if (typeof raw.minScore === "number" && Number.isFinite(raw.minScore) && raw.minScore >= 0) out.minScore = raw.minScore;
  if (bool(raw.teeOnly)) out.teeOnly = raw.teeOnly;
  if (strArr(raw.providersExcluded)) out.providersExcluded = raw.providersExcluded;
  if (strArr(raw.families)) out.families = raw.families;
  if (raw.priceMode === "adjusted" || raw.priceMode === "raw") out.priceMode = raw.priceMode;
  if (typeof raw.inputWeight === "number" && BLEND_VALUES.has(raw.inputWeight)) out.inputWeight = raw.inputWeight;
  return out;
}

const Ctx = createContext<SettingsCtx | null>(null);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<SettingsState>(DEFAULTS);
  // Persisting is gated on hydration so the initial DEFAULTS write can never
  // clobber a stored choice before it has been read and applied.
  const [hydrated, setHydrated] = useState(false);

  // hydrate from localStorage after mount (avoids SSR/client mismatch)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const stored = sanitizeSettings(JSON.parse(raw));
        setState((s) => ({ ...s, ...stored }));
      }
    } catch { /* ignore */ }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
  }, [state, hydrated]);

  const value = useMemo<SettingsCtx>(() => ({
    ...state,
    setScore: (score) => setState((s) => ({ ...s, score, minScore: defaultMinFor(score) })),
    setCollapse: (collapse) => setState((s) => ({ ...s, collapse })),
    setFeatured: (featured) => setState((s) => ({ ...s, featured })),
    setHideDeprecated: (hideDeprecated) => setState((s) => ({ ...s, hideDeprecated })),
    setExcludeChinese: (excludeChinese) => setState((s) => ({ ...s, excludeChinese })),
    setEuHostedOnly: (euHostedOnly) => setState((s) => ({ ...s, euHostedOnly })),
    setNonUsOnly: (nonUsOnly) => setState((s) => ({ ...s, nonUsOnly })),
    setOpenOnly: (openOnly) => setState((s) => ({ ...s, openOnly })),
    setMinScore: (minScore) => setState((s) => ({ ...s, minScore })),
    setTeeOnly: (teeOnly) => setState((s) => ({ ...s, teeOnly })),
    setProvidersExcluded: (providersExcluded) => setState((s) => ({ ...s, providersExcluded })),
    setFamilies: (families) => setState((s) => ({ ...s, families })),
    setPriceMode: (priceMode) => setState((s) => ({ ...s, priceMode })),
    setInputWeight: (inputWeight) => setState((s) => BLEND_VALUES.has(inputWeight) ? { ...s, inputWeight } : s),
    excludedSet: state.providersExcluded.length ? new Set(state.providersExcluded) : null,
    familySet: state.families.length ? new Set(state.families) : null,
  }), [state]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSettings(): SettingsCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("useSettings must be used within SettingsProvider");
  return c;
}

PREVIOUS INSTALLED DAILY PROMPT
You are the daily data-refresh agent for the model-market-comparison app (this repo, /opt/model-market-comparison). Do the full refresh, commit, push, deploy. Work non-interactively; never ask questions. Do NOT send Telegram messages yourself — the wrapper script decides whether anything is worth notifying. Instead, write your final summary to /opt/mmc-daily/last-summary.txt (overwrite; German; max 15 lines: what moved, tests/deploy/freshness status, problems).

Environment variables are already exported: ARTIFICIAL_ANALYSIS_API_KEY, TG_BOT_TOKEN, TG_CHAT_ID. Never print secret values.

STEPS
1. git pull --ff-only origin main (abort and write the reason to /opt/mmc-daily/last-summary.txt if it fails).
2. node scripts/fetch-live.mjs aa && node scripts/fetch-live.mjs da && node scripts/fetch-live.mjs or
   AA also refreshes data/raw/aa-efficiency.json from one full model-page payload. OR also collects four model pages in oldest-attempt rotation (OpenRouter empirical I/O and exact-endpoint cache statistics), then the seven-completed-day Chutes global I/O fallback. These write data/raw/openrouter-efficiency.json and data/raw/chutes-efficiency.json. Do not crawl every OpenRouter model daily. Page observations retain individual dates; sparse or failed attempts are explicit. Source failures that exit nonzero abort publication and preserve the previous good source snapshot. Never treat AA benchmark token ratios as observed user workloads or copy cache rates between provider labels/tags. The standalone recovery command is npm run data:efficiency.
3. Run node scripts/fetch-aa-coding-agents.mjs. It validates the full AA Coding Agent v1.5 board and atomically writes data/raw/aa-coding-agents-v1.5.json. The dated v1.4 snapshot data/raw/aa-coding-agents.json is retained for the unchanged Composite: do not replace it with v1.5, relabel its date, or reimplement the scrape. A failure must abort the refresh and preserve the good snapshot.
3b. Versioned benchmark results use docs/benchmark-ingestion.md and data/raw/benchmarks/collection-plan.json. Reuse the AA model-page capture for extract-aa-benchmark-fields; stage public captures once per source using capture-benchmark-sources.py and collect-public-benchmarks.py --plan CANDIDATE_PLAN CANDIDATE_RESULTS. Preserve exact task/version/split/harness and all immutable source receipts; source access failure must never erase good dated results. The reviewed ingestion-lock binds the AA field snapshot and immutable coding copies. Stage a fresh v1.5 copy and review before changing its lock; never change v1.4. Public results and vendor release/HF/report claims require actual primary evidence, a different-family GAUNTLET critic and owner acceptance; every self-reported observation fingerprint must match score-approvals.json. Every X interaction uses xplainervideo and the existing account/browser gates. Never auto-approve claims, infer missing scores or comparison keys, or relabel stale scores as fresh. Unverified candidates stay outside accepted raw inputs. After accepted updates, run node scripts/ingest-benchmark-scores.mjs and then the normal dataset build. If no review can be completed, retain the prior accepted benchmark snapshot/dates and explicitly report the skipped benchmark refresh. Phase 08 will install the unattended review orchestration; do not invent it here.
4. node scripts/build-dataset.mjs. If it fails with missing provider metadata, verify the provider against a primary source before adding an entry; do not invent a country or residency flag. If unverifiable, report the error and do not push.
5. Override check: GET https://openrouter.ai/api/v1/models/openai/gpt-5.6-luna/endpoints. If the endpoint tagged exactly "openai" now prices at the official standard ($0.20/$1.20 for Luna; sibling Terra $2/$12), remove the offer_overrides entries from data/raw/manual.json and rebuild; if it still shows the flex price ($0.10/$0.60), keep them.
6. npm run build && npm test && npx tsc --noEmit -p . && node --test test/production/prerender.mjs. The production build is required before testing because test/production/prerender.mjs reads .next/prerender-manifest.json; stale manifests are not valid evidence. Fix a failing test ONLY when it pins a benchmark value, price, date floor or catalog presence that legitimately changed upstream (update the pin, add a dated comment like "// <date>: AA re-scored X -> Y"). Anything else: do not touch app code; report it in the summary file instead and skip the commit if the suite is red.
7. If the working tree changed: git add -A; git commit with a concise summary of what actually moved (new models, notable score/price moves, catalog changes), ending with the trailer line: Co-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>. Then git push origin main. Never force-push; on conflict report it in the summary file.
8. Deploy: the app is hosted on this server via Coolify (Render is no longer used). GitHub pushes now trigger an automatic webhook deployment (verified 2026-09-08). After pushing, poll https://model-market-comparison.app.mintapis.com/api/dataset with TLS verification and a cache-busting query for up to 10 minutes, comparing generated_at and source dates with the committed snapshot. Do not trigger another deployment while the webhook build is progressing. If the snapshot has not become live, inspect deployment state; only when no deployment is queued/running, use bash /opt/mmc-daily/redeploy.sh as fallback. Report failures rather than queueing duplicate builds. Only deploy if you pushed a new commit.
9. Verify the live /api/dataset with TLS verification: generated_at and all source dates must match the committed snapshot. artificialanalysis/designarena/openrouter/aa_coding_agents_v1_5 must be today; aa_coding_agents remains the explicitly retained v1.4 date, with source_status explaining why. Never require an invented fresh date for the historical source.
   aa_efficiency/openrouter_efficiency/chutes_efficiency must record today's collector run. For rotated OpenRouter pages inspect each observation's collected_at, not just the run date; inspect efficiency.coverage and per-model token_efficiency.attempts for gaps. Preserve metadata.retained_fields and aa_metadata.retained_fields with their original dates.
10. Write the summary file /opt/mmc-daily/last-summary.txt as described above. Its FIRST line must be exactly "STATUS: ok" if everything (fetch, build, tests, push/deploy when there were changes) succeeded, otherwise "STATUS: problem".

PREVIOUS DAILY RUNNER
#!/bin/bash
# Daily model-market-comparison refresh driven by Codex CLI (headless). Cron-safe:
# loads secrets itself, runs fully non-interactive, no windows, logs to cron.log.
set -u
# The root cron delegates to the subscription-authenticated account before loading secrets.
if [ "$(id -u)" = 0 ]; then exec runuser -u flori -- bash "$0"; fi
LOG=/opt/mmc-daily/cron.log
exec >> "$LOG" 2>&1
echo "=== $(date -u '+%F %T') UTC start ==="
for f in "$HOME/.config/dev-secrets.env" /root/.config/dev-secrets.env; do
  [ -r "$f" ] && . "$f" && break
done
[ -f /etc/profile.d/telegram.sh ] && . /etc/profile.d/telegram.sh
export ARTIFICIAL_ANALYSIS_API_KEY="${ARTIFICIAL_ANALYSIS_API_KEY:-${ARTIF_ANALYSIS_API_KEY:-}}"
export RENDER_API_KEY TG_BOT_TOKEN TG_CHAT_ID
export PATH="$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin"
# Codex must bill against the ChatGPT Pro subscription, not an API key.
unset OPENAI_API_KEY OPENAI_BASE_URL
case "$(codex login status 2>&1 | head -1)" in
  *ChatGPT*) : ;;
  *) echo "ABORT: codex not on ChatGPT subscription"; exit 1 ;;
esac
cd /opt/model-market-comparison || exit 1
AUTH="$(codex login status 2>&1)"
case "$AUTH" in
  *ChatGPT*) ;;
  *) printf 'STATUS: problem\nCodex auth is not ChatGPT; refusing API billing.\n' > /opt/mmc-daily/last-summary.txt; exit 1 ;;
esac
timeout 45m codex exec -m gpt-5.6-sol --dangerously-bypass-approvals-and-sandbox -C /opt/model-market-comparison "$(cat /opt/mmc-daily/prompt.md)"
rc=$?
echo "=== $(date -u '+%F %T') UTC end rc=$rc ==="
# --- Notification policy: quiet by default. Telegram only when
#  (a) a new family enters the top 5 by Composite (state in top5-state.json), or
#  (b) the refresh failed — at most once per 7 days (failure-alert.stamp).
python3 - "$rc" << 'PY'
import os, sys, json, subprocess, time, urllib.request
rc = int(sys.argv[1]); D = '/opt/mmc-daily'
def tg(text):
    t, c = os.environ.get('TG_BOT_TOKEN'), os.environ.get('TG_CHAT_ID')
    if not (t and c): return
    req = urllib.request.Request(f'https://api.telegram.org/bot{t}/sendMessage', data=json.dumps({'chat_id': c, 'text': text}).encode(), headers={'Content-Type': 'application/json'})
    urllib.request.urlopen(req, timeout=30).read()
summary = open(f'{D}/last-summary.txt').read().strip() if os.path.exists(f'{D}/last-summary.txt') else ''
problem = rc != 0 or not summary.startswith('STATUS: ok')
# (a) top-5 entrants
try:
    top = json.loads(subprocess.check_output(['node', 'scripts/top5.mjs', '5'], cwd='/opt/model-market-comparison', timeout=120))
    sp = f'{D}/top5-state.json'
    prev = json.load(open(sp)) if os.path.exists(sp) else None
    if prev is not None:
        old = {r['family_key'] for r in prev}
        new = [r for r in top if r['family_key'] not in old]
        if new:
            lines = [f"🏆 MMC: Neu in den Top 5 (Composite): " + ", ".join(f"{r['name']} ({r['composite']})" for r in new), ""]
            lines += [f"{i+1}. {r['name']} — {r['composite']}" for i, r in enumerate(top)]
            lines.append("https://model-market-comparison.app.mintapis.com")
            tg("\n".join(lines)); print('telegram: top5 entrant sent')
        else: print('top5 unchanged: ' + ', '.join(r['family_key'] for r in top))
    else: print('top5 state initialised')
    json.dump(top, open(sp, 'w'), indent=1)
except Exception as e:
    print('top5 check failed:', e); problem = True
# (b) rate-limited failure alert
if problem:
    st = f'{D}/failure-alert.stamp'
    last = os.path.getmtime(st) if os.path.exists(st) else 0
    if time.time() - last > 7 * 86400:
        tg(f"⚠️ MMC Daily-Refresh (Sandy) hat Probleme (rc={rc}). Nächste Warnung frühestens in 7 Tagen. Log: /opt/mmc-daily/cron.log\n\n{summary[:1500]}")
        open(st, 'w').close(); print('telegram: failure alert sent')
    else: print('failure alert suppressed (rate limit)')
PY
# keep log bounded (~2MB)
if [ "$(stat -c%s "$LOG")" -gt 2000000 ]; then
  tail -c 1000000 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
fi
exit "$rc"

RECEIPT daily-installed.json
{
  "at": "2026-09-11T02:09:42.369787+00:00",
  "files": [
    {
      "source": "ops/rebuild-2026-09/daily-refresh-prompt.md",
      "installed": "/opt/mmc-daily/prompt.md",
      "sha256": "943ac99621b0c69ba3a6df8bf7217c7554a50e3760db0198f0ac4f6c7deabe3a",
      "equal": true
    },
    {
      "source": "ops/daily/run.sh",
      "installed": "/opt/mmc-daily/run.sh",
      "sha256": "39a9ee2c0c62880eedd29bed24aaa2ef4a77ff63fa2cc41470532d5761dcb34f",
      "equal": true
    }
  ],
  "schedule": [
    "17 5 * * * /opt/mmc-daily/run.sh"
  ],
  "scope": "Message branding, public URL and current existing prompt mirrored. No cadence, state, callback paths or quiet-policy change. No daily refresh or Telegram send executed.",
  "schedule_owner": "flori"
}

RECEIPT dataset-continuity.json
{
  "sameExceptGeneratedAt": true,
  "counts": {
    "models": 835,
    "families": 650,
    "providers": 89,
    "offers": 2786
  },
  "observations": 13908
}

RECEIPT coolify-domains.json
{
  "ok": true,
  "data": {
    "uuid": "ggbs6upie6tqsousmrkw0vja",
    "name": "Benchmark Heaven",
    "fqdn": "https://benchmarkheaven.com,https://www.benchmarkheaven.com,https://model-market-comparison.app.mintapis.com",
    "status": "running:unknown",
    "git_repository": "fstandhartinger/model-market-comparison",
    "git_branch": "main",
    "git_commit_sha": "HEAD",
    "build_pack": "dockerfile",
    "base_directory": "/",
    "ports_exposes": "3000",
    "health_check_enabled": false,
    "health_check_path": "/api/health",
    "health_check_method": "GET",
    "limits_memory": "768M",
    "limits_cpus": "1",
    "created_at": "2026-08-26T15:13:34.000000Z",
    "updated_at": "2026-09-11T01:56:02.000000Z"
  },
  "meta": {
    "idempotency_replay": false
  }
}

RECEIPT tests.log
lity (0.330614ms)
✔ unscored transport smoke has a price ceiling and cannot select automatically (0.599409ms)
✔ critic excludes every producer family including aliases and explicit model pins (29.608262ms)
✔ worker CLI preserves output on provider failures and accepts a large embedded packet (3152.170375ms)
✔ transport smoke cannot accept arbitrary data work or a reference file (105.420403ms)
ℹ tests 146
ℹ suites 0
ℹ pass 146
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 7778.942476

RECEIPT typecheck.log

RECEIPT prerender.log
✔ bundled catalog / is rendered once at build time (2.1339ms)
✔ bundled catalog /about is rendered once at build time (0.213656ms)
✔ bundled catalog /charts is rendered once at build time (0.153638ms)
✔ bundled catalog /compare is rendered once at build time (0.118058ms)
✔ bundled catalog /eu is rendered once at build time (0.139297ms)
✔ bundled catalog /gateways is rendered once at build time (0.103338ms)
✔ bundled catalog /provider-explorer is rendered once at build time (0.090308ms)
✔ bundled catalog /providers is rendered once at build time (0.095228ms)
✔ bundled catalog /scatter is rendered once at build time (0.195576ms)
✔ bundled catalog /benchmarks is rendered once at build time (0.270305ms)
✔ bundled catalog /radar is rendered once at build time (0.287195ms)
ℹ tests 11
ℹ suites 0
ℹ pass 11
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 85.059787

RECEIPT letsencrypt-status.txt
Source: https://letsencrypt.status.io/
Captured 2026-09-11 02:12 UTC. Primary status-page text fetched by curl; the earlier web-tool snapshot still showed the initial investigating update.

Exact incident excerpt: "We have identified an issue with our DNS resolver in our secondary validation."

Status-page facts, paraphrased: Domain Control Validation was partly disrupted on production and staging. The incident began at 01:40 UTC. An update at 02:11 UTC marked the issue identified, said the change was being reverted, and estimated recovery within 15 minutes. This matches our secondary DNS validation error, but is not proof of recovery for our certificate. The final SSL check is still required.
