# Phase 7 — Benchmark Heaven rebrand and benchmarkheaven.com

**Goal:** the product is called Benchmark Heaven and lives at benchmarkheaven.com.

1. Develop the brand: name usage, logo/mark, favicon, colour system, typography, tone,
   og-image, README header. It must look designed, not renamed. Show variants, pick one,
   justify the pick in the report.
2. Apply it everywhere: `app/layout.tsx` metadata, nav, footer, README, API docs, the
   fork-sync prompt, the Telegram message templates.
3. **Domain:** DNS A record `benchmarkheaven.com` → `65.109.49.103` (plus `www`). There are
   no Namecheap API credentials — try the Namecheap web UI in Sandy's logged-in Chrome
   (`self-service-provisioning` skill). If that is gated, do everything else and send
   Florian the exact records to paste.
4. Add the domain to Coolify app `ggbs6upie6tqsousmrkw0vja`, issue TLS, verify HTTPS.
   **Keep `model-market-comparison.app.mintapis.com` working** (serve both or redirect) —
   downstream consumers use it.
5. Document the move loudly in `CHANGELOG.md` and `API.md`: new base URL, old one still
   valid, nothing else moved.


## How to work this phase

1. `cd /opt/model-market-comparison`. Read `ops/rebuild-2026-09/00-MASTER-BRIEF.md` and
   `10-RECON-FINDINGS.md` if you have not in this session (they are short and they save you
   a lot of tokens).
2. Delegate the bulk/mechanical parts to cheap workers via
   `bash ops/rebuild-2026-09/bin/worker.sh "<task>"` (see `--help`). You review everything.
3. Run a **gauntlet round** on this phase's artifacts before finishing: a critic model that
   did not produce the artifact checks it against primary sources
   (`bash ops/rebuild-2026-09/bin/worker.sh --critic --producer "<all producer model IDs, comma-separated>" --file <frozen evidence packet> "<what to verify>"`). Follow `GAUNTLET.md`; supply actual sources and record review coverage. Fix findings.
   Repeat until a round is clean or you have done 3 rounds; write the residue down.
4. Finish with: `node scripts/build-dataset.mjs`, `npm test`, `npx tsc --noEmit -p .`,
   then commit and push. Keep `main` green at all times.
5. Append your phase report to `ops/rebuild-2026-09/REPORT.md`: what you built, what the
   critic found, what you verified and how, what is still uncertain.
6. Write `DONE` (or `BLOCKED: <one line>`) as the last line of
   `/opt/benchmarkheaven/state/phase-07.status`. The tick job starts the next phase only
   when it sees `DONE`.

Commit trailer for every commit in this project:

    Co-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>


PRIMARY SCOPE: Phase7 only, not completion of all later rebuild phases. The owner has already accepted independently reviewed brand and consumer docs artifacts. The current review covers DNS/Coolify/TLS, released revision, old-host compatibility, report/coverage claims and actual publication. The final documentation-only closing commit and phase status write necessarily follow this review; these must not be claimed complete yet. No brand/data/application changes are planned after this review. Initial source and TLS failures are retained and distinguished from successful final checks. The primary CA incident was independently identified; our domain recovery is established by real certificate/HTTP checks, not by assuming the incident is resolved. The first incomplete browser probe is openly retained.

{
  "artifact_id": "phase07-domain-release-report",
  "round": 1,
  "files": {
    "ops/rebuild-2026-09/REPORT.md": "e3fd30b0b70923f7b937565139307158c6484f8fb7e5822b1a3664e2b51468ac",
    "ops/rebuild-2026-09/COVERAGE.md": "d14bb817f8900fd8cd16561cb62c3eac6e0491b468069e9eb6bbe93e6c5c52d7",
    "ops/rebuild-2026-09/evidence/phase-07/domain-change.json": "96895596a33acc6eac4132ef3418daa3c8c43e1556e48b1a36ab0f1be388cf7a",
    "ops/rebuild-2026-09/evidence/phase-07/dns-checks.json": "722c409696e6308b0801a41b0f4e5cf9243766bd52f3cf29cbd9612ab1115690",
    "ops/rebuild-2026-09/evidence/phase-07/domain-rdap.json": "00ee89c00e79f307d48ffdbe6802a96beba5f13905b05ddc8f616f4e73e65d63",
    "ops/rebuild-2026-09/evidence/phase-07/coolify-domains.json": "bd3545ef4e7af2c2c366c04be9ca6be58816c6958328076f4b3e917ec98ed177",
    "ops/rebuild-2026-09/evidence/phase-07/domain-primary-extract.txt": "25e0227f9b3400d2cc48925229d5a16a8d22a648a1e3780c22fab1666a00ce66",
    "ops/rebuild-2026-09/evidence/phase-07/certificate-initial-errors.log": "7eebe0a033a950ef59629530e82ede2fd5c6eac5c0f42f3d2652788fa26a52d7",
    "ops/rebuild-2026-09/evidence/phase-07/letsencrypt-status.txt": "867f25ff64522187f72ffb0b7cb5750a18f606b1ea10cd18b82090cc403058e8",
    "ops/rebuild-2026-09/evidence/phase-07/letsdebug-result.txt": "9c9d5cf7adde9bb010bd2d947126a7dd3c0adf52e008fba31ff48dd47244ad72",
    "ops/rebuild-2026-09/evidence/phase-07/domain-activation-deployment.json": "42c28461a3b08f01d03db5f18bbdc2bc796031d8609d5a881a300fdc90062a02",
    "ops/rebuild-2026-09/evidence/phase-07/tls-pre-release.json": "29ba3d91af1f9ec64a179b0c8bc1fe44c1ba879519c4a6397c976b18c23f8ed2",
    "ops/rebuild-2026-09/evidence/phase-07/release-deployment.json": "757680595157c2e2c78794d349a4a7644bf932d1d9264c25e1e5dd5f9546d1eb",
    "ops/rebuild-2026-09/evidence/phase-07/tls-release.json": "87bfd8d4cb6615a18ef88fb4002b0f86f157691dda3e7e692fc87ddcfce6154f",
    "ops/rebuild-2026-09/evidence/phase-07/live-apex-api.json": "094459f75578790d9c6c96e8137651642a2d6019e10e96de216f5e4f4fe184cb",
    "ops/rebuild-2026-09/evidence/phase-07/live-www-api.json": "cd36cb41b9492765294cf4e41f8221e2948b5cbbf2a97dd6c48b72d872423925",
    "ops/rebuild-2026-09/evidence/phase-07/live-compatibility-api.json": "60a48bf27e94ae16fa35a12b1197283c70019ad5c3ef284c43e46775f4c89015",
    "ops/rebuild-2026-09/evidence/phase-07/live/browser.json": "16522128ab2e529cae1590ebcb9cd47b445703a87c9cc2505ca4ad50b3bdc6e6",
    "ops/rebuild-2026-09/evidence/phase-07/live/first-browser-probe.json": "1c4880a98e69bd2e253d33b7224cbec8f9b451576751d1e0c593fb3d1c5ae666",
    "ops/rebuild-2026-09/evidence/phase-07/final-checks.json": "2ac1e3f3eb8b9c0ed5fc00b070113af76f5fa72a079fadcf585fa88524f5c820",
    "ops/rebuild-2026-09/evidence/phase-07/final-source-hashes.json": "b58b9cd6922b70589c60758368543f307a209bc74ad81c316d482f8f588e3629",
    "ops/rebuild-2026-09/evidence/phase-07/daily-installed.json": "a4094db09e0be3e247c79f474ee5fd46f94cda8bf79229d5724c1f98e0722df2",
    "ops/rebuild-2026-09/evidence/phase-07/ui-acceptance.json": "5bbf26e99d52f12034a63fe52105d80a21a8e08652b0bebfd11a95362f645660",
    "ops/rebuild-2026-09/evidence/phase-07/docs-acceptance.json": "007a81ef67f81a031530835d037d6f47a27d210e451e1113e08e5fb25f0985ca",
    "ops/rebuild-2026-09/evidence/phase-07/dataset-continuity.json": "030b4cbc3688caa8c66089039933a5acecfb329983cef0490207ff7b09889bc4",
    "ops/rebuild-2026-09/evidence/phase-07/worker-costs.json": "b990a154c88737e4477d36bb5825b5d26826db18aafb2b7b2d80772798e79250",
    "ops/rebuild-2026-09/evidence/phase-07/tls-check.py": "044c3123f23a8a89c22f02000193c593c2714730625bae277d7d039df38398e2",
    "ops/rebuild-2026-09/evidence/phase-07/api-check.mjs": "a3ecbd36760e8732891992dcd5a0cc1730a4df48c45eac1201b32015f95b1b4a",
    "ops/rebuild-2026-09/evidence/phase-07/live/browser-check.mjs": "7073efac2173cf50b936bc41c9b8d84750071d82bed102c1f563eb8ba983304c"
  },
  "images": {
    "ops/rebuild-2026-09/evidence/phase-07/live/overview.png": "fc58f6c850a077905606b18a4053456e2af88b16becc09cfaf3b3cec43ab7f7f",
    "ops/rebuild-2026-09/evidence/phase-07/live/compare.png": "cedb1934c19305686b44d685616a07e1a7f3df9f2a7171d7b1b1fda8d344df90",
    "ops/rebuild-2026-09/evidence/phase-07/live/mobile-dark.png": "8c9997033927d0acd94828058e938482d3e4f7c6e92fefd90bb30dc7c6959fa2"
  },
  "artifact_sha256": "ae7fc49d25d93cf940f23d539d9f1359b3660a2917ddc0e40053d0d6ce0476af"
}

FILE ops/rebuild-2026-09/REPORT.md
## Phase 07 — Benchmark Heaven identity and domain (2026-09-11)

Built a coherent **Benchmark Heaven** identity: the Observatory arch with three measurement bars, serif wordmark/display typography paired with system sans controls/data, the sky/sea-glass light/dark palette, SVG favicon, 180px touch icon, web manifest, 1200×630 social PNG and its editable SVG, and a README wordmark. [Three visual concepts](../../public/brand/variants.svg) show Observatory, Cloudline and a BH monogram. Observatory connects the name to measurement; Cloudline suggests a hosting service and the monogram communicates less to a new visitor. The production mark removes the concept star and strengthens the geometry for 16px use. [Brand guide](../../docs/brand.md), [actual assets](evidence/phase-07/rendered/assets.png), [desktop](evidence/phase-07/rendered/overview-light.png), [mobile](evidence/phase-07/rendered/overview-mobile.png).

Applied the identity to metadata/social tags, navigation, footer, overview and shared display headings, README/API/change notices, project specification, fork and spinoff prompts, collector User-Agent labels and Telegram templates. API/CHANGELOG loudly preserve the compatibility hostname and all existing routes, dataset paths, schemas, IDs, units and Composite inputs. Browser preference keys remain unchanged, but saved filters/theme are per origin and do not automatically transfer between hostnames. Fork instructions explicitly preserve msg branding while merging functional changes. The daily prompt mirrors now match the latest previously installed collection instructions; obsolete mirror guidance requiring a new date for retained v1.4 was eliminated. The installed runner/prompt match their repository sources; the **05:17 UTC** cron and quiet policy remain unchanged. [Installation receipt](evidence/phase-07/daily-installed.json).

Namecheap's saved login worked in Sandy's real Chrome without CAPTCHA, mail confirmation or phone approval. Under the shared browser lock, replaced the `www` parking CNAME and apex URL redirect with **A @ → 65.109.49.103** and **A www → 65.109.49.103**, TTL 1800 seconds, preserving mail records. Both authoritative servers and three public resolvers return the correct records; AAAA and CAA return successful empty responses. The parent delegation and public registry match the Namecheap nameservers. Coolify application **ggbs6upie6tqsousmrkw0vja** is named Benchmark Heaven and holds all three HTTPS hostnames. The original host stays served directly, preserving clients that do not follow redirects. [DNS checks](evidence/phase-07/dns-checks.json), [Coolify configuration](evidence/phase-07/coolify-domains.json).

TLS activation encountered an external incident. Deployments `ykjqjju6n1scbd8aummkp751` and `g5d3glsnbrmyxdfcd9wh0pcx` applied the domains successfully, but certificate authorization failed during secondary DNS validation. The independent HTTP-01 diagnostic found no domain configuration issue and flagged a CA outage. Let's Encrypt's primary status page identified its secondary DNS resolver problem at **02:11 UTC**, matching the observed errors; this is a supported explanation, not a claim that issuance has recovered. The existing hostname remained HTTPS 200. [Primary incident receipt](evidence/phase-07/letsencrypt-status.txt), [diagnostic](evidence/phase-07/letsdebug-result.txt), [initial HTTPS checks](evidence/phase-07/domain-https-initial.json). Release and `DONE` remain withheld until real certificates and the new public app are verified; the closing release section will record the outcome.

Delegation: GLM 5.3 Flash produced the visual concept board, which Astra checked and refined for contrast and precise copy. A Kimi K3 agent timed out after drafting four documentation files; Astra reviewed those partial changes and completed the remaining work. Two smaller brand completions exhausted their output allowance and supplied no usable artifact. These failures are recorded rather than counted as completed work. [Worker attempts](evidence/phase-07/worker-attempts.json).

The independent Google Gemini 3.7 Flash visual critic covered all eight actual image attachments, source files, brand criteria, metadata, keyboard/axe receipts and dataset continuity. Its final round 3 is clean. Rounds 1 and 2 reported no product defects but failed the exact JSON contract (uppercase verdict, then Markdown fencing). Astra recomputed final source/image/input/output hashes and the successful producer receipt. [Visual acceptance](evidence/phase-07/ui-acceptance.json). Documentation/operations and final domain/release evidence receive separate required reviews; their closing outcomes follow below.

Local validation includes dataset build, **146/146 tests**, typecheck, production build and **11/11 prerender checks**. The rebrand preserves the entire dataset except `generated_at`: **835 models, 650 families, 89 providers, 2,786 offers and 13,908 observations**. Seven rendered states cover light/dark, 1440px desktop and 390/320px reflow, with zero axe violations, no root overflow and no product runtime errors. Keyboard skip navigation, assets/social metadata and retained three-model comparison pass. [Browser receipts](evidence/phase-07/rendered/checks.json), [dataset continuity](evidence/phase-07/dataset-continuity.json). Browser-harness fixes corrected an SVG-document preview and opaque-origin fixture loading; they were not application defects. Final checks repeat after the completed template edits.

Limits: system serif letterforms vary by operating system; the social PNG is deterministic for the captured renderer. Automated accessibility scans and selected manual views do not establish complete WCAG conformance. No benchmark value, score definition or cache/workload assumption changed. The final domain/TLS/deployment result is still a release gate, not accepted on configuration alone. Later-phase automation and final explainer-video obligations remain outside phase 07.

### Phase 07 pre-release acceptance

Documentation/operations passed independent round 2 with zero content findings. Round 1 omitted the artifact ID/hash/round and was rejected as a reporting failure. [Documentation acceptance](evidence/phase-07/docs-acceptance.json) binds all 14 files and recomputed model input/output hashes. Final dataset build, 146 tests, typecheck, production build, 11 prerender checks and whitespace validation all pass; [exact commands and exits](evidence/phase-07/final-checks.json). [Final local API checks](evidence/phase-07/local-final-api.json) cover six branded pages, eight JSON endpoints, full committed-dataset equality and CORS preflight. Six completed producer/critic calls so far report **$0.169795296** in returned charges; incomplete/failed calls and the owner's subscription usage are excluded. Final domain/release QA and publication remain pending CA recovery.

### Phase 07 trusted domains activated

The spaced retry deployment **doblw9veld5qskwbuhjpqpsw** finished at **02:27:46 UTC**. All three domains now present trusted, hostname-validated certificates and return HTTPS 200 with identical API metadata. Ordinary HTTPS requests succeed without DNS or certificate overrides; HTTP redirects preserve the API path and query. [Certificate and request receipts](evidence/phase-07/tls-pre-release.json), [activation deployment](evidence/phase-07/domain-activation-deployment.json). An early probe during the rollout briefly received HTTP 502; the completed rollout passed on every host. This proves our domains recovered even before relying on a later incident-status update. The activated domains still serve the prior accepted application revision at this point; the tested rebrand is published next. Frozen review packets and build output are retained byte-for-byte in [compressed archives](evidence/phase-07/frozen-archives.json).

### Phase 07 published implementation

Implementation **989ce7d3b6d17c909a2470e06fa9bb64fd371a96** is pushed to `main`. Webhook deployment **fuotj6trvelbn2sqz7idk5xo** finished at **02:31:01 UTC**. Benchmark Heaven is now live at **https://benchmarkheaven.com**, with **https://www.benchmarkheaven.com** and **https://model-market-comparison.app.mintapis.com** serving the same app and feed. [Deployment](evidence/phase-07/release-deployment.json), [trusted certificates and ordinary HTTPS](evidence/phase-07/tls-release.json).

All **45 public checks** pass across the three hosts: branded pages, eight JSON endpoints, complete committed-dataset equality and CORS preflight. [Apex](evidence/phase-07/live-apex-api.json), [www](evidence/phase-07/live-www-api.json), [compatibility host](evidence/phase-07/live-compatibility-api.json). The public browser check verifies the new identity, a three-model comparison, mobile reflow, the theme toggle and byte-identical published social PNG, with no runtime errors. [Live browser receipt](evidence/phase-07/live/browser.json), [desktop](evidence/phase-07/live/overview.png), [mobile](evidence/phase-07/live/mobile-dark.png). One initial browser probe timed out waiting for a theme control after navigation; the instrumented repeat passed without app changes. The initial probe's root cause is not established and is not claimed as diagnosed; [bounded record](evidence/phase-07/live/first-browser-probe.json).

The brand and consumer-documentation final critic rounds remain clean after publication; all source and archived input/output hashes still match. No unresolved product finding is accepted. The final domain/release/report review and documentation-only closing push follow; `DONE` is withheld until that close completes. Existing source-coverage limitations and later-phase obligations are unchanged.


FILE ops/rebuild-2026-09/COVERAGE.md
# Original-request coverage — Benchmark Heaven

> Phase 01 audit: DeepSeek first draft, corrected and reviewed by Astra.
> Status convention: **Planned** = not yet completed. **Phase 1 verified** = the foundations documented in `REPORT.md`; later product work is still planned.
> “Completion evidence required” is an acceptance criterion, not an observation.
> Phase 1 execution and deployment evidence is in `REPORT.md`; future evidence requirements below are not completion claims.

Phase 1 foundations and phases 02–05 have release evidence in `REPORT.md`. Phase 06 is implemented and live-verified, with final release receipts in `REPORT.md`. Later-phase obligations remain planned. This table only updates the wishes verified by the current phase; the report carries prior phase detail.

---

## Every wish in §11 and its binding follow-up

| ID | Original wish (abbreviated) | Phase(s) | Completion evidence required | Status |
|---|---|---|---|---|
| W1 | Token & caching-efficiency adjusted costs, **default ON** | 2, 3, 8 | `data/dataset.json` contains I/O ratio, tokens/task, cache-hit/cache-price fields with provenance; effective-cost formula per §2-A4 implemented with unit tests; UI default shows adjusted price with toggle; daily refresh updates the inputs; deploy verified | Planned |
| W2 | Realistic input:output ratio; base case = agentic coding (Claude Code/Codex/opencode); try OpenRouter per-model first, Chutes API otherwise | 2, 3 | Per-model ratio with explicit basis (OpenRouter observation, Chutes global fallback, or explicitly labelled AA benchmark proxy); OpenRouter attempt documented; Chutes fallback flagged; existing fixed blends remain selectable; UI explains which basis was used | Planned |
| W3 | Tokens-per-task verbosity from AA “Output Tokens per Intelligence Index Task”; collect per model during collection and updates | 2, 8 | AA `intelligenceIndexOutputTokensPerTask` captured for the maximum politely reachable model set; coverage caveat recorded; daily refresh re-collects; parser tests cover missing/malformed payloads | Planned |
| W4 | Caching efficiency per **model × provider**; cache-hit rate scraped from OpenRouter pricing pages; cache read/write prices stored | 2, 8 | Store keyed by `(or_model_id, provider/endpoint)` with `cache_hit_rate`, `cache_read_price`, `cache_write_price`, provenance; partial coverage designed; tests | Planned |
| W5 | All new data integrated into the Model Market Comparison dataset and refreshed on every regular update | 2, 8 | Schema/API/CHANGELOG updated; daily job refreshes these fields; end-to-end dry run output is shown in the phase report | Planned |
| W6 | Default UI shows adjusted prices; user can answer “cheapest model at min benchmark score” | 3, 6 | Adjusted price is default; toggle to raw list price exists; one-screen min-score filter with adjusted cost; per-row explainer of assumptions; five-model sanity check documented | Phase 3 price task retained and Phase 6 browser-verified; released, see REPORT.md |
| W7 | Complete rebuild task handed to Codex GPT-6 Astra xHigh on Sandy Hetzner, with re-test and deploy at end | 1, 9 | Phase statuses in `/opt/benchmarkheaven/state/`; final verification checklist in `REPORT.md`; live deploy on benchmarkheaven.com verified | Phase 1 verified; rest planned |
| W8 | Astra may delegate token-heavy work to free/cheap workers; Astra stays quality gate | 1, 8 | `bin/worker.sh` verified end-to-end against all three backends; `bin/pick-worker-models.mjs` returns AA-index-filtered list; daily job uses dynamic worker selection; critic rounds documented | Phase 1 verified; rest planned |
| W9 | Final update via `/notify-telegram` | 8, 9 | Telegram notification sent at completion; daily quiet policy implemented | Planned |
| W10 | Claude Code near weekly limit → task goes as completely as possible to Codex | 1, 9 | Execution logs show Codex drives all rebuild phases; Claude is only used for the explainer-video handoff; no main rebuild work assigned to Claude | Phase 1 verified; rest planned |
| W11 | Radar charts on `/compare` and as own tab; up to 4 models; axes = collected benchmarks (AA, DesignArena, registry) | 6 | Radar implemented and rendered in both places; axis selection; normalization method documented; missing axes handled honestly; keyboard accessible | Phase 6 implemented; four-model/axis/keyboard and rendered evidence verified; released, see REPORT.md |
| W12 | Collect further benchmarks from Twitter; start with `https://x.com/search?q=benchmark&src=typed_query`; use logged-in Chrome | 4, 9 | Registry entries from sweep; “where results appear” captured; logs show **xplainervideo**, never airesearch12 | Planned |
| W13 | Goal: most complete benchmark collection of the AI Twitter universe; exclusions documented | 4, 5, 8 | Broad registry populated; saturated/superseded and excluded benchmarks recorded with reasons; coverage visible in UI | Planned |
| W14 | Composite may stay as-is; current Composite sources are reliable; new benchmarks additive | 4, 5, 6 | Existing Composite definition unchanged; regression guard added; new benchmarks only in new views/columns, not in Composite | Phase 6 verified: unchanged Composite bytes/inputs, dated v1.4 and separate v1.5 |
| W15 | Use Grok in X UI with the specified prompt; run more prompts/subagents to prune, detect saturation, and check versions | 4 | Grok session records; excluded-benchmark list with reasons; version-currency notes | Planned |
| W16 | Research gauntlet-loop technique online; use it for data, UI, design, docs; aim for world-best overview | 1–9 | `ops/rebuild-2026-09/GAUNTLET.md`; critic rounds per phase; residue documented; bounded rounds per artifact | Phase 1 verified; rest planned |
| W17 | Daily updates via Sandy cron with gauntlet loops; continuously discover free OpenRouter models; never use models below AA Intelligence Index 34 | 8 | Daily job rebuilt and dry-run end-to-end; dynamic picker filters AA ≥ 34; worker/cost log; Telegram quiet policy | Planned |
| W18 | For every benchmark, record where results actually appear (Tweets, websites, HF, GitHub) | 4, 8 | Registry `how_to_collect` / `primary_url` fields populated; recipes executed by daily refresh | Planned |
| W19 | One-sentence English summary + category per benchmark | 4 | Registry `one_sentence_description` and `category` fields populated | Planned |
| W20 | New UI sections: per-model full score list, model-vs-model comparison, inverse per-benchmark view listing models | 6 | Pages/routes implemented; scores shown with version, source, date, self-reported flag, links; sparse coverage handled | Phase 6 implemented and browser-verified; released, see REPORT.md |
| W21 | Handle missing scores elegantly; never mix benchmark versions (Terminal-Bench 4.0 ≠ 3.0) | 4, 5, 6 | Sparse-data states distinguished; version identity enforced; version shown in UI; version-isolation tests | Phase 6 verified: version/group isolation, explicit missing states, no zero imputation |
| W22 | General app revamp to “absolutely perfect standards” | 6 | Usability/accessibility checklist; critic review against rendered output/screenshots; performance checks | Phase 6 checklist and rendered/keyboard/performance verification; critic/release acceptance in REPORT.md |
| W23 | Anomaly/outlier highlighting per model; explainable; guard against noise | 6 | Anomaly view implemented; method described (e.g. z-score vs own profile and peer distribution); small-sample guard | Phase 6 measured-peer/profile heuristics implemented and tested; released, see REPORT.md |
| W24 | Rebrand to Benchmark Heaven; domain benchmarkheaven.com; hosting stays on Sandy PaaS; real branding | 7, 9 | DNS A record; Coolify domain/TLS; old host still works; brand assets; metadata/README updated | Phase 7 branding and all three HTTPS hosts published and verified; unchanged consumer data/contracts; final release acceptance in REPORT.md |
| W25 | Collect self-reported benchmark scores; mark them as such; critic verifies; flag divergence vs measured later | 5, 6 | `basis: self_reported` rows with source URL; critic verification log; divergence surfaced in UI | Phase 5 sources retained; Phase 6 claim flags and pair UI implemented; zero verified live pairs, no invented deltas |
| W26 | Pass structured brief + verbatim original prompt to Codex; re-verify completeness | 1, 9 | `COVERAGE.md` maintained; Phase 9 re-reads §11 line by line; discrepancies reported in `REPORT.md` | Phase 1 verified; rest planned |
| W27 | At the end: update via `/notify-telegram` **and** an `/explainer-video` about the end result | 9 + handoff to local Claude session | Telegram sent; explainer-video brief handed to Claude session; actual video delivery confirmed; a blocked handoff remains incomplete | Planned |
| W28 | Efficient collection recipes saved as user-level skills everywhere: local machine and Sandy, Claude Code, Codex and opencode | 2, 8, 9 | Token/I/O/cache collection skills written; installed in each of the six runtime/machine combinations; discovery and successful invocation receipts; repository copies alone do not count | Planned |
| F1 | Binding follow-up: use **xplainervideo** for all X/Grok interactions, **NOT airesearch12** | 4, 9 | Operational logs and final audit show only xplainervideo; no airesearch12 usage in any phase artifact | Planned |

---

## Corrections applied to the phase instructions

1. **I/O source priority (phase 02):** §11 explicitly asks for OpenRouter per-model empirical usage, then Chutes typical LLM usage. The structured brief promoted AA benchmark token ratios to the default. Restore the original priority. AA ratios remain useful cross-checks or clearly labelled benchmark proxies if actual usage is unavailable; never describe them as observed user workloads. The worker draft also put AA ahead of Chutes; owner corrected that error.
2. **Selectable blends (phase 03):** preserve existing fixed blends as alternative scenarios, in addition to the adjusted default and raw-price toggle.
3. **Provider identity (phase 02):** retain provider name along with model ID and endpoint tag; do not join unrelated endpoints just because their provider labels match.
4. **Composite/version protection (phases 04–06, 08):** the 2026-09-10 source moved Coding Agent Index from v1.4 to v1.5. Keep v1.4 dated and separate for the unchanged Composite. Collect v1.5 separately and ingest into versioned new views. No implicit score migration. Every radar axis, ranking and comparison displays its benchmark version.
5. **Skills on both machines (phase 09):** repository copies/handoff are intermediate artifacts. Completion requires installation and discovery evidence for Claude Code, Codex and opencode on Sandy AND Florian's machine. If a machine is unavailable, mark the installation incomplete with the specific blocker.
6. **Explainer video delivery (phase 09):** the master brief assigns production to Florian's local Claude session, while the original asks for a delivered video. Prepare an explicit video brief, deliver that handoff, and verify the video reaches Florian. A prepared brief alone is not completion. Record an outstanding blocker honestly rather than mark the entire rebuild complete.
7. **Unknown AA worker scores (phase 01/08):** the fixed known-answer smoke test verifies transport, not AA qualification, including the requested free and near-free backends. It has a price/token cap and accepts no custom task. Models with no AA score remain excluded from unattended data-bearing work. Known scores below 34 are excluded even from pinned and smoke paths.

All original wishes have phase owners. No new product features are claimed complete by this phase-01 mapping. Phase 09 must re-check every row against the actual deployed product and delivery receipts. The binding xplainervideo correction supersedes the original airesearch12 account reference everywhere, including vendor-release searches in phase 05.


FILE ops/rebuild-2026-09/evidence/phase-07/domain-change.json
{
  "at": "2026-09-11T01:56:38.243580+00:00",
  "domain": "benchmarkheaven.com",
  "ui": "https://ap.www.namecheap.com/domains/domaincontrolpanel/benchmarkheaven.com/advancedns",
  "method": "Existing Sandy Chrome saved login, then Advanced DNS; no challenge or mail confirmation required. Replaced parking CNAME www and URL redirect @ with two A records. Save all changes succeeded in UI.",
  "records": [
    {
      "type": "A",
      "host": "@",
      "value": "65.109.49.103",
      "ttl": 1800
    },
    {
      "type": "A",
      "host": "www",
      "value": "65.109.49.103",
      "ttl": 1800
    }
  ],
  "mail_records": "Unmodified.",
  "propagation": "Verified in dns-checks.json on both authoritative nameservers and three public resolvers; the local resolver also returned 65.109.49.103 at 02:24 UTC.",
  "browser_screenshots": "Private outside repository; public DNS execution evidence follows."
}


FILE ops/rebuild-2026-09/evidence/phase-07/dns-checks.json
{
  "at": "2026-09-11T02:09:02.564231+00:00",
  "queries": [
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com A @dns1.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 22611\n;; flags: qr aa rd; QUERY: 1, ANSWER: 1, AUTHORITY: 2, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n;; ANSWER SECTION:\nbenchmarkheaven.com.\t1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com AAAA @dns1.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 26055\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com CAA @dns1.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 16582\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com A @dns2.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 52208\n;; flags: qr aa rd; QUERY: 1, ANSWER: 1, AUTHORITY: 2, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n;; ANSWER SECTION:\nbenchmarkheaven.com.\t1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com AAAA @dns2.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 32007\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com CAA @dns2.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 17126\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com A @1.1.1.1",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 50625\n;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n;; ANSWER SECTION:\nbenchmarkheaven.com.\t1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com AAAA @1.1.1.1",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 28685\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com CAA @1.1.1.1",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 64358\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com A @8.8.8.8",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 16657\n;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n;; ANSWER SECTION:\nbenchmarkheaven.com.\t1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com AAAA @8.8.8.8",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 61438\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com CAA @8.8.8.8",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 49066\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com A @9.9.9.9",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 56562\n;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n;; ANSWER SECTION:\nbenchmarkheaven.com.\t1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com AAAA @9.9.9.9",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 404\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com CAA @9.9.9.9",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 1384\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com A @dns1.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 29857\n;; flags: qr aa rd; QUERY: 1, ANSWER: 1, AUTHORITY: 2, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n;; ANSWER SECTION:\nwww.benchmarkheaven.com. 1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com AAAA @dns1.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 11442\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com CAA @dns1.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 38762\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com A @dns2.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 20128\n;; flags: qr aa rd; QUERY: 1, ANSWER: 1, AUTHORITY: 2, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n;; ANSWER SECTION:\nwww.benchmarkheaven.com. 1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com AAAA @dns2.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 24453\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com CAA @dns2.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 24080\n;; flags: qr aa rd; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com A @1.1.1.1",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 54790\n;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n;; ANSWER SECTION:\nwww.benchmarkheaven.com. 1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com AAAA @1.1.1.1",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 49000\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com CAA @1.1.1.1",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 20264\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com A @8.8.8.8",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 9783\n;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n;; ANSWER SECTION:\nwww.benchmarkheaven.com. 1521\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com AAAA @8.8.8.8",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 26367\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com CAA @8.8.8.8",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 1042\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 512\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com A @9.9.9.9",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 14211\n;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n;; ANSWER SECTION:\nwww.benchmarkheaven.com. 1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com AAAA @9.9.9.9",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 1571\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n"
    },
    {
      "command": "dig +time=3 +tries=1 +noall +answer +comments www.benchmarkheaven.com CAA @9.9.9.9",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 14726\n;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 1232\n"
    },
    {
      "command": "dig +tcp +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com A @dns1.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 33510\n;; flags: qr aa rd; QUERY: 1, ANSWER: 1, AUTHORITY: 2, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n;; ANSWER SECTION:\nbenchmarkheaven.com.\t1800\tIN\tA\t65.109.49.103\n\n"
    },
    {
      "command": "dig +tcp +time=3 +tries=1 +noall +answer +comments benchmarkheaven.com A @dns2.registrar-servers.com",
      "exit": 0,
      "output": ";; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 51318\n;; flags: qr aa rd; QUERY: 1, ANSWER: 1, AUTHORITY: 2, ADDITIONAL: 1\n;; WARNING: recursion requested but not available\n\n;; OPT PSEUDOSECTION:\n; EDNS: version: 0, flags:; udp: 4096\n;; ANSWER SECTION:\nbenchmarkheaven.com.\t1800\tIN\tA\t65.109.49.103\n\n"
    }
  ]
}


FILE ops/rebuild-2026-09/evidence/phase-07/domain-rdap.json
{
  "url": "https://rdap.verisign.com/com/v1/domain/benchmarkheaven.com",
  "public_fields": {
    "ldhName": "BENCHMARKHEAVEN.COM",
    "status": [
      "client transfer prohibited"
    ],
    "nameservers": [
      {
        "objectClassName": "nameserver",
        "ldhName": "DNS1.REGISTRAR-SERVERS.COM"
      },
      {
        "objectClassName": "nameserver",
        "ldhName": "DNS2.REGISTRAR-SERVERS.COM"
      }
    ],
    "events": [
      {
        "eventAction": "registration",
        "eventDate": "2026-09-10T17:53:18Z"
      },
      {
        "eventAction": "expiration",
        "eventDate": "2027-09-10T17:53:18Z"
      },
      {
        "eventAction": "last changed",
        "eventDate": "2026-09-10T17:53:22Z"
      },
      {
        "eventAction": "last update of RDAP database",
        "eventDate": "2026-09-11T02:09:06Z"
      }
    ]
  }
}


FILE ops/rebuild-2026-09/evidence/phase-07/coolify-domains.json
{
  "ok": true,
  "data": {
    "uuid": "ggbs6upie6tqsousmrkw0vja",
    "name": "Benchmark Heaven",
    "fqdn": "https://benchmarkheaven.com,https://www.benchmarkheaven.com,https://model-market-comparison.app.mintapis.com",
    "status": "running:unknown",
    "git_repository": "fstandhartinger/model-market-comparison",
    "git_branch": "main",
    "git_commit_sha": "HEAD",
    "build_pack": "dockerfile",
    "base_directory": "/",
    "ports_exposes": "3000",
    "health_check_enabled": false,
    "health_check_path": "/api/health",
    "health_check_method": "GET",
    "limits_memory": "768M",
    "limits_cpus": "1",
    "created_at": "2026-08-26T15:13:34.000000Z",
    "updated_at": "2026-09-11T01:56:02.000000Z"
  },
  "meta": {
    "idempotency_replay": false
  }
}


FILE ops/rebuild-2026-09/evidence/phase-07/domain-primary-extract.txt
Source: https://coolify.io/docs/core/networking/domains
Retrieved through web browser tool 2026-09-11. Direct urllib fetch returned HTTP403; no bypass attempted.

Exact source excerpt: “If DNS was changed recently, you may need to wait for the previous record’s TTL to expire.”

Source table (column value): https://app.example.com,https://www.example.com

Paraphrase: Configure DNS to reach the application server, configure complete HTTPS URLs in Coolify, save and redeploy, then verify DNS, the application and its certificate. HTTPS domains cause the integrated proxy to request and renew certificates. Multiple hostnames can serve the application concurrently.

The user’s primary instruction specifies these exact records: benchmarkheaven.com and www -> 65.109.49.103; app ggbs6upie6tqsousmrkw0vja; keep model-market-comparison.app.mintapis.com working.


FILE ops/rebuild-2026-09/evidence/phase-07/certificate-initial-errors.log
2026-09-11T01:57:42Z ERR Unable to obtain ACME certificate for domains error="unable to generate a certificate for the domains [www.benchmarkheaven.com]: resolver: one or more domains had a problem: [www.benchmarkheaven.com: invalid authorization: acme: error: 400 :: urn:ietf:params:acme:error:dns :: During secondary validation: DNS problem: networking error looking up A for www.benchmarkheaven.com; DNS problem: networking error looking up AAAA for www.benchmarkheaven.com]" ACME CA=https://acme-v02.api.letsencrypt.org/directory acmeCA=https://acme-v02.api.letsencrypt.org/directory domains=["www.benchmarkheaven.com"] providerName=letsencrypt.acme routerName=https-1-ggbs6upie6tqsousmrkw0vja@docker rule="Host(`www.benchmarkheaven.com`) && PathPrefix(`/`)"
2026-09-11T01:58:12Z ERR Unable to obtain ACME certificate for domains error="unable to generate a certificate for the domains [www.benchmarkheaven.com]: resolver: one or more domains had a problem: [www.benchmarkheaven.com: invalid authorization: acme: error: 400 :: urn:ietf:params:acme:error:dns :: During secondary validation: DNS problem: networking error looking up A for www.benchmarkheaven.com; DNS problem: networking error looking up AAAA for www.benchmarkheaven.com]" ACME CA=https://acme-v02.api.letsencrypt.org/directory acmeCA=https://acme-v02.api.letsencrypt.org/directory domains=["www.benchmarkheaven.com"] providerName=letsencrypt.acme routerName=https-1-ggbs6upie6tqsousmrkw0vja@docker rule="Host(`www.benchmarkheaven.com`) && PathPrefix(`/`)"
2026-09-11T01:58:12Z ERR Unable to obtain ACME certificate for domains error="unable to generate a certificate for the domains [benchmarkheaven.com]: resolver: one or more domains had a problem: [benchmarkheaven.com: invalid authorization: acme: error: 400 :: urn:ietf:params:acme:error:dns :: During secondary validation: DNS problem: networking error looking up A for benchmarkheaven.com; DNS problem: networking error looking up AAAA for benchmarkheaven.com]" ACME CA=https://acme-v02.api.letsencrypt.org/directory acmeCA=https://acme-v02.api.letsencrypt.org/directory domains=["benchmarkheaven.com"] providerName=letsencrypt.acme routerName=https-0-ggbs6upie6tqsousmrkw0vja@docker rule="Host(`benchmarkheaven.com`) && PathPrefix(`/`)"


FILE ops/rebuild-2026-09/evidence/phase-07/letsencrypt-status.txt
Source: https://letsencrypt.status.io/
Captured 2026-09-11 02:12 UTC. Primary status-page text fetched by curl; the earlier web-tool snapshot still showed the initial investigating update.

Exact incident excerpt: "We have identified an issue with our DNS resolver in our secondary validation."

Status-page facts, paraphrased: Domain Control Validation was partly disrupted on production and staging. The incident began at 01:40 UTC. An update at 02:11 UTC marked the issue identified, said the change was being reverted, and estimated recovery within 15 minutes. This matches our secondary DNS validation error, but is not proof of recovery for our certificate. The final SSL check is still required.


FILE ops/rebuild-2026-09/evidence/phase-07/letsdebug-result.txt
Source: https://letsdebug.net/benchmarkheaven.com/3149892
HTTP-01 diagnostic requested 2026-09-11 02:11 UTC
 Let's Debug Let's Debug Test result for benchmarkheaven.com using http-01 All OK! OK No issues were found with benchmarkheaven.com. If you are having problems with creating an SSL certificate, please visit the Let's Encrypt Community forums and post a question there. StatusNotOperational Info The current status as reported by the Let's Encrypt status page is Partial Service Disruption as at 2026-09-11 01:40:45.3 +0000 UTC. Depending on the reported problem, this may affect certificate issuance. For more information, please visit the status page. https://letsencrypt.status.io/ Submitted 31s ago . Sat in queue for 2ms. Completed in 4s. Show verbose information. We also have open-source API and CLI tools , as well as web-based certificate search and certificate revocation. Let's Encrypt™ is a trademark of the Internet Security Research Group (ISRG). Let's Debug is not affiliated with, or sponsored or endorsed by, ISRG.


FILE ops/rebuild-2026-09/evidence/phase-07/domain-activation-deployment.json
{
  "ok": true,
  "data": {
    "deployment_uuid": "doblw9veld5qskwbuhjpqpsw",
    "application_id": "3",
    "application_name": "Benchmark Heaven",
    "commit": "d8f0ac290d186676ddb87384d49aee62bbe9a27f",
    "commit_message": "Record phase 06 verified UI and patched runtime release\n\nRetain complete live dataset and source checks, rendered public comparison flows, successful Sandy deployment and exact deployed package versions. Close Phase 06 coverage with explicit source, timing and conformance limits. Tested application code, dependency lock and dataset are unchanged.\n\nCo-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>",
    "status": "finished",
    "pull_request_id": 0,
    "force_rebuild": false,
    "restart_only": false,
    "rollback": false,
    "is_api": true,
    "is_webhook": false,
    "created_at": "2026-09-11T02:27:02.000000Z",
    "updated_at": "2026-09-11T02:27:46.000000Z",
    "deployment_url": "/project/qpztsc5m7bpiphpwkskyqouv/environment/cosufmmbioifcdsgycefeyxg/application/ggbs6upie6tqsousmrkw0vja/deployment/doblw9veld5qskwbuhjpqpsw"
  },
  "meta": {
    "idempotency_replay": false
  }
}


FILE ops/rebuild-2026-09/evidence/phase-07/tls-pre-release.json
{
  "at": "2026-09-11T02:28:27.292086+00:00",
  "stage": "pre-release",
  "hosts": [
    {
      "host": "benchmarkheaven.com",
      "public_dns": {
        "1.1.1.1": "65.109.49.103",
        "8.8.8.8": "65.109.49.103"
      },
      "tls": {
        "subject": [
          [
            [
              "commonName",
              "benchmarkheaven.com"
            ]
          ]
        ],
        "subjectAltName": [
          [
            "DNS",
            "benchmarkheaven.com"
          ]
        ],
        "issuer": [
          [
            [
              "countryName",
              "US"
            ]
          ],
          [
            [
              "organizationName",
              "Let's Encrypt"
            ]
          ],
          [
            [
              "commonName",
              "YR1"
            ]
          ]
        ],
        "notBefore": "Sep 11 01:28:47 2026 GMT",
        "notAfter": "Dec 10 01:28:46 2026 GMT",
        "sha256": "295b2073223bad63ea8280db4c401ccc334bde147176b769913e52a4837de2d6",
        "version": "TLSv1.3",
        "chain_and_hostname_verified": true,
        "connection_ip": "65.109.49.103"
      },
      "requests": [
        {
          "path": "/api/health",
          "status": 200,
          "final_url": "https://benchmarkheaven.com/api/health",
          "cors": "*",
          "json": {
            "ok": true,
            "db": false
          }
        },
        {
          "path": "/api/meta",
          "status": 200,
          "final_url": "https://benchmarkheaven.com/api/meta",
          "cors": "*",
          "json": {
            "generated_at": "2026-09-11T01:28:15.062Z",
            "counts": {
              "models": 835,
              "families": 650,
              "providers": 89,
              "offers": 2786
            },
            "sources": {
              "openrouter": "2026-09-10",
              "artificialanalysis": "2026-09-10",
              "designarena": "2026-09-10",
              "aws_bedrock": "2026-09-08",
              "azure_foundry": "2026-09-08",
              "google_vertex": "2026-09-08",
              "nebius": "2026-09-08",
              "inceptron": "2026-09-08",
              "scaleway": "2026-09-08",
              "ionos": "2026-09-08",
              "mistral": "2026-09-08",
              "tensorx": "2026-09-08",
              "chutes": "2026-09-08",
              "ovhcloud": "2026-09-08",
              "stackit": "2026-09-08",
              "t_systems_llm_hub": "2026-09-08",
              "aa_coding_agents": "2026-09-09",
              "github_copilot": "2026-09-08",
              "claude_code": "2026-09-08",
              "aa_coding_agents_v1_5": "2026-09-10",
              "provider_meta": "2026-07-12",
              "aa_efficiency": "2026-09-10T20:13:54.198Z",
              "openrouter_efficiency": "2026-09-10T20:13:54.306Z",
              "chutes_efficiency": "2026-09-10T19:44:35.632Z"
            },
            "source": "bundled"
          }
        }
      ],
      "http_redirect_preserves_path_query": true
    },
    {
      "host": "www.benchmarkheaven.com",
      "public_dns": {
        "1.1.1.1": "65.109.49.103",
        "8.8.8.8": "65.109.49.103"
      },
      "tls": {
        "subject": [
          [
            [
              "commonName",
              "www.benchmarkheaven.com"
            ]
          ]
        ],
        "subjectAltName": [
          [
            "DNS",
            "www.benchmarkheaven.com"
          ]
        ],
        "issuer": [
          [
            [
              "countryName",
              "US"
            ]
          ],
          [
            [
              "organizationName",
              "Let's Encrypt"
            ]
          ],
          [
            [
              "commonName",
              "YR2"
            ]
          ]
        ],
        "notBefore": "Sep 11 01:28:47 2026 GMT",
        "notAfter": "Dec 10 01:28:46 2026 GMT",
        "sha256": "2ea141a5a78ae9fcb33ef75a257d37314506f1a95cc01c94362c9db75a84775e",
        "version": "TLSv1.3",
        "chain_and_hostname_verified": true,
        "connection_ip": "65.109.49.103"
      },
      "requests": [
        {
          "path": "/api/health",
          "status": 200,
          "final_url": "https://www.benchmarkheaven.com/api/health",
          "cors": "*",
          "json": {
            "ok": true,
            "db": false
          }
        },
        {
          "path": "/api/meta",
          "status": 200,
          "final_url": "https://www.benchmarkheaven.com/api/meta",
          "cors": "*",
          "json": {
            "generated_at": "2026-09-11T01:28:15.062Z",
            "counts": {
              "models": 835,
              "families": 650,
              "providers": 89,
              "offers": 2786
            },
            "sources": {
              "openrouter": "2026-09-10",
              "artificialanalysis": "2026-09-10",
              "designarena": "2026-09-10",
              "aws_bedrock": "2026-09-08",
              "azure_foundry": "2026-09-08",
              "google_vertex": "2026-09-08",
              "nebius": "2026-09-08",
              "inceptron": "2026-09-08",
              "scaleway": "2026-09-08",
              "ionos": "2026-09-08",
              "mistral": "2026-09-08",
              "tensorx": "2026-09-08",
              "chutes": "2026-09-08",
              "ovhcloud": "2026-09-08",
              "stackit": "2026-09-08",
              "t_systems_llm_hub": "2026-09-08",
              "aa_coding_agents": "2026-09-09",
              "github_copilot": "2026-09-08",
              "claude_code": "2026-09-08",
              "aa_coding_agents_v1_5": "2026-09-10",
              "provider_meta": "2026-07-12",
              "aa_efficiency": "2026-09-10T20:13:54.198Z",
              "openrouter_efficiency": "2026-09-10T20:13:54.306Z",
              "chutes_efficiency": "2026-09-10T19:44:35.632Z"
            },
            "source": "bundled"
          }
        }
      ],
      "http_redirect_preserves_path_query": true
    },
    {
      "host": "model-market-comparison.app.mintapis.com",
      "public_dns": {
        "1.1.1.1": "65.109.49.103",
        "8.8.8.8": "65.109.49.103"
      },
      "tls": {
        "subject": [
          [
            [
              "commonName",
              "model-market-comparison.app.mintapis.com"
            ]
          ]
        ],
        "subjectAltName": [
          [
            "DNS",
            "model-market-comparison.app.mintapis.com"
          ]
        ],
        "issuer": [
          [
            [
              "countryName",
              "US"
            ]
          ],
          [
            [
              "organizationName",
              "Let's Encrypt"
            ]
          ],
          [
            [
              "commonName",
              "YR1"
            ]
          ]
        ],
        "notBefore": "Aug 26 16:12:47 2026 GMT",
        "notAfter": "Nov 24 16:12:46 2026 GMT",
        "sha256": "2c0c7d1efa55b81bff29bf92b4ce9f39e7a53423dc31ccc48f9048153e9c4840",
        "version": "TLSv1.3",
        "chain_and_hostname_verified": true,
        "connection_ip": "65.109.49.103"
      },
      "requests": [
        {
          "path": "/api/health",
          "status": 200,
          "final_url": "https://model-market-comparison.app.mintapis.com/api/health",
          "cors": "*",
          "json": {
            "ok": true,
            "db": false
          }
        },
        {
          "path": "/api/meta",
          "status": 200,
          "final_url": "https://model-market-comparison.app.mintapis.com/api/meta",
          "cors": "*",
          "json": {
            "generated_at": "2026-09-11T01:28:15.062Z",
            "counts": {
              "models": 835,
              "families": 650,
              "providers": 89,
              "offers": 2786
            },
            "sources": {
              "openrouter": "2026-09-10",
              "artificialanalysis": "2026-09-10",
              "designarena": "2026-09-10",
              "aws_bedrock": "2026-09-08",
              "azure_foundry": "2026-09-08",
              "google_vertex": "2026-09-08",
              "nebius": "2026-09-08",
              "inceptron": "2026-09-08",
              "scaleway": "2026-09-08",
              "ionos": "2026-09-08",
              "mistral": "2026-09-08",
              "tensorx": "2026-09-08",
              "chutes": "2026-09-08",
              "ovhcloud": "2026-09-08",
              "stackit": "2026-09-08",
              "t_systems_llm_hub": "2026-09-08",
              "aa_coding_agents": "2026-09-09",
              "github_copilot": "2026-09-08",
              "claude_code": "2026-09-08",
              "aa_coding_agents_v1_5": "2026-09-10",
              "provider_meta": "2026-07-12",
              "aa_efficiency": "2026-09-10T20:13:54.198Z",
              "openrouter_efficiency": "2026-09-10T20:13:54.306Z",
              "chutes_efficiency": "2026-09-10T19:44:35.632Z"
            },
            "source": "bundled"
          }
        }
      ],
      "http_redirect_preserves_path_query": true
    }
  ],
  "same_api_metadata_all_hosts": true
}


FILE ops/rebuild-2026-09/evidence/phase-07/release-deployment.json
{
  "ok": true,
  "data": {
    "deployment_uuid": "fuotj6trvelbn2sqz7idk5xo",
    "application_id": "3",
    "application_name": "Benchmark Heaven",
    "commit": "989ce7d3b6d17c909a2470e06fa9bb64fd371a96",
    "commit_message": "Rebrand the comparison app as Benchmark Heaven\n\nIntroduce the Observatory mark, editorial identity, icons and social card; apply the brand across UI, docs, fork guidance and daily message templates. Configure and verify both new HTTPS domains while retaining the original API hostname. Preserve the dataset and consumer contracts.\n\nValidated with dataset build, 146 tests, typecheck, production build, 11 prerender checks, rendered accessibility/keyboard checks and independent brand/documentation critics. Record the recovered certificate-authority incident and trusted domain activation.\n\nCo-Authored-By: Codex GPT-6 Astra (Sandy rebuild) <noreply@openai.com>",
    "status": "finished",
    "pull_request_id": 0,
    "force_rebuild": false,
    "restart_only": false,
    "rollback": false,
    "is_api": false,
    "is_webhook": true,
    "created_at": "2026-09-11T02:28:40.000000Z",
    "updated_at": "2026-09-11T02:31:01.000000Z",
    "deployment_url": "/project/qpztsc5m7bpiphpwkskyqouv/environment/cosufmmbioifcdsgycefeyxg/application/ggbs6upie6tqsousmrkw0vja/deployment/fuotj6trvelbn2sqz7idk5xo"
  },
  "meta": {
    "idempotency_replay": false
  }
}


FILE ops/rebuild-2026-09/evidence/phase-07/tls-release.json
{
  "at": "2026-09-11T02:33:00.737405+00:00",
  "stage": "release",
  "hosts": [
    {
      "host": "benchmarkheaven.com",
      "public_dns": {
        "1.1.1.1": "65.109.49.103",
        "8.8.8.8": "65.109.49.103"
      },
      "tls": {
        "subject": [
          [
            [
              "commonName",
              "benchmarkheaven.com"
            ]
          ]
        ],
        "subjectAltName": [
          [
            "DNS",
            "benchmarkheaven.com"
          ]
        ],
        "issuer": [
          [
            [
              "countryName",
              "US"
            ]
          ],
          [
            [
              "organizationName",
              "Let's Encrypt"
            ]
          ],
          [
            [
              "commonName",
              "YR1"
            ]
          ]
        ],
        "notBefore": "Sep 11 01:28:47 2026 GMT",
        "notAfter": "Dec 10 01:28:46 2026 GMT",
        "sha256": "295b2073223bad63ea8280db4c401ccc334bde147176b769913e52a4837de2d6",
        "version": "TLSv1.3",
        "chain_and_hostname_verified": true,
        "connection_ip": "65.109.49.103"
      },
      "requests": [
        {
          "path": "/api/health",
          "status": 200,
          "final_url": "https://benchmarkheaven.com/api/health",
          "cors": "*",
          "json": {
            "ok": true,
            "db": false
          }
        },
        {
          "path": "/api/meta",
          "status": 200,
          "final_url": "https://benchmarkheaven.com/api/meta",
          "cors": "*",
          "json": {
            "generated_at": "2026-09-11T02:14:45.641Z",
            "counts": {
              "models": 835,
              "families": 650,
              "providers": 89,
              "offers": 2786
            },
            "sources": {
              "openrouter": "2026-09-10",
              "artificialanalysis": "2026-09-10",
              "designarena": "2026-09-10",
              "aws_bedrock": "2026-09-08",
              "azure_foundry": "2026-09-08",
              "google_vertex": "2026-09-08",
              "nebius": "2026-09-08",
              "inceptron": "2026-09-08",
              "scaleway": "2026-09-08",
              "ionos": "2026-09-08",
              "mistral": "2026-09-08",
              "tensorx": "2026-09-08",
              "chutes": "2026-09-08",
              "ovhcloud": "2026-09-08",
              "stackit": "2026-09-08",
              "t_systems_llm_hub": "2026-09-08",
              "aa_coding_agents": "2026-09-09",
              "github_copilot": "2026-09-08",
              "claude_code": "2026-09-08",
              "aa_coding_agents_v1_5": "2026-09-10",
              "provider_meta": "2026-07-12",
              "aa_efficiency": "2026-09-10T20:13:54.198Z",
              "openrouter_efficiency": "2026-09-10T20:13:54.306Z",
              "chutes_efficiency": "2026-09-10T19:44:35.632Z"
            },
            "source": "bundled"
          }
        }
      ],
      "http_redirect_preserves_path_query": true
    },
    {
      "host": "www.benchmarkheaven.com",
      "public_dns": {
        "1.1.1.1": "65.109.49.103",
        "8.8.8.8": "65.109.49.103"
      },
      "tls": {
        "subject": [
          [
            [
              "commonName",
              "www.benchmarkheaven.com"
            ]
          ]
        ],
        "subjectAltName": [
          [
            "DNS",
            "www.benchmarkheaven.com"
          ]
        ],
        "issuer": [
          [
            [
              "countryName",
              "US"
            ]
          ],
          [
            [
              "organizationName",
              "Let's Encrypt"
            ]
          ],
          [
            [
              "commonName",
              "YR2"
            ]
          ]
        ],
        "notBefore": "Sep 11 01:28:47 2026 GMT",
        "notAfter": "Dec 10 01:28:46 2026 GMT",
        "sha256": "2ea141a5a78ae9fcb33ef75a257d37314506f1a95cc01c94362c9db75a84775e",
        "version": "TLSv1.3",
        "chain_and_hostname_verified": true,
        "connection_ip": "65.109.49.103"
      },
      "requests": [
        {
          "path": "/api/health",
          "status": 200,
          "final_url": "https://www.benchmarkheaven.com/api/health",
          "cors": "*",
          "json": {
            "ok": true,
            "db": false
          }
        },
        {
          "path": "/api/meta",
          "status": 200,
          "final_url": "https://www.benchmarkheaven.com/api/meta",
          "cors": "*",
          "json": {
            "generated_at": "2026-09-11T02:14:45.641Z",
            "counts": {
              "models": 835,
              "families": 650,
              "providers": 89,
              "offers": 2786
            },
            "sources": {
              "openrouter": "2026-09-10",
              "artificialanalysis": "2026-09-10",
              "designarena": "2026-09-10",
              "aws_bedrock": "2026-09-08",
              "azure_foundry": "2026-09-08",
              "google_vertex": "2026-09-08",
              "nebius": "2026-09-08",
              "inceptron": "2026-09-08",
              "scaleway": "2026-09-08",
              "ionos": "2026-09-08",
              "mistral": "2026-09-08",
              "tensorx": "2026-09-08",
              "chutes": "2026-09-08",
              "ovhcloud": "2026-09-08",
              "stackit": "2026-09-08",
              "t_systems_llm_hub": "2026-09-08",
              "aa_coding_agents": "2026-09-09",
              "github_copilot": "2026-09-08",
              "claude_code": "2026-09-08",
              "aa_coding_agents_v1_5": "2026-09-10",
              "provider_meta": "2026-07-12",
              "aa_efficiency": "2026-09-10T20:13:54.198Z",
              "openrouter_efficiency": "2026-09-10T20:13:54.306Z",
              "chutes_efficiency": "2026-09-10T19:44:35.632Z"
            },
            "source": "bundled"
          }
        }
      ],
      "http_redirect_preserves_path_query": true
    },
    {
      "host": "model-market-comparison.app.mintapis.com",
      "public_dns": {
        "1.1.1.1": "65.109.49.103",
        "8.8.8.8": "65.109.49.103"
      },
      "tls": {
        "subject": [
          [
            [
              "commonName",
              "model-market-comparison.app.mintapis.com"
            ]
          ]
        ],
        "subjectAltName": [
          [
            "DNS",
            "model-market-comparison.app.mintapis.com"
          ]
        ],
        "issuer": [
          [
            [
              "countryName",
              "US"
            ]
          ],
          [
            [
              "organizationName",
              "Let's Encrypt"
            ]
          ],
          [
            [
              "commonName",
              "YR1"
            ]
          ]
        ],
        "notBefore": "Aug 26 16:12:47 2026 GMT",
        "notAfter": "Nov 24 16:12:46 2026 GMT",
        "sha256": "2c0c7d1efa55b81bff29bf92b4ce9f39e7a53423dc31ccc48f9048153e9c4840",
        "version": "TLSv1.3",
        "chain_and_hostname_verified": true,
        "connection_ip": "65.109.49.103"
      },
      "requests": [
        {
          "path": "/api/health",
          "status": 200,
          "final_url": "https://model-market-comparison.app.mintapis.com/api/health",
          "cors": "*",
          "json": {
            "ok": true,
            "db": false
          }
        },
        {
          "path": "/api/meta",
          "status": 200,
          "final_url": "https://model-market-comparison.app.mintapis.com/api/meta",
          "cors": "*",
          "json": {
            "generated_at": "2026-09-11T02:14:45.641Z",
            "counts": {
              "models": 835,
              "families": 650,
              "providers": 89,
              "offers": 2786
            },
            "sources": {
              "openrouter": "2026-09-10",
              "artificialanalysis": "2026-09-10",
              "designarena": "2026-09-10",
              "aws_bedrock": "2026-09-08",
              "azure_foundry": "2026-09-08",
              "google_vertex": "2026-09-08",
              "nebius": "2026-09-08",
              "inceptron": "2026-09-08",
              "scaleway": "2026-09-08",
              "ionos": "2026-09-08",
              "mistral": "2026-09-08",
              "tensorx": "2026-09-08",
              "chutes": "2026-09-08",
              "ovhcloud": "2026-09-08",
              "stackit": "2026-09-08",
              "t_systems_llm_hub": "2026-09-08",
              "aa_coding_agents": "2026-09-09",
              "github_copilot": "2026-09-08",
              "claude_code": "2026-09-08",
              "aa_coding_agents_v1_5": "2026-09-10",
              "provider_meta": "2026-07-12",
              "aa_efficiency": "2026-09-10T20:13:54.198Z",
              "openrouter_efficiency": "2026-09-10T20:13:54.306Z",
              "chutes_efficiency": "2026-09-10T19:44:35.632Z"
            },
            "source": "bundled"
          }
        }
      ],
      "http_redirect_preserves_path_query": true
    }
  ],
  "same_api_metadata_all_hosts": true
}


FILE ops/rebuild-2026-09/evidence/phase-07/live-apex-api.json
{
  "at": "2026-09-11T02:32:48.616Z",
  "base": "https://benchmarkheaven.com",
  "results": [
    {
      "path": "/",
      "status": 200,
      "brand": true
    },
    {
      "path": "/compare",
      "status": 200,
      "brand": true
    },
    {
      "path": "/benchmarks",
      "status": 200,
      "brand": true
    },
    {
      "path": "/radar",
      "status": 200,
      "brand": true
    },
    {
      "path": "/about",
      "status": 200,
      "brand": true
    },
    {
      "path": "/models/gpt-5.6-sol%3A%3Ahigh",
      "status": 200,
      "brand": true
    },
    {
      "path": "/api/dataset",
      "status": 200,
      "cors": "*",
      "fullDatasetEquality": true,
      "generated_at": "2026-09-11T02:14:45.641Z"
    },
    {
      "path": "/api/meta",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/health",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/benchmarks",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/benchmark-scores?limit=1",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/models?score=composite",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/providers",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/models/gpt-5.6-sol%3A%3Ahigh",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/dataset",
      "method": "OPTIONS",
      "status": 204,
      "cors": "*"
    }
  ]
}


FILE ops/rebuild-2026-09/evidence/phase-07/live-www-api.json
{
  "at": "2026-09-11T02:32:57.663Z",
  "base": "https://www.benchmarkheaven.com",
  "results": [
    {
      "path": "/",
      "status": 200,
      "brand": true
    },
    {
      "path": "/compare",
      "status": 200,
      "brand": true
    },
    {
      "path": "/benchmarks",
      "status": 200,
      "brand": true
    },
    {
      "path": "/radar",
      "status": 200,
      "brand": true
    },
    {
      "path": "/about",
      "status": 200,
      "brand": true
    },
    {
      "path": "/models/gpt-5.6-sol%3A%3Ahigh",
      "status": 200,
      "brand": true
    },
    {
      "path": "/api/dataset",
      "status": 200,
      "cors": "*",
      "fullDatasetEquality": true,
      "generated_at": "2026-09-11T02:14:45.641Z"
    },
    {
      "path": "/api/meta",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/health",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/benchmarks",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/benchmark-scores?limit=1",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/models?score=composite",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/providers",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/models/gpt-5.6-sol%3A%3Ahigh",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/dataset",
      "method": "OPTIONS",
      "status": 204,
      "cors": "*"
    }
  ]
}


FILE ops/rebuild-2026-09/evidence/phase-07/live-compatibility-api.json
{
  "at": "2026-09-11T02:32:59.949Z",
  "base": "https://model-market-comparison.app.mintapis.com",
  "results": [
    {
      "path": "/",
      "status": 200,
      "brand": true
    },
    {
      "path": "/compare",
      "status": 200,
      "brand": true
    },
    {
      "path": "/benchmarks",
      "status": 200,
      "brand": true
    },
    {
      "path": "/radar",
      "status": 200,
      "brand": true
    },
    {
      "path": "/about",
      "status": 200,
      "brand": true
    },
    {
      "path": "/models/gpt-5.6-sol%3A%3Ahigh",
      "status": 200,
      "brand": true
    },
    {
      "path": "/api/dataset",
      "status": 200,
      "cors": "*",
      "fullDatasetEquality": true,
      "generated_at": "2026-09-11T02:14:45.641Z"
    },
    {
      "path": "/api/meta",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/health",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/benchmarks",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/benchmark-scores?limit=1",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/models?score=composite",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/providers",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/models/gpt-5.6-sol%3A%3Ahigh",
      "status": 200,
      "cors": "*"
    },
    {
      "path": "/api/dataset",
      "method": "OPTIONS",
      "status": 204,
      "cors": "*"
    }
  ]
}


FILE ops/rebuild-2026-09/evidence/phase-07/live/browser.json
{
  "at": "2026-09-11T02:34:05.916Z",
  "base": "https://benchmarkheaven.com",
  "brand": true,
  "threeModelComparison": true,
  "mobileNoOverflow": true,
  "themeToggle": true,
  "publishedSocialPngMatches": true,
  "errors": []
}


FILE ops/rebuild-2026-09/evidence/phase-07/live/first-browser-probe.json
{
  "result": "incomplete",
  "completed_before_failure": [
    "branded root page",
    "three-model compare interaction"
  ],
  "failure": "30-second wait for Toggle color theme button after a mobile root navigation timed out. The failed page DOM was not captured in that first probe.",
  "followup": "Fresh instrumented browser run captured the page/tree, found one theme button, exercised it successfully and reported no page runtime errors. Container logs showed normal startup. No application change was made.",
  "root_cause": "not established; do not label this as a diagnosed app or network defect"
}


FILE ops/rebuild-2026-09/evidence/phase-07/final-checks.json
{
  "at": "2026-09-11T02:16:02.996394+00:00",
  "checks": [
    {
      "command": [
        "node",
        "scripts/build-dataset.mjs"
      ],
      "exit": 0,
      "log": "ops/rebuild-2026-09/evidence/phase-07/dataset-final.log"
    },
    {
      "command": [
        "npm",
        "test"
      ],
      "exit": 0,
      "log": "ops/rebuild-2026-09/evidence/phase-07/tests-final.log"
    },
    {
      "command": [
        "npx",
        "tsc",
        "--noEmit",
        "-p",
        "."
      ],
      "exit": 0,
      "log": "ops/rebuild-2026-09/evidence/phase-07/typecheck-final.log"
    },
    {
      "command": [
        "npm",
        "run",
        "build"
      ],
      "exit": 0,
      "log": "ops/rebuild-2026-09/evidence/phase-07/build-final.log.gz"
    },
    {
      "command": [
        "node",
        "--test",
        "test/production/prerender.mjs"
      ],
      "exit": 0,
      "log": "ops/rebuild-2026-09/evidence/phase-07/prerender-final.log"
    },
    {
      "command": [
        "git",
        "diff",
        "--check"
      ],
      "exit": 0,
      "log": "ops/rebuild-2026-09/evidence/phase-07/whitespace-final.log"
    }
  ]
}


FILE ops/rebuild-2026-09/evidence/phase-07/final-source-hashes.json
{
  "reviews": [
    {
      "artifact": "ui-r3",
      "source_images_input_output_match": true
    },
    {
      "artifact": "docs-r2",
      "source_images_input_output_match": true
    }
  ],
  "all_archive_hashes_match": true,
  "code_data_revision": "989ce7d3b6d17c909a2470e06fa9bb64fd371a96"
}


FILE ops/rebuild-2026-09/evidence/phase-07/daily-installed.json
{
  "at": "2026-09-11T02:09:42.369787+00:00",
  "files": [
    {
      "source": "ops/rebuild-2026-09/daily-refresh-prompt.md",
      "installed": "/opt/mmc-daily/prompt.md",
      "sha256": "943ac99621b0c69ba3a6df8bf7217c7554a50e3760db0198f0ac4f6c7deabe3a",
      "equal": true
    },
    {
      "source": "ops/daily/run.sh",
      "installed": "/opt/mmc-daily/run.sh",
      "sha256": "39a9ee2c0c62880eedd29bed24aaa2ef4a77ff63fa2cc41470532d5761dcb34f",
      "equal": true
    }
  ],
  "schedule": [
    "17 5 * * * /opt/mmc-daily/run.sh"
  ],
  "scope": "Message branding, public URL and current existing prompt mirrored. No cadence, state, callback paths or quiet-policy change. No daily refresh or Telegram send executed.",
  "schedule_owner": "flori"
}


FILE ops/rebuild-2026-09/evidence/phase-07/ui-acceptance.json
{
  "artifact_id": "phase07-brand-ui",
  "round": 3,
  "verdict": "pass",
  "files_and_images_match": true,
  "review_input_and_output_hashes_match": true,
  "producer_input_output_hashes_match": true,
  "coverage_checked": [
    "Brand naming and typography: Benchmark Heaven branding applied across layouts, nav, footer, metadata, and manifests; Georgia serif display headings paired with system sans data tables and controls",
    "Brand visual assets and variants: Observatory concept selection and rationale documented in docs/brand.md; variants explored in public/brand/variants.svg; production assets public/brand/mark.svg, public/brand/wordmark.svg, app/icon.svg, components/BrandMark.tsx, and app/apple-icon.png",
    "Social card generation and validation: public/brand/og-image.svg and 1200x630 public/brand/og-image.png reviewed against layout metadata and visual evidence",
    "Color system and theming: dark/light theme CSS custom properties in app/globals.css validated with contrast checks and rendered overview-light/overview-dark screenshots",
    "Responsiveness and accessibility: layout hierarchy, skip links, 44px touch targets, mobile layouts (320px/390px), and keyboard navigation verified via accessibility trees and checks.json",
    "Preservation of URLs and data integrity: dataset counts (835 models, 650 families, 89 providers, 2786 offers), scraping methodology, scoring mechanics, and API routes preserved without regression",
    "Visual evidence inspection: all 8 rendered screenshots (variants.png, overview-light.png, overview-dark.png, overview-mobile.png, radar-mobile-dark.png, footer-light.png, assets.png, og-image.png) inspected for clipping, alignment, and legibility"
  ],
  "critic": "google/gemini-3.7-flash",
  "earlier_rounds": "r1 uppercase verdict and r2 fenced JSON were reporting failures; neither identified a product defect. r3 is clean.",
  "limitations": [
    "System font letterforms vary by operating system.",
    "Automated axe scans plus limited manual visual/keyboard coverage do not prove complete WCAG conformance.",
    "No real data or Composite inputs were changed."
  ]
}


FILE ops/rebuild-2026-09/evidence/phase-07/docs-acceptance.json
{
  "artifact_id": "phase07-consumer-docs-ops",
  "round": 2,
  "verdict": "pass",
  "files_match": true,
  "input_and_output_hashes_match": true,
  "coverage_checked": [
    "README.md",
    "API.md",
    "CHANGELOG.md",
    "DEPLOYMENT.md",
    "PRD.md",
    "MSG-SPINOFF-STARTER-PROMPT.md",
    "MSG-UPSTREAM-SYNC-PROMPT.md",
    "ops/daily/run.sh",
    "ops/daily/prompt.md",
    "ops/daily-refresh-prompt.md",
    "ops/rebuild-2026-09/daily-refresh-prompt.md",
    "scripts/fetch-live.mjs",
    "scripts/fetch-aa-efficiency.mjs",
    "scripts/fetch-aa-coding-agents.mjs",
    "components/SettingsContext.tsx",
    "middleware.ts",
    "Installed runner & prompt equality against receipts",
    "Telegram quiet-policy and notification branding",
    "User-Agent-only script changes",
    "Per-origin preference isolation docs",
    "Compatibility URL retention and schema immutability"
  ],
  "critic": "google/gemini-3.7-flash",
  "uncertainties": [
    "Live public TLS certificate issuance for benchmarkheaven.com is subject to separate out-of-band release verification following the upstream CA incident resolution and is explicitly out of scope for doc semantics QA."
  ],
  "prior_round": "No content defects; omitted artifact metadata and was not accepted."
}


FILE ops/rebuild-2026-09/evidence/phase-07/dataset-continuity.json
{
  "sameExceptGeneratedAt": true,
  "counts": {
    "models": 835,
    "families": 650,
    "providers": 89,
    "offers": 2786
  },
  "observations": 13908
}


FILE ops/rebuild-2026-09/evidence/phase-07/worker-costs.json
{
  "completed_calls": [
    {
      "receipt": "ops/rebuild-2026-09/evidence/phase-07/ui-r1-review.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.033413985
    },
    {
      "receipt": "ops/rebuild-2026-09/evidence/phase-07/docs-r2-review.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.033544665
    },
    {
      "receipt": "ops/rebuild-2026-09/evidence/phase-07/variants-draft.svg.meta.json",
      "model": "z-ai/glm-5.3-flash",
      "cost": 0.005849811
    },
    {
      "receipt": "ops/rebuild-2026-09/evidence/phase-07/docs-r1-review.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0291453525
    },
    {
      "receipt": "ops/rebuild-2026-09/evidence/phase-07/ui-r3-review.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0340384275
    },
    {
      "receipt": "ops/rebuild-2026-09/evidence/phase-07/ui-r2-review.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.033803055
    }
  ],
  "total_returned_cost_usd": 0.169795296,
  "excludes": "Incomplete/failed-call charges and owner subscription usage."
}


FILE ops/rebuild-2026-09/evidence/phase-07/tls-check.py
import socket,ssl,urllib.request,json,hashlib,datetime,subprocess,sys
from pathlib import Path
mode=sys.argv[1] if len(sys.argv)>1 else 'pre-release';rows=[]
for host in ['benchmarkheaven.com','www.benchmarkheaven.com','model-market-comparison.app.mintapis.com']:
 row={'host':host,'public_dns':{},'tls':{}}
 for ns in ['1.1.1.1','8.8.8.8']:
  ans=subprocess.check_output(['dig','+short',host,'A','@'+ns],text=True).strip();assert ans=='65.109.49.103',ans;row['public_dns'][ns]=ans
 # Inspect the certificate on the publicly resolved server. Explicit address keeps a
 # local stale resolver entry from masking the CA result; SNI/name/chain all verified.
 with socket.create_connection(('65.109.49.103',443),timeout=15) as sock:
  with ssl.create_default_context().wrap_socket(sock,server_hostname=host) as t:
   c=t.getpeercert();row['tls']={'subject':c['subject'],'subjectAltName':c.get('subjectAltName'),'issuer':c['issuer'],'notBefore':c['notBefore'],'notAfter':c['notAfter'],'sha256':hashlib.sha256(t.getpeercert(True)).hexdigest(),'version':t.version(),'chain_and_hostname_verified':True,'connection_ip':'65.109.49.103'}
 row['requests']=[]
 for path in ['/api/health','/api/meta']:
  # Ordinary HTTPS client, no certificate or DNS overrides.
  with urllib.request.urlopen('https://'+host+path,timeout=20) as r:
   data=json.load(r);assert r.status==200;row['requests'].append({'path':path,'status':r.status,'final_url':r.url,'cors':r.headers.get('Access-Control-Allow-Origin'),'json':data})
 with urllib.request.urlopen('http://'+host+'/api/health?brandcheck=1',timeout=20) as r:
  assert r.url=='https://'+host+'/api/health?brandcheck=1';assert r.status==200;row['http_redirect_preserves_path_query']=True
 rows.append(row)
for row in rows[1:]:assert row['requests'][1]['json']==rows[0]['requests'][1]['json']
Path('ops/rebuild-2026-09/evidence/phase-07/tls-'+mode+'.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':mode,'hosts':rows,'same_api_metadata_all_hosts':True},indent=2)+'\n')
print('Public DNS, trusted certificates, ordinary HTTPS and API equality pass on all 3 hosts')


FILE ops/rebuild-2026-09/evidence/phase-07/api-check.mjs
import fs from 'node:fs';import assert from 'node:assert/strict';
const base=process.argv[2],out=process.argv[3];const snapshot=JSON.parse(fs.readFileSync('data/dataset.json'));const results=[];
for(const path of ['/','/compare','/benchmarks','/radar','/about','/models/gpt-5.6-sol%3A%3Ahigh']){const r=await fetch(base+path);const t=await r.text();assert.equal(r.status,200,path);assert.ok(t.includes('Benchmark Heaven'),path);assert.ok(!t.includes('Model Market Comparison'),path);results.push({path,status:r.status,brand:true});}
for(const path of ['/api/dataset','/api/meta','/api/health','/api/benchmarks','/api/benchmark-scores?limit=1','/api/models?score=composite','/api/providers','/api/models/gpt-5.6-sol%3A%3Ahigh']){const r=await fetch(base+path);const body=await r.json();assert.equal(r.status,200,path);assert.equal(r.headers.get('access-control-allow-origin'),'*');const receipt={path,status:r.status,cors:'*'};if(path==='/api/dataset'){delete body._source;delete snapshot._source;assert.deepEqual(body,snapshot);receipt.fullDatasetEquality=true;receipt.generated_at=body.generated_at;}if(path==='/api/health')assert.equal(body.ok,true);results.push(receipt);}
const cors=await fetch(base+'/api/dataset',{method:'OPTIONS',headers:{Origin:'https://consumer.example'}});assert.equal(cors.status,204);assert.equal(cors.headers.get('access-control-allow-origin'),'*');results.push({path:'/api/dataset',method:'OPTIONS',status:204,cors:'*'});
fs.writeFileSync(out,JSON.stringify({at:new Date().toISOString(),base,results},null,2)+'\n');console.log('15 page/API/consumer checks passed:',base);


FILE ops/rebuild-2026-09/evidence/phase-07/live/browser-check.mjs
import fs from 'node:fs';import assert from 'node:assert/strict';import{createRequire}from'node:module';const require=createRequire(import.meta.url),{chromium}=require('/opt/tao-head-family-video-render-v1/node_modules/playwright');
const base='https://benchmarkheaven.com',out='ops/rebuild-2026-09/evidence/phase-07/live';fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox']});const ctx=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'reduce'});await ctx.addInitScript(()=>localStorage.setItem('bh-theme','light'));const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(base);await page.waitForLoadState('networkidle');assert.match(await page.title(),/Benchmark Heaven/);assert.equal(await page.getByRole('link',{name:'Benchmark Heaven',exact:true}).count(),1);await page.screenshot({path:out+'/overview.png'});
await page.goto(base+'/compare');await page.waitForLoadState('networkidle');await page.getByRole('combobox',{name:'Model C',exact:true}).selectOption('gpt-5.6-terra::high');await page.waitForFunction(()=>document.querySelector('[aria-label="Chart legend"]')?.children.length===3);await page.screenshot({path:out+'/compare.png'});
await page.setViewportSize({width:390,height:844});await page.goto(base);await page.waitForLoadState('networkidle');assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth-innerWidth),0);await page.screenshot({path:out+'/mobile-before-toggle.png'});console.log('mobile url/title',page.url(),await page.title(),'toggle',await page.getByRole('button',{name:'Toggle color theme'}).count());fs.writeFileSync(out+'/mobile-tree.txt',await page.locator('body').ariaSnapshot());await page.getByRole('button',{name:'Toggle color theme'}).click();assert.equal(await page.evaluate(()=>document.documentElement.dataset.theme),'dark');await page.screenshot({path:out+'/mobile-dark.png'});assert.equal(errors.length,0);
const img=await fetch(base+'/brand/og-image.png');assert.equal(img.status,200);assert.deepEqual(Buffer.from(await img.arrayBuffer()),fs.readFileSync('public/brand/og-image.png'));
fs.writeFileSync(out+'/browser.json',JSON.stringify({at:new Date().toISOString(),base,brand:true,threeModelComparison:true,mobileNoOverflow:true,themeToggle:true,publishedSocialPngMatches:true,errors},null,2)+'\n');await browser.close();console.log('Live brand, 3-model comparison, mobile theme and social asset passed');

PUBLISHED CONSUMER NOTICE API.md
# Benchmark Heaven public API

> **2026-09-11 — New domain:** Benchmark Heaven at benchmarkheaven.com
>
> The product is now **Benchmark Heaven** (formerly Model Market Comparison). Its
> **new primary base URL is `https://benchmarkheaven.com`**.
> The previous base URL **`https://model-market-comparison.app.mintapis.com` remains
> valid as a compatibility URL and serves the same endpoints and dataset** — existing
> consumers do NOT have to migrate.
> **Nothing else moved**: API routes, JSON shapes, schema, model/offer/benchmark IDs,
> units, the Composite definition, settings keys, the GitHub repo and file paths
> are all unchanged.
> Browser preferences are stored per origin; the old hostname’s saved filters/theme
> do not automatically transfer to the new hostname.

All endpoints are **read-only**, return JSON, and are **CORS-enabled** (`Access-Control-Allow-Origin: *`), so they can be called from any site or tool — including directly from a browser.

Base URL (primary): `https://benchmarkheaven.com`
Base URL (compatibility, unchanged, same endpoints): `https://model-market-comparison.app.mintapis.com`

The data is served from Postgres when `DATABASE_URL` is configured, otherwise from the committed `data/dataset.json` snapshot — the API shape is identical either way.

## Endpoints

### `GET /api/benchmarks`

All exact versioned registry entries, source/metric definitions, collection status and
per-benchmark coverage. No family-only version aliases are accepted.

### `GET /api/benchmark-scores`

Filters: `benchmark_id`, `model_id`, `basis` (`measured`, `self_reported`, `derived`),
`offset` (default 0), `limit` (default 100, maximum 500). Returns observations, total,
stored divergences, coverage and collection status. Both identity filters also return
the sparse cell status. Unknown exact versions/models return 404; bad parameters 400.
PUBLISHED CONSUMER NOTICE CHANGELOG.md
# Changelog

For downstream consumers (forks, apps syncing data from this repo or the live API):
the **data locations have not moved**. What changed recently is the hosting URL and
some app internals — details per release below.

## 2026-09-11 — New domain: Benchmark Heaven at benchmarkheaven.com

- **The product is renamed Benchmark Heaven** (formerly Model Market Comparison).
- **New primary base URL: `https://benchmarkheaven.com`.**
- **The previous base URL `https://model-market-comparison.app.mintapis.com` remains
  valid as a compatibility URL and serves the same endpoints and dataset.** No consumer
  migration is required; both hosts stay attached.
- **Nothing else moved:** the GitHub repo, repo file paths, JSON schema, model/offer/
  benchmark IDs, units, the Composite definition and settings storage keys are unchanged. Browser preferences are per origin, so
  saved filters/theme on the old hostname are not transferred to the new hostname.
- The fetch scripts' HTTP User-Agent now identifies the collector as Benchmark Heaven;
  the contacted GitHub project URL inside it is unchanged.
- New Observatory mark, favicon, touch icon, light/dark identity, serif display typography,
  social card, metadata, README header, and branded fork-sync/Telegram templates.
- Older entries below keep the previously correct hostnames as their historical record.

## 2026-09-10 — Phase 04: benchmark discovery

- Added a versioned benchmark registry with verified publication routes, scoring semantics,
  provenance and an exclusion ledger, including public and independent writing/RP boards.
- Retained AA's previously discarded benchmark fields as raw observations with a fail-closed
  extractor. Coding Agent Index v1.4 and v1.5 remain separate; the legacy date is unchanged.
- Dataset builds validate registry evidence. Public API scores and Composite inputs are unchanged.

## 2026-09-10 — Phase 03: effective task costs

- Comparisons default to modeled USD/task, combining exact-variant task tokens, usage I/O and exact-endpoint cache statistics, with every fallback explained.
- Raw list prices and six fixed I/O scenarios remain selectable; settings move to `mmc.settings.v6`.
- The explorer starts at cheapest adjusted cost and measured task-token data; minimum benchmark scores make the cost/capability question directly filterable.
PUBLISHED CONSUMER NOTICE README.md
![Benchmark Heaven](public/brand/wordmark.svg)

Benchmarks in perspective. Costs in context.

> Benchmark Heaven (formerly Model Market Comparison) has its primary base URL at
> **[benchmarkheaven.com](https://benchmarkheaven.com)** (2026-09-11). The previous host
> **[model-market-comparison.app.mintapis.com](https://model-market-comparison.app.mintapis.com)
> remains valid** and serves the same app and API endpoints. The GitHub repo, file paths,
> data schema, IDs, units, Composite and settings keys did not move. Browser preferences are stored per hostname
> and are not automatically transferred to the new domain.

Compare **open-source and frontier LLMs** by capability and price in one place.
Capability comes from [ArtificialAnalysis](https://artificialanalysis.ai) (Coding,
Coding Agent & Intelligence indices) and [Intelligence.ai / DesignArena](https://intelligence.ai)
(Agentic Web Dev Frontend & Full-Stack Elo). Prices are aggregated across **OpenRouter**
inference providers, **AWS Bedrock**, **Azure AI Foundry**, **Google Vertex AI**,
**Nebius**, **Inceptron**, **TensorX**, **Scaleway**, **IONOS**, **Mistral**, **Chutes**,
**OVHcloud**, **STACKIT**, **T-Systems LLM Hub**,
**GitHub Copilot**, and the **Anthropic / Claude Code** list price — normalized to
USD per 1M tokens.

> 📋 Product spec: [PRD.md](PRD.md) · 🗂️ Data schema: [data/SCHEMA.md](data/SCHEMA.md) ·
> 🔄 Data collection & refresh: [data/SCRAPING.md](data/SCRAPING.md) ·
> 🔌 Public API: [API.md](API.md) · 🚀 Deploy / migrate / env vars: [DEPLOYMENT.md](DEPLOYMENT.md) · 📜 Data/URL changes for consumers: [CHANGELOG.md](CHANGELOG.md)


## Benchmark exploration

Explore [benchmark rankings](https://benchmarkheaven.com/benchmarks), compare up to four exact model configurations on [Compare](https://benchmarkheaven.com/compare), or use the standalone [Radar](https://benchmarkheaven.com/radar). Model pages include complete benchmark sheets, source links and dates, missing coverage, and explainable profile signals. Every comparison keeps benchmark versions separate. [Methodology and limitations](docs/benchmark-explorer.md).


## Features

- **Price & provider filters** (apply to price comparisons and model offers; benchmark exploration uses its own filters, persisted): selectable **score**,
  min-score, **One variant for Reasoning models** (collapse GPT/Claude/GLM/Kimi to one),
INDEPENDENT REVIEW ui-r3-review.json
{
  "artifact_id": "phase07-brand-ui",
  "artifact_sha256": "decfb3e25f0a99b90f81f8160752cce867322ad1c8e435a516b7b61bf1036ff3",
  "round": 3,
  "verdict": "pass",
  "coverage_checked": [
    "Brand naming and typography: Benchmark Heaven branding applied across layouts, nav, footer, metadata, and manifests; Georgia serif display headings paired with system sans data tables and controls",
    "Brand visual assets and variants: Observatory concept selection and rationale documented in docs/brand.md; variants explored in public/brand/variants.svg; production assets public/brand/mark.svg, public/brand/wordmark.svg, app/icon.svg, components/BrandMark.tsx, and app/apple-icon.png",
    "Social card generation and validation: public/brand/og-image.svg and 1200x630 public/brand/og-image.png reviewed against layout metadata and visual evidence",
    "Color system and theming: dark/light theme CSS custom properties in app/globals.css validated with contrast checks and rendered overview-light/overview-dark screenshots",
    "Responsiveness and accessibility: layout hierarchy, skip links, 44px touch targets, mobile layouts (320px/390px), and keyboard navigation verified via accessibility trees and checks.json",
    "Preservation of URLs and data integrity: dataset counts (835 models, 650 families, 89 providers, 2786 offers), scraping methodology, scoring mechanics, and API routes preserved without regression",
    "Visual evidence inspection: all 8 rendered screenshots (variants.png, overview-light.png, overview-dark.png, overview-mobile.png, radar-mobile-dark.png, footer-light.png, assets.png, og-image.png) inspected for clipping, alignment, and legibility"
  ],
  "errors_found": 0,
  "findings": [],
  "fixed": [],
  "uncertainties": [],
  "missing_evidence": []
}

INDEPENDENT REVIEW docs-r2-review.json
{"artifact_id": "phase07-consumer-docs-ops", "artifact_sha256": "ad1a5d45da3f31f029bf553093fd1ca65ad222c57e1bfe2fd83756a34618cff7", "round": 2, "verdict": "pass", "coverage_checked": ["README.md", "API.md", "CHANGELOG.md", "DEPLOYMENT.md", "PRD.md", "MSG-SPINOFF-STARTER-PROMPT.md", "MSG-UPSTREAM-SYNC-PROMPT.md", "ops/daily/run.sh", "ops/daily/prompt.md", "ops/daily-refresh-prompt.md", "ops/rebuild-2026-09/daily-refresh-prompt.md", "scripts/fetch-live.mjs", "scripts/fetch-aa-efficiency.mjs", "scripts/fetch-aa-coding-agents.mjs", "components/SettingsContext.tsx", "middleware.ts", "Installed runner & prompt equality against receipts", "Telegram quiet-policy and notification branding", "User-Agent-only script changes", "Per-origin preference isolation docs", "Compatibility URL retention and schema immutability"], "errors_found": 0, "findings": [], "fixed": [], "uncertainties": ["Live public TLS certificate issuance for benchmarkheaven.com is subject to separate out-of-band release verification following the upstream CA incident resolution and is explicitly out of scope for doc semantics QA."], "missing_evidence": []}

FINAL EXECUTION OUTPUTS: dataset build, test, build, typecheck, prerender

dataset-final.log
Registry: 73 versioned entries, 25 AA field mappings, 55 verified evidence files
✓ dataset.json { models: 835, families: 650, providers: 89, offers: 2786 }

tests-final.log
rve exact free SKU identity and source last-activity date (1.828945ms)
✔ Pareto frontier keeps cost/capability tradeoffs and removes dominated interiors (2.012472ms)
✔ Pareto frontier handles cost, score, and exact ties correctly (15.92148ms)
✔ Pareto frontier is deterministic, order independent, and supports empty/singleton filters (0.296935ms)
✔ Pareto helper agrees with the strict minimize-cost/maximize-score definition (2.134739ms)
✔ public source parsers preserve zero, reject malformed values and isolate protocols (157.291974ms)
✔ collapse picks the strongest measured GPT effort for the selected score (1.289496ms)
✔ collapse keeps DeepSeek Coding-Agent evidence instead of an unmeasured max row (0.136768ms)
✔ collapse prefers an explicit GLM max result over a generic default alias (0.132397ms)
✔ neutral Composite fallback cannot replace a measured family representative (0.247205ms)
✔ collapsed representative fallback is deterministic and prefers a measured Claude effort (0.169467ms)
✔ hide-deprecated hides whole families, not individual variants (2.064431ms)
✔ a fully deprecated family has no selectable model while hiding is active (0.178566ms)
✔ vision critic sends actual local pixels with hashed receipts, without weakening model or payload gates (20.15002ms)
✔ AA fallback requires exact version and matching organization (2.199029ms)
✔ explicit maximum-effort mapping cannot hide a weak or missing sibling (1.58918ms)
✔ missing or malformed prices never become free eligibility (0.417632ms)
✔ unscored transport smoke has a price ceiling and cannot select automatically (0.372453ms)
✔ critic excludes every producer family including aliases and explicit model pins (14.077774ms)
✔ worker CLI preserves output on provider failures and accepts a large embedded packet (3265.792234ms)
✔ transport smoke cannot accept arbitrary data work or a reference file (129.076816ms)
ℹ tests 146
ℹ suites 0
ℹ pass 146
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 7924.495469

typecheck-final.log

build-final.log.gz
JS
┌ ○ /                                    6.75 kB         121 kB
├ ○ /_not-found                             1 kB         103 kB
├ ○ /about                                 153 B         103 kB
├ ƒ /api/benchmark-scores                  153 B         103 kB
├ ƒ /api/benchmark-view                    153 B         103 kB
├ ƒ /api/benchmarks                        153 B         103 kB
├ ƒ /api/dataset                           153 B         103 kB
├ ƒ /api/health                            153 B         103 kB
├ ƒ /api/meta                              153 B         103 kB
├ ƒ /api/models                            153 B         103 kB
├ ƒ /api/models/[id]                       153 B         103 kB
├ ƒ /api/price-comparison                  153 B         103 kB
├ ƒ /api/providers                         153 B         103 kB
├ ○ /apple-icon.png                          0 B            0 B
├ ○ /benchmarks                          3.16 kB         112 kB
├ ○ /charts                              5.47 kB         218 kB
├ ○ /compare                             1.83 kB         116 kB
├ ○ /eu                                  1.62 kB         116 kB
├ ○ /gateways                            1.61 kB         104 kB
├ ○ /icon.svg                                0 B            0 B
├ ○ /manifest.webmanifest                  153 B         103 kB
├ ƒ /models/[id]                            4 kB         115 kB
├ ○ /provider-explorer                   4.13 kB         115 kB
├ ○ /providers                           6.54 kB         117 kB
├ ○ /radar                                 179 B         115 kB
└ ○ /scatter                             9.73 kB         225 kB
+ First Load JS shared by all             102 kB
  ├ chunks/255-9e5c9994c6807ca2.js       46.1 kB
  ├ chunks/4bd1b696-409494caf8c83275.js  54.2 kB
  └ other shared chunks (total)           2.1 kB


ƒ Middleware                             34.2 kB

○  (Static)   prerendered as static content
ƒ  (Dynamic)  server-rendered on demand


prerender-final.log
✔ bundled catalog / is rendered once at build time (3.450735ms)
✔ bundled catalog /about is rendered once at build time (0.260175ms)
✔ bundled catalog /charts is rendered once at build time (0.121418ms)
✔ bundled catalog /compare is rendered once at build time (0.126588ms)
✔ bundled catalog /eu is rendered once at build time (0.333274ms)
✔ bundled catalog /gateways is rendered once at build time (0.113098ms)
✔ bundled catalog /provider-explorer is rendered once at build time (0.113847ms)
✔ bundled catalog /providers is rendered once at build time (0.112558ms)
✔ bundled catalog /scatter is rendered once at build time (0.439392ms)
✔ bundled catalog /benchmarks is rendered once at build time (0.248306ms)
✔ bundled catalog /radar is rendered once at build time (0.234596ms)
ℹ tests 11
ℹ suites 0
ℹ pass 11
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 91.000963
