PRIMARY REQUIREMENTS (user Phase 7): Develop Benchmark Heaven branding: name usage, logo/mark, favicon, colour system, typography, tone, og-image, README header. It must look designed, not renamed. Show variants, pick one and justify the pick. Apply metadata/nav/footer. Keep old URLs, schema and data working. No invented numbers.

SCOPE: brand visual assets, shared layout and page heading changes, metadata, manifest and package identity. README, API, consumer docs and DNS/TLS are reviewed separately. Existing score/data behavior is unchanged. Concept board is exploration; the chosen production mark intentionally drops the tiny star. Judge the actual geometry/readability in assets.png. System fonts can vary by OS; no remote fonts.

{
  "artifact_id": "phase07-brand-ui",
  "round": 2,
  "files": {
    "app/layout.tsx": "b710ede830a37c7d6de2c0f16bf39fb7e4b2189e58e2ab38ea676fe22231c26c",
    "app/globals.css": "2b623c71afce02b3050a0179ea08e240f2c9d18138306c07f93f5516d55bdbce",
    "app/page.tsx": "88d61a37f595881745568f8abbead6ae2c674130feb73c0fbe9305fad0a331c3",
    "app/about/page.tsx": "f511992739fa29aeb40263ad7663ca416c20d35e83b2822e72cae6f6de38b6dd",
    "app/gateways/page.tsx": "55bbf80a3387794bb3e109181a998d7a149af45799c24aba0565e6175035d60d",
    "app/provider-explorer/page.tsx": "2e15cd6dc70e69aa55e23c6335e81a235a6ef801ef0535389b689d70abd9e898",
    "app/icon.svg": "063a50ca0517cc3a78b8450384290a0c290bc07096854bb59ce2cb145d1fc603",
    "app/apple-icon.png": "522ae21e9854fe40968d0973285089381e21179d75cc3bf0a10732560ed82ff3",
    "app/manifest.ts": "71b786fd0ccb1020a4def8367cdd64531eb1ef83f48457a028c70dd6e1094698",
    "components/Nav.tsx": "9dd767935964118cf9a8ee34cec6a2741a93ae929f5ac10cda7ee63892dd2fa9",
    "components/BrandMark.tsx": "16c53605a2b3832effee6fb44e953955350be89542fa1cc3fcf70e27a17e49b8",
    "docs/brand.md": "2369070c0984ed702a1850b234f48652b703c35e27e08ee2c8464ad816089633",
    "public/brand/mark.svg": "063a50ca0517cc3a78b8450384290a0c290bc07096854bb59ce2cb145d1fc603",
    "public/brand/wordmark.svg": "acb0caacf7d5af88682771b93481e517a288575efc21516f4cb7b077bda93649",
    "public/brand/variants.svg": "e52cd9964316e11c19c2b99d045cbd94f72cb345d55c4405dec4b5cd9094de83",
    "public/brand/og-image.svg": "d64b128b9c0ee91002306e78c94bfb8e2878f616407c038f40af9e8796cf0e13",
    "public/brand/og-image.png": "0e7f0ee3e0c58f29a315e8853099024b788d26754e366e9569f646f565600390",
    "package.json": "905599315b17daed2c14bacd5045e345686ab942fbfbeba3b71205bdaad54e97",
    "package-lock.json": "45f191fbbaa892f1e4683aae933edf8afda91f5f36feceb9592d9a9745de0d0f"
  },
  "images": {
    "ops/rebuild-2026-09/evidence/phase-07/rendered/variants.png": "1060559d03c028b842ddd759fb4c49cee7202df0a0fc915bb4b571d002aa7282",
    "ops/rebuild-2026-09/evidence/phase-07/rendered/overview-light.png": "fc58f6c850a077905606b18a4053456e2af88b16becc09cfaf3b3cec43ab7f7f",
    "ops/rebuild-2026-09/evidence/phase-07/rendered/overview-dark.png": "aafe82bca49cba9e0585c917e3eac1d79a66b268d1fc59dde06f72dfdd00a91a",
    "ops/rebuild-2026-09/evidence/phase-07/rendered/overview-mobile.png": "c1f5316fc6cfa754ce7eebcb54674f63601d99cac2e7d126ff76932b2a3260d6",
    "ops/rebuild-2026-09/evidence/phase-07/rendered/radar-mobile-dark.png": "da8dc568e0ddd94cfb116a744ec26dc14ac6e44cc31af9df80fc0b0369b9dfc5",
    "ops/rebuild-2026-09/evidence/phase-07/rendered/footer-light.png": "2a671664e623510985ea446164fe8c98e2d1d4ed3f012a4c9dd6af7e369fb169",
    "ops/rebuild-2026-09/evidence/phase-07/rendered/assets.png": "4c9437c03d6cad948ef2ae31af47f8307fc35a01cd51b017b7779c1e477f47bc",
    "public/brand/og-image.png": "0e7f0ee3e0c58f29a315e8853099024b788d26754e366e9569f646f565600390"
  },
  "build_id": "-tLF0ySJkiArQ-nNz5LvR",
  "artifact_sha256": "5aa249ecaad1afd804c6deb5cd0c2cd8ba913fc38cf56f688970154b78a70905"
}

FILE ops/rebuild-2026-09/evidence/phase-07/DESIGN-CHECKLIST.md
# Phase 07 visual acceptance

Reference: three brand concepts in public/brand/variants.svg, the chosen Observatory
production mark/wordmark, and docs/brand.md. Preserve phase06 functional controls.

- Product reads Benchmark Heaven in navigation, footer, metadata and documentation.
- Arch/bar mark is recognizable at 16/32px; production geometry consistently mirrors favicon and navigation.
- Editorial serif display and wordmark pair with legible system sans data, restrained sky/sea-glass palette in both themes.
- Logo, navigation, main content, footer and social card have deliberate hierarchy; no clipping or root overflow at 320/390/1440px.
- Brand colors do not replace benchmark provenance, assumptions or numeric labels.
- 44px controls, visible keyboard focus, working skip link and retained model-selection flow.
- Social image is 1200x630 with legible name, message and domain; no invented scores or trust claims.
- Show three variants and record selection/rationale. Automated axe is supplementary, not a complete conformance claim.


FILE app/layout.tsx
import type { Metadata } from "next";
import "./globals.css";
import { Nav } from "../components/Nav";
import { SettingsProvider } from "../components/SettingsContext";
import { GlobalFilters } from "../components/GlobalFilters";
import { getDataset } from "../lib/data";
import type { ProviderInfo, FamilyOption } from "../lib/client-model";

export const metadata: Metadata = {
  metadataBase: new URL("https://benchmarkheaven.com"),
  applicationName: "Benchmark Heaven",
  title: { default: "Benchmark Heaven — Model benchmarks & costs", template: "%s | Benchmark Heaven" },
  description: "Explore model benchmarks, compare provider prices, and see the assumptions behind adjusted task costs. Versioned results with sources and dates.",
  openGraph: {
    type: "website", siteName: "Benchmark Heaven",
    title: "Benchmark Heaven", description: "Benchmarks in perspective. Costs in context.",
    images: [{ url: "/brand/og-image.png", width: 1200, height: 630, alt: "Benchmark Heaven — Benchmarks in perspective. Costs in context." }],
  },
  twitter: { card: "summary_large_image", title: "Benchmark Heaven", description: "Benchmarks in perspective. Costs in context.", images: ["/brand/og-image.png"] },
  icons: { icon: "/icon.svg", apple: "/apple-icon.png" },
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const ds = await getDataset();
  const providers: ProviderInfo[] = ds.providers.map((p) => ({
    key: `${p.platform}::${p.provider}`, platform: p.platform, provider: p.provider, model_count: p.model_count,
    eu_hosted: p.eu_hosted, eu_dedicated: p.eu_dedicated, non_us: p.non_us,
    hyperscaler: p.hyperscaler, country: p.country, note: p.note, coming_soon: p.coming_soon,
  }));
  const famMap = new Map<string, FamilyOption>();
  for (const m of ds.models) if (!famMap.has(m.family_key)) famMap.set(m.family_key, { key: m.family_key, name: m.family_name, org: m.org });
  const families = [...famMap.values()].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: `(function(){try{var t=localStorage.getItem('bh-theme');document.documentElement.dataset.theme=t==='light'||t==='dark'?t:window.matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'}catch(e){document.documentElement.dataset.theme='dark'}})()` }} /></head>
      <body>
        <a href="#main-content" className="skip-link">Skip to main content</a>
        <SettingsProvider>
          <Nav />
          <GlobalFilters providers={providers} families={families} />
          <main id="main-content" tabIndex={-1} className="mx-auto max-w-[1400px] px-4 py-6">{children}</main>
          <footer className="bh-footer mx-auto max-w-[1400px] px-4 py-10 text-xs text-gray-500">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-4">
              <span className="bh-wordmark text-lg">Benchmark Heaven</span>
              <div className="flex flex-wrap gap-5"><a href="/about">Sources &amp; methodology</a><a href="https://github.com/fstandhartinger/model-market-comparison/blob/main/API.md">Public API</a><a href="https://github.com/fstandhartinger/model-market-comparison">GitHub</a></div>
            </div>
            <p>Benchmarks in perspective. Costs in context. Every result has a source; every estimate has assumptions.</p>
            <p className="mt-2">Data from OpenRouter, Artificial Analysis, Intelligence.ai / DesignArena, benchmark maintainers and provider catalogs.
              Raw token prices are USD per 1M tokens; adjusted task costs are estimates with visible inputs.
              Source dates vary. Check the linked source before choosing a provider.</p>
            <p className="mt-2">Independent project. Not affiliated with model or inference providers.</p>
          </footer>
        </SettingsProvider>
      </body>
    </html>
  );
}


FILE app/globals.css
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  color-scheme: dark;
  --ink: 14 19 27; --panel: 23 30 41; --line: 57 70 87;
  --accent: 108 174 255; --accent2: 103 224 193; --warn: 255 197 111;
  --surface: #171e29; --text: #edf2f8; --muted: #adb9ca; --control-border: #74869e;
  --negative: #ffafbc; --radar-1: #6caeff; --radar-2: #67e0c1;
  --radar-3: #ffc56f; --radar-4: #d0acff; --radar-grid: #8c9ab0;
}
[data-theme="light"] {
  color-scheme: light;
  --ink: 245 248 252; --panel: 255 255 255; --line: 199 210 225;
  --accent: 29 78 185; --accent2: 4 109 91; --warn: 145 69 9;
  --surface: #fff; --text: #182639; --muted: #4c5e75; --control-border: #718198;
  --negative: #b91c3a; --radar-1: #1d4eb9; --radar-2: #046d5b;
  --radar-3: #914509; --radar-4: #7433b7; --radar-grid: #61758f;
}
html, body { background: rgb(var(--ink)); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.5; }
html { -webkit-text-size-adjust: 100%; }
body { margin: 0; }
main :is(p, li) a { text-decoration: underline; }
a { color: inherit; text-underline-offset: 3px; }
button, input, select, textarea { max-width: 100%; font: inherit; }
button, select, input:not([type="checkbox"]):not([type="radio"]), summary { min-height: 44px; }
input, select, textarea { color: var(--text); accent-color: rgb(var(--accent)); }
input[type="checkbox"], input[type="radio"] { width: 16px; height: 16px; flex-shrink: 0; }
input::placeholder { color: var(--muted); opacity: 1; }
button:disabled, select:disabled { cursor: not-allowed; opacity: .55; }
:focus-visible { outline: 3px solid rgb(var(--accent)); outline-offset: 3px; border-radius: 3px; }
::selection { background: rgb(var(--accent) / .25); }
::-webkit-scrollbar { height: 10px; width: 10px; }
::-webkit-scrollbar-thumb { background: var(--control-border); border-radius: 6px; }
::-webkit-scrollbar-track { background: transparent; }
.card, .bh-panel { background: var(--surface); border: 1px solid rgb(var(--line)); border-radius: 14px; }
.tabular { font-variant-numeric: tabular-nums; }
.bh-muted, .text-gray-400, .text-gray-500, .text-gray-600 { color: var(--muted); }
.text-gray-100, .text-gray-200, .text-gray-300 { color: var(--text); }
.bh-eyebrow { color: rgb(var(--accent2)); font-size: 11px; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; }
.bh-eyebrow + h1, .bh-eyebrow + h2 { margin-top: 6px; }
.bh-page-head { padding: 12px 0 8px; margin-bottom: 24px; }
.bh-button { display: inline-flex; min-height: 44px; align-items: center; justify-content: center; gap: 6px; border: 1px solid var(--control-border); border-radius: 8px; padding: 8px 12px; background: var(--surface); color: var(--text); text-decoration: none; font-weight: 500; cursor: pointer; }
.bh-button:hover { background: rgb(var(--accent) / .1); }
.bh-input { min-width: 0; border: 1px solid var(--control-border); border-radius: 8px; padding: 9px 12px; background: rgb(var(--ink)); color: var(--text); }
.bh-badge { display: inline-block; border: 1px solid rgb(var(--line)); border-radius: 6px; padding: 3px 7px; font-size: 11px; line-height: 1.4; font-weight: 500; background: rgb(var(--accent) / .07); color: var(--text); }
.bh-positive { color: rgb(var(--accent2)); background: rgb(var(--accent2) / .08); }
.bh-negative { color: var(--negative); background: color-mix(in srgb, var(--negative) 8%, transparent); }
.bh-alert { color: rgb(var(--warn)); background: rgb(var(--warn) / .08); }
.bh-table-wrap { max-width: 100%; overflow-x: auto; border: 1px solid rgb(var(--line)); border-radius: 10px; }
.bh-table { width: 100%; border-collapse: collapse; font-size: 14px; }
.bh-table th, .bh-table td { padding: 14px 16px; border-bottom: 1px solid rgb(var(--line)); }
.bh-table thead th { font-size: 12px; color: var(--muted); text-align: left; background: rgb(var(--ink)); }
.bh-table tbody tr:last-child > * { border-bottom: none; }
.bh-table tbody tr:hover { background: rgb(var(--accent) / .025); }
table.dtable th, table.dtable td { border-bottom: 1px solid rgb(var(--line)); }
table.dtable thead th { position: sticky; top: 0; background: var(--surface); z-index: 1; user-select: none; }
table.dtable tbody tr:hover { background: rgb(var(--accent) / .04); }
.bh-empty { display: grid; align-content: center; padding: 32px; text-align: center; color: var(--muted); }
.bh-grid { display: grid; gap: 24px; grid-template-columns: repeat(auto-fit, minmax(min(100%, 240px), 1fr)); }
.bh-stat { border: 1px solid rgb(var(--line)); border-radius: 10px; padding: 16px; }
summary { cursor: pointer; padding-top: 10px; padding-bottom: 10px; }
summary::marker { color: rgb(var(--accent)); }
details[open] > summary { margin-bottom: 8px; }
.bh-table details { max-width: 380px; }
.bh-table code { overflow-wrap: anywhere; }
.skip-link { position: fixed; top: 8px; left: 8px; z-index: 100; transform: translateY(-180%); border-radius: 6px; padding: 12px; background: var(--surface); color: var(--text); border: 2px solid rgb(var(--accent)); }
.skip-link:focus { transform: translateY(0); }
[data-theme="light"] [class*="bg-[#"] { background-color: var(--surface); }
[data-theme="light"] .text-white { color: var(--text); }
[data-theme="light"] :is(.text-amber-200,.text-amber-300,.text-yellow-300,.text-orange-300) { color: #85420a; }
[data-theme="light"] :is(.text-red-300,.text-red-400,.text-pink-300) { color: #a51b35; }
[data-theme="light"] :is(.text-emerald-300,.text-green-300,.text-teal-300) { color: #035448; }
[data-theme="light"] :is(.text-sky-300,.text-blue-300) { color: #1d4eb9; }
[data-theme="light"] .bg-gray-600\/30 { background-color: #e5eaf1; }
[data-theme="light"] .text-purple-300 { color: #652893; }
[data-theme="light"] .recharts-text { fill: var(--muted); }
[data-theme="light"] .recharts-cartesian-grid line { stroke: rgb(var(--line)); }
@media (max-width: 639px) { .bh-page-head h1 { font-size: 28px; } .bh-panel { border-radius: 10px; } .bh-table th, .bh-table td { padding: 12px; } }
@media (prefers-reduced-motion: reduce) { *, ::before, ::after { animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; scroll-behavior: auto !important; } }

/* Benchmark Heaven — Observatory identity. UI/data keep the system sans. */
:root { --brand-serif: Georgia, "Times New Roman", serif; }
.bh-wordmark { font-family: var(--brand-serif); font-size: 21px; font-weight: 700; letter-spacing: -.045em; color: var(--text); white-space: nowrap; }
.bh-brand-link { border-radius: 8px; }
.bh-brand-link:hover .bh-wordmark { color: rgb(var(--accent)); }
.bh-hero { position: relative; border-bottom: 1px solid rgb(var(--line)); padding: 12px 0 28px; }
.bh-hero::before { content: ""; position: absolute; inset: -24px -16px 0; background: radial-gradient(ellipse at 90% 0, rgb(var(--accent) / .08), transparent 60%); pointer-events: none; }
.bh-hero > * { position: relative; }
.bh-display { font-family: var(--brand-serif); font-size: clamp(32px, 4vw, 52px); font-weight: 400; line-height: 1.06; letter-spacing: -.045em; }
.bh-display span { color: rgb(var(--accent2)); }
.bh-hero > p:not(.bh-eyebrow) { margin-top: 18px; max-width: 760px; line-height: 1.7; }
.bh-page-head > h1, main > div > h1 { font-family: var(--brand-serif); font-weight: 400; letter-spacing: -.035em; }
.bh-footer { border-top: 1px solid rgb(var(--line)); }
.bh-footer a { text-decoration: underline; }
@media (max-width: 639px) { .bh-wordmark { font-size: 20px; } .bh-hero { padding-top: 4px; } }


FILE app/page.tsx
import { getDataset } from "../lib/data";
import { clientData } from "../lib/client-model";
import { ModelExplorer } from "../components/ModelExplorer";


export default async function Home() {
  const ds = await getDataset();
  const data = clientData(ds);
  const featured = data.models.filter((r) => r.featured).length;

  return (
    <div>
      <section className="bh-hero mb-6">
        <p className="bh-eyebrow">Benchmark Heaven / Model intelligence</p>
        <h1 className="bh-display mt-3">Benchmarks in perspective.<br /><span>Costs in context.</span></h1>
        <p className="mt-1 max-w-3xl text-sm text-gray-400">
          Find the model that meets your benchmark threshold, then compare estimated task costs across providers.
          Adjusted prices are on by default. Explore versioned results, check their sources, and see where evidence is missing.
          Raw list prices and fixed input/output blends remain selectable.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Stat label="Models" value={ds.counts.models} />
          <Stat label="Featured" value={featured} />
          <Stat label="Model families" value={ds.counts.families} />
          <Stat label="Provider offers" value={ds.counts.offers} />
          <Stat label="Provider channels" value={ds.counts.providers} />
        </div>
      </section>

      <ModelExplorer data={data} />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="card px-4 py-2">
      <div className="text-lg font-semibold tabular">{value.toLocaleString()}</div>
      <div className="text-xs text-gray-500">{label}</div>
    </div>
  );
}


FILE app/about/page.tsx
import { getDataset } from "../../lib/data";


export default async function AboutPage() {
  const ds = await getDataset();
  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold">About &amp; data sources</h1>
      <p className="mt-2 text-sm text-gray-400">
        Benchmark Heaven brings together pricing and benchmark data for open-source and frontier LLMs into one
        comparable view. Prices are normalized to USD per 1M tokens (input and output) unless a
        platform prices differently (GitHub Copilot&apos;s current token/AI-Credit rates and legacy request billing are shown on a separate product axis).
      </p>

      <h2 className="mt-6 mb-2 font-semibold">Sources</h2>
      <ul className="space-y-2 text-sm text-gray-300">
        <li><b>OpenRouter</b> — model catalog and per-provider endpoint pricing (live API).</li>
        <li><b>ArtificialAnalysis</b> — Intelligence &amp; Coding indices plus sub-benchmarks (LiveCodeBench, SciCode, Terminal-Bench Hard, τ²-Bench, GPQA, MMLU-Pro) via the v2 API.</li>
        <li><b>AA Coding Agent Index</b> — Composite retains v1.4, last collected {ds.sources.aa_coding_agents}. AA now publishes v1.5 with different benchmark components. We collect it separately and do not mix the versions.</li>
        <li>Some AA licensing and model identifiers are retained from earlier source publications. Their original dates are recorded per field in the downloadable dataset.</li>
        <li><b>Intelligence.ai / DesignArena</b> — Agentic Web Dev Frontend &amp; Full-Stack Elo leaderboards.</li>
        <li><b>AWS Bedrock</b> — on-demand token pricing, European regions (eu-central-1 where available).</li>
        <li><b>Azure AI Foundry</b> — retail token meters plus model-card serving-region checks. A billing/resource region alone is not treated as proof that inference stays in the EU. By company policy, only Azure Direct Global DeepSeek V4 Pro and Kimi K2.7 Code are additionally eligible as EU-hosted equivalents; they remain marked Global because inference may occur outside the EU.</li>
        <li><b>Google Vertex AI</b> — pay-as-you-go token pricing for Gemini and Model Garden partner models (Claude, Llama, Mistral, DeepSeek, Qwen); offers are marked EU-hosted only where the model supports a documented European serving location.</li>
        <li><b>TensorX, Inceptron, Scaleway, IONOS, Mistral, Nebius, OVHcloud, STACKIT &amp; T-Systems</b> — direct European serverless/managed catalogs. TensorX is the broadest in-EU host for GLM/Kimi/DeepSeek/MiniMax; Inceptron serves GLM/Kimi/MiniMax from Finland; Scaleway and OVHcloud serve from France; STACKIT and T-Systems publish German/EU catalogs. Nebius is EU-capable but mixes EU, US and UK serving regions, so every model offer is checked separately. See the <a href="/eu" className="text-accent">EU &amp; Sovereign</a> tab.</li>
        <li><b>GitHub Copilot</b> — current 26-model AI-Credit/token-price catalog plus the 25-model legacy premium-request multiplier table. The UI&apos;s separate per-request field applies only to eligible legacy annual Pro/Pro+ plans.</li>
        <li><b>Anthropic / Claude Code</b> — all 11 currently callable first-party API models, their cache/batch/list prices, active promotions and Claude Code Enterprise terms.</li>
      </ul>

      <h2 className="mt-6 mb-2 font-semibold">What are &ldquo;Featured&rdquo; models?</h2>
      <p className="text-sm text-gray-400">
        <span className="text-warn">★ Featured</span> marks the specific models this tool was
        commissioned to track closely — the current frontier and leading open-weight families that
        matter most for the price/capability comparison. Filtering to &ldquo;Featured&rdquo; (the
        default on most pages) hides the long tail of older or niche models so the charts and tables
        stay focused. The featured set is:
      </p>
      <ul className="mt-2 grid grid-cols-1 gap-1 text-sm text-gray-300 sm:grid-cols-2">
        <li>• GPT-5.6 Sol/Terra/Luna, GPT-5.5 &amp; GPT-5.4 (incl. Mini/Nano, low→xhigh effort)</li>
        <li>• Claude Opus 4.8 / 4.7 / 4.6</li>
        <li>• Claude Sonnet 4.6 / 5 &amp; Claude Fable 5</li>
        <li>• Kimi K2.5 / K2.6 / K2.7-Coding</li>
        <li>• GLM 5.1 / 5.2</li>
        <li>• MiniMax M2.5 / M2.7 / M3</li>
        <li>• Xiaomi MiMo-V2.5-Pro</li>
        <li>• DeepSeek V4 Pro</li>
      </ul>
      <p className="mt-2 text-xs text-gray-500">
        Turn the &ldquo;Featured&rdquo; filter off on any page to explore all {ds.counts.models}{" "}
        tracked models. Featured status is derived from the model&apos;s family, so every reasoning
        variant of a featured family (e.g. each GPT-5.5 effort level) is included.
      </p>

      <h2 className="mt-6 mb-2 font-semibold">Snapshot</h2>
      <div className="card p-4 text-sm">
        <div>Dataset generated: <span className="tabular">{new Date(ds.generated_at).toUTCString()}</span></div>
        <div className="mt-1">Models: {ds.counts.models} · families: {ds.counts.families} · offers: {ds.counts.offers} · providers: {ds.counts.providers}</div>
        <div className="mt-2 text-xs text-gray-500">Per-source collection dates:</div>
        <ul className="mt-1 text-xs text-gray-400">
          {Object.entries(ds.sources).map(([k, v]) => <li key={k}>{k}: {v}</li>)}
        </ul>
      </div>

      <h2 className="mt-6 mb-2 font-semibold">Methodology</h2>
      <p className="text-sm text-gray-400">
        Costs default to modeled USD/task, using exact-variant AA output tokens, OpenRouter usage I/O (Chutes global fallback), and exact-endpoint cache-hit rates.
        Missing values are assumed and flagged: 1,000 output tokens/task, no cache discount, and zero additional cache writes. General traffic and benchmark tasks are proxies for coding-agent usage.
        Click an underlined price to inspect the full formula, inputs, dates and assumptions. Raw list-price mode uses your chosen fixed blend per million tokens (including 1:1, 3:1, 10:1, 100:1, input-only and output-only). Capability scores are shown as published; AA indices are 0–100, DesignArena values are Elo.
        The Composite score uses five slots: AA Coding, source-matched AA Coding Agent,
        AA Intelligence, DesignArena Frontend and DesignArena Full-Stack. AA values are clamped to 0–100. A DesignArena
        board qualifies at an app-selected minimum of 200 battles, aligned with the source&apos;s typical preliminary/reliability threshold; its Elo is converted to the expected score against a fixed Elo 1000
        opponent. Each observed slot is converted to its percentile among the current catalog&apos;s unique observed values.
        Every missing slot inherits that model&apos;s mean observed percentile, producing a base score exactly equal to the mean of its
        available percentiles. A final dominance-safe projection prevents missing data from reversing an otherwise unambiguous comparison:
        when one model covers every reliable slot of another measured model and is no worse in any shared slot,
        the catalog scores are adjusted by the smallest symmetric amount needed to keep the dominating model at least 0.1 points ahead.
        The unadjusted base and any adjustment are shown separately in model details. A model with no reliable observed slot receives the neutral fallback 50; its zero evidence
        coverage remains distinct from a measured score and is excluded from capability charts. Coding Agent results are
        attached to an exact or explicitly audited model/reasoning identity; every harness
        result is retained and their median is used. Family-scoped Intelligence.ai / DesignArena results are attached exactly once to the deterministic collapsed-family representative rather than copied to effort
        siblings. The provenance note explicitly states that this does not identify the tested effort setting. Raw DesignArena score views continue to show Elo. Stable model ids and repositories are preferred over
        fuzzy names so distinct releases, modes, context tiers and serving routes do not share the wrong price.
        See the repository README and <code>data/SCRAPING.md</code> for how each source is collected and refreshed.
      </p>
    </div>
  );
}


FILE app/gateways/page.tsx
import { GatewaysView } from "../../components/GatewaysView";
import gw from "../../data/gateways.json";

export const metadata = { title: "LLM Gateways" };

export default function GatewaysPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">LLM Gateways &amp; Routers</h1>
      <p className="mt-1 mb-5 max-w-3xl text-sm text-gray-400">
        Multi-provider gateways / routers / aggregators (one API key for many models). Compare them on what
        matters for European deployments: can the <b>actual inference be kept in the EU</b>, can the gateway
        <b> run locally / self-hosted</b>, and is it <b>open source</b>. Be skeptical of &ldquo;GDPR-compliant&rdquo;
        badges — most providers&apos; &ldquo;EU&rdquo; means EU-resident <i>logs/metadata</i>, not EU routing of the
        model inference. The <b>EU routing</b> column captures the real capability.
      </p>
      <GatewaysView gateways={gw.gateways} collectedAt={gw.collected_at} note={gw.note} />
    </div>
  );
}


FILE app/provider-explorer/page.tsx
import { getDataset } from "../../lib/data";
import { clientData } from "../../lib/client-model";
import { ProviderExplorer } from "../../components/ProviderExplorer";

export const metadata = { title: "Provider explorer" };

export default async function ProviderExplorerPage() {
  const ds = await getDataset();
  const data = clientData(ds);
  return (
    <div>
      <h1 className="text-2xl font-bold">Provider explorer</h1>
      <p className="mt-1 mb-5 max-w-3xl text-sm text-gray-400">
        Browse the <b>provider directory</b> on the left — each tagged <span className="text-amber-300">Hyperscaler</span> /
        {" "}<span className="text-emerald-300">EU</span> / <span className="text-sky-300">Non-US</span>, with its model count and HQ.
        Click a provider to see <b>every model it offers</b> and its price; click a model to compare that provider&apos;s
        price against <b>all other providers</b> of the same model, ranked cheapest-first in the selected cost scenario (adjusted USD/task by default).
      </p>
      <ProviderExplorer data={data} />
    </div>
  );
}


FILE app/icon.svg
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#0e131b"/><path d="M12 46V32a20 20 0 0 1 40 0v14" fill="none" stroke="#6caeff" stroke-width="4"/><path d="M10 48h44" stroke="#6caeff" stroke-width="4" stroke-linecap="round"/><path d="M22 41v-7m10 7V28m10 13V22" stroke="#67e0c1" stroke-width="4" stroke-linecap="round"/></svg>


FILE app/manifest.ts
import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Benchmark Heaven", short_name: "Benchmark Heaven",
    description: "Model benchmarks, provider prices and transparent adjusted task costs.",
    start_url: "/", display: "browser", background_color: "#0e131b", theme_color: "#0e131b",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" }],
  };
}


FILE components/Nav.tsx
"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { BrandMark } from './BrandMark';
import { ThemeToggle } from './ThemeToggle';

const LINKS = [
  ["/", "Overview"],
  ["/compare", "Compare"],
  ["/benchmarks", "Benchmarks"],
  ["/radar", "Radar"],
  ["/scatter", "Cost vs Capability"],
  ["/charts", "Charts"],
  ["/providers", "Providers per Model"],
  ["/provider-explorer", "Provider explorer"],
  ["/gateways", "Gateways"],
  ["/eu", "EU & Sovereign"],
  ["/about", "About"],
];

export function Nav() {
  const path = usePathname();
  return (
    <header className="border-b border-line bg-panel">
      <div className="mx-auto flex max-w-[1400px] flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
        <Link href="/" className="bh-brand-link flex min-h-11 items-center gap-2.5"><BrandMark className="h-9 w-9 shrink-0" /><span className="bh-wordmark">Benchmark Heaven</span></Link>
        <nav aria-label="Primary" className="relative order-3 flex w-full flex-wrap gap-1 text-sm lg:order-none lg:w-auto">
          {[LINKS[0], LINKS[2], LINKS[1], LINKS[3]].map(([href, label]) => {
            const active = href === "/" ? path === "/" : path.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? 'page' : undefined}
                className={`inline-flex min-h-11 items-center rounded-md px-3 py-1.5 ${active ? "bg-accent/15 text-accent" : "text-gray-300 hover:bg-accent/5"}`}
              >
                {label}
              </Link>
            );
          })}
          <details><summary className="flex min-h-11 cursor-pointer items-center rounded-md px-3 text-gray-300">More ▾</summary><div className="absolute left-0 top-full z-30 mt-2 grid w-64 max-w-full gap-1 rounded-xl border border-line bg-panel p-2 shadow-lg">{LINKS.slice(4).map(([href, label]) => <Link key={href} href={href} aria-current={path === href ? 'page' : undefined} className={`rounded-md px-3 py-3 ${path === href ? 'text-accent bg-accent/10' : 'hover:bg-accent/5'}`} onClick={(e) => e.currentTarget.closest('details')?.removeAttribute('open')}>{label}</Link>)}</div></details>
        </nav>
        <div className="ml-auto"><ThemeToggle /></div>
      </div>
    </header>
  );
}


FILE components/BrandMark.tsx
export function BrandMark({ className }: { className?: string }) {
  return <svg viewBox="0 0 64 64" width="64" height="64" className={className} aria-hidden="true" focusable="false"><rect width="64" height="64" rx="16" fill="#0e131b"/><path d="M12 46V32a20 20 0 0 1 40 0v14" fill="none" stroke="#6caeff" strokeWidth="4"/><path d="M10 48h44" stroke="#6caeff" strokeWidth="4" strokeLinecap="round"/><path d="M22 41v-7m10 7V28m10 13V22" stroke="#67e0c1" strokeWidth="4" strokeLinecap="round"/></svg>;
}


FILE docs/brand.md
# Benchmark Heaven brand

Use **Benchmark Heaven**, two title-case words. The domain is **benchmarkheaven.com**. Do not abbreviate the product to MMC. The GitHub repository and on-disk project paths retain `model-market-comparison` for compatibility.

**Benchmarks in perspective. Costs in context.**

## Direction: Observatory

The arch frames a field of measurements; three bars suggest comparison without pretending to be actual data. The baseline anchors the mark. This is an observatory for published evidence, not a promise that any model is best. The final small-size mark omits the concept star to keep its silhouette clear at 16 pixels.

[Three visual concepts](../public/brand/variants.svg) compare Observatory, Cloudline and a BH monogram. Observatory ties the name to the product's analytical purpose. Cloudline feels more like a cloud hosting service; the monogram is compact but tells a new visitor little about the product. The selected production geometry is refined separately in [mark.svg](../public/brand/mark.svg).

## Color and typography

The existing accessible chart palette becomes part of a coherent editorial identity. These values are implemented in `app/globals.css`; color never replaces score labels, units, source flags or chart line patterns.

| Role | Dark | Light |
| --- | --- | --- |
| Canvas | `#0e131b` | `#f5f8fc` |
| Panel | `#171e29` | `#ffffff` |
| Text | `#edf2f8` | `#182639` |
| Muted text | `#adb9ca` | `#4c5e75` |
| Sky / links and focus | `#6caeff` | `#1d4eb9` |
| Sea glass / supporting emphasis | `#67e0c1` | `#046d5b` |
| Amber / caveats | `#ffc56f` | `#914509` |

Use Georgia, then Times New Roman/serif, for the wordmark and display headings. Use the operating system sans-serif stack for navigation, controls and data; retain tabular numerals. No font request or remote font dependency. Platform font fallbacks can change letterforms. Social artwork is rasterized once from the checked-in SVG for predictable sharing.

## Mark and assets

- [Navigation/favicons master](../public/brand/mark.svg), mirrored in `components/BrandMark.tsx` and `app/icon.svg`.
- [README wordmark](../public/brand/wordmark.svg), with an explicit dark backplate so it works in both GitHub themes.
- [Social source](../public/brand/og-image.svg) and 1200 × 630 [PNG](../public/brand/og-image.png).
- `app/apple-icon.png`: 180 × 180 touch icon.

Keep the mark square and undistorted. Leave at least one quarter of its width as clear space in standalone artwork. Decorative SVGs are hidden from assistive technology when adjacent text supplies the name. Use meaningful alt text on standalone images.

## Voice

Calm, precise and curious. Explain what a comparison can establish and make its limits easy to find. Use “estimated task cost”, “source”, “observed on” and “not published” where applicable. Distinguish vendor claims from measurements. Avoid “definitive”, “most accurate”, “verified daily” or “best model” without evidence. Never decorate a brand asset with made-up scores.

The product says “Find the model that meets your benchmark threshold”; a result explains the threshold, price inputs and original source dates. The README and API notices state exactly what moved. German Telegram templates use Benchmark Heaven and retain the quiet notification policy.


FILE public/brand/mark.svg
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#0e131b"/><path d="M12 46V32a20 20 0 0 1 40 0v14" fill="none" stroke="#6caeff" stroke-width="4"/><path d="M10 48h44" stroke="#6caeff" stroke-width="4" stroke-linecap="round"/><path d="M22 41v-7m10 7V28m10 13V22" stroke="#67e0c1" stroke-width="4" stroke-linecap="round"/></svg>


FILE public/brand/wordmark.svg
<svg xmlns="http://www.w3.org/2000/svg" width="900" height="180" viewBox="0 0 900 180" role="img" aria-labelledby="title"><title id="title">Benchmark Heaven</title><rect width="900" height="180" rx="16" fill="#0e131b"/><g transform="translate(36 38) scale(1.625)"><rect width="64" height="64" rx="16" fill="#0e131b"/><path d="M12 46V32a20 20 0 0 1 40 0v14" fill="none" stroke="#6caeff" stroke-width="4"/><path d="M10 48h44" stroke="#6caeff" stroke-width="4" stroke-linecap="round"/><path d="M22 41v-7m10 7V28m10 13V22" stroke="#67e0c1" stroke-width="4" stroke-linecap="round"/></g><text x="172" y="92" fill="#edf2f8" font-family="Georgia,serif" font-size="54" letter-spacing="-2">Benchmark Heaven</text><text x="174" y="128" fill="#67e0c1" font-family="Arial,sans-serif" font-size="19">Benchmarks in perspective. Costs in context.</text></svg>


FILE public/brand/variants.svg
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1200" height="660" viewBox="0 0 1200 660" font-family="Helvetica,Arial,sans-serif">
<defs>
<g id="obs">
<path d="M14 74a36 36 0 0 1 72 0" fill="none" stroke="#6caeff" stroke-width="5"/>
<line x1="8" y1="74" x2="92" y2="74" stroke="#0e131b" stroke-width="4"/>
<rect x="30" y="58" width="9" height="16" fill="#67e0c1"/>
<rect x="45" y="48" width="9" height="26" fill="#67e0c1"/>
<rect x="60" y="36" width="9" height="38" fill="#67e0c1"/>
<path d="M76 12l2.6 6.4 6.4 2.6-6.4 2.6-2.6 6.4-2.6-6.4-6.4-2.6 6.4-2.6z" fill="#6caeff"/>
</g>
<g id="cld">
<path d="M25 60a12 12 0 0 1 0-24 15 15 0 0 1 28-8 13 13 0 0 1 20 11 10.5 10.5 0 0 1-2 21z" fill="#f6efdf" stroke="#a394e0" stroke-width="3" stroke-linejoin="round"/>
<polyline points="26,56 42,44 54,50 74,30" fill="none" stroke="#7c68d6" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
<polygon points="84,20 80.8,29.6 74.4,23.2" fill="#7c68d6"/>
</g>
<g id="bh">
<rect x="48" y="40.5" width="23" height="7" fill="#d9a521"/>
<rect x="22" y="18" width="7" height="64" fill="#23201a"/>
<rect x="71" y="18" width="7" height="64" fill="#23201a"/>
<path d="M29 18h19a13 13 0 0 1 0 26H29m0 0h21a19 19 0 0 1 0 38H29" fill="none" stroke="#23201a" stroke-width="7"/>
</g>
</defs>
<rect width="1200" height="660" fill="#f4f3ee"/>
<text x="30" y="48" font-family="Georgia,serif" font-size="23" fill="#242830">Benchmark Heaven · Brand Directions</text>
<text x="1170" y="48" font-size="12" fill="#59554e" text-anchor="end">Three concepts · September 2026</text>
<line x1="30" y1="64" x2="1170" y2="64" stroke="#e2ddd2"/>

<rect x="30" y="80" width="360" height="524" rx="14" fill="#ffffff" stroke="#e2ddd2"/>
<use xlink:href="#obs" transform="translate(120 96) scale(1.2)"/>
<text x="210" y="262" font-family="Georgia,serif" font-size="25" fill="#1c2027" text-anchor="middle">Benchmark Heaven</text>
<rect x="175" y="272" width="70" height="3" rx="1.5" fill="#6caeff"/>
<text x="210" y="302" font-size="11" letter-spacing="3" fill="#59554e" text-anchor="middle">OBSERVATORY</text>
<text x="210" y="336" font-size="12.5" fill="#6d6960" text-anchor="middle">Calm, instrument-like: an arch frames the</text>
<text x="210" y="355" font-size="12.5" fill="#6d6960" text-anchor="middle">horizon, bars rise like readings, and a small</text>
<text x="210" y="374" font-size="12.5" fill="#6d6960" text-anchor="middle">star marks a clear night of good data.</text>
<line x1="58" y1="404" x2="362" y2="404" stroke="#eceae2"/>
<text x="210" y="432" font-size="10" letter-spacing="2" fill="#59554e" text-anchor="middle">ICON SAMPLES</text>
<rect x="90" y="450" width="56" height="56" rx="10" fill="#eef4fb"/>
<use xlink:href="#obs" transform="translate(102 462) scale(.32)"/>
<rect x="224" y="470" width="36" height="36" rx="8" fill="#eef4fb"/>
<use xlink:href="#obs" transform="translate(234 480) scale(.16)"/>
<text x="118" y="528" font-size="11" fill="#59554e" text-anchor="middle">32 px</text>
<text x="242" y="528" font-size="11" fill="#59554e" text-anchor="middle">16 px</text>

<rect x="420" y="80" width="360" height="524" rx="14" fill="#ffffff" stroke="#e2ddd2"/>
<use xlink:href="#cld" transform="translate(510 96) scale(1.2)"/>
<text x="600" y="262" font-family="Georgia,serif" font-size="25" fill="#1c2027" text-anchor="middle">Benchmark Heaven</text>
<rect x="565" y="272" width="70" height="3" rx="1.5" fill="#a394e0"/>
<text x="600" y="302" font-size="11" letter-spacing="3" fill="#7c68d6" text-anchor="middle">CLOUDLINE</text>
<text x="600" y="336" font-size="12.5" fill="#6d6960" text-anchor="middle">Soft and approachable: a drifting cloud</text>
<text x="600" y="355" font-size="12.5" fill="#6d6960" text-anchor="middle">carries the benchmark line gently upward —</text>
<text x="600" y="374" font-size="12.5" fill="#6d6960" text-anchor="middle">friendly and human, never intimidating.</text>
<line x1="448" y1="404" x2="752" y2="404" stroke="#eceae2"/>
<text x="600" y="432" font-size="10" letter-spacing="2" fill="#59554e" text-anchor="middle">ICON SAMPLES</text>
<rect x="480" y="450" width="56" height="56" rx="10" fill="#f8f2e5"/>
<use xlink:href="#cld" transform="translate(492 462) scale(.32)"/>
<rect x="614" y="470" width="36" height="36" rx="8" fill="#f8f2e5"/>
<use xlink:href="#cld" transform="translate(624 480) scale(.16)"/>
<text x="508" y="528" font-size="11" fill="#59554e" text-anchor="middle">32 px</text>
<text x="632" y="528" font-size="11" fill="#59554e" text-anchor="middle">16 px</text>

<rect x="810" y="80" width="360" height="524" rx="14" fill="#ffffff" stroke="#e2ddd2"/>
<use xlink:href="#bh" transform="translate(900 96) scale(1.2)"/>
<text x="990" y="262" font-family="Georgia,serif" font-size="25" fill="#1c2027" text-anchor="middle">Benchmark Heaven</text>
<rect x="955" y="272" width="70" height="3" rx="1.5" fill="#d9a521"/>
<text x="990" y="302" font-size="11" letter-spacing="3" fill="#59554e" text-anchor="middle">BH MONOGRAM</text>
<text x="990" y="336" font-size="12.5" fill="#6d6960" text-anchor="middle">A compact geometric monogram where B</text>
<text x="990" y="355" font-size="12.5" fill="#6d6960" text-anchor="middle">and H share one connecting stroke —</text>
<text x="990" y="374" font-size="12.5" fill="#6d6960" text-anchor="middle">sturdy and abstract; detail reduces at 16 px.</text>
<line x1="838" y1="404" x2="1142" y2="404" stroke="#eceae2"/>
<text x="990" y="432" font-size="10" letter-spacing="2" fill="#59554e" text-anchor="middle">ICON SAMPLES</text>
<rect x="870" y="450" width="56" height="56" rx="10" fill="#f7f0db"/>
<use xlink:href="#bh" transform="translate(882 462) scale(.32)"/>
<rect x="1004" y="470" width="36" height="36" rx="8" fill="#f7f0db"/>
<use xlink:href="#bh" transform="translate(1014 480) scale(.16)"/>
<text x="898" y="528" font-size="11" fill="#59554e" text-anchor="middle">32 px</text>
<text x="1022" y="528" font-size="11" fill="#59554e" text-anchor="middle">16 px</text>
</svg>


FILE public/brand/og-image.svg
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630" role="img" aria-labelledby="title"><title id="title">Benchmark Heaven — Benchmarks in perspective. Costs in context.</title><rect width="1200" height="630" fill="#0e131b"/><path d="M760 520V265a190 190 0 0 1 380 0v255M715 520h485" stroke="#243a52" stroke-width="2" fill="none"/><path d="M825 488V368m125 120V288m125 200V208" stroke="#284e4b" stroke-width="24" stroke-linecap="round"/><g transform="translate(64 50)"><rect width="64" height="64" rx="16" fill="#0e131b"/><path d="M12 46V32a20 20 0 0 1 40 0v14" fill="none" stroke="#6caeff" stroke-width="4"/><path d="M10 48h44" stroke="#6caeff" stroke-width="4" stroke-linecap="round"/><path d="M22 41v-7m10 7V28m10 13V22" stroke="#67e0c1" stroke-width="4" stroke-linecap="round"/></g><text x="146" y="92" fill="#edf2f8" font-family="Georgia,serif" font-size="32">Benchmark Heaven</text><text x="64" y="267" fill="#edf2f8" font-family="Georgia,serif" font-size="72" letter-spacing="-2">Benchmarks in perspective.</text><text x="64" y="355" fill="#67e0c1" font-family="Georgia,serif" font-size="72" letter-spacing="-2">Costs in context.</text><text x="68" y="421" fill="#adb9ca" font-family="Arial,sans-serif" font-size="25">Model benchmarks · Provider prices · Transparent assumptions</text><path d="M64 508h600" stroke="#394657"/><text x="68" y="560" fill="#6caeff" font-family="Arial,sans-serif" font-size="23">benchmarkheaven.com</text></svg>


FILE package.json
{
  "name": "benchmark-heaven",
  "version": "1.0.0",
  "private": true,
  "description": "Benchmark Heaven: model benchmarks, provider prices and transparent adjusted task costs",
  "scripts": {
    "dev": "next dev -p 3000",
    "build": "next build",
    "start": "next start -p ${PORT:-3000}",
    "lint": "next lint",
    "data:fetch": "node scripts/fetch-live.mjs",
    "data:build": "node scripts/build-dataset.mjs",
    "data:refresh": "node scripts/fetch-live.mjs && node scripts/build-dataset.mjs",
    "data:efficiency": "node scripts/fetch-aa-efficiency.mjs && node scripts/fetch-openrouter-efficiency.mjs && node scripts/fetch-chutes-efficiency.mjs",
    "db:seed": "node scripts/seed-db.mjs",
    "test": "node --test test/",
    "prebuild": "node scripts/validate-benchmark-scores.mjs",
    "data:benchmarks": "node scripts/ingest-benchmark-scores.mjs"
  },
  "dependencies": {
    "next": "^15.5.25",
    "pg": "^8.13.1",
    "react": "19.0.0",
    "react-dom": "19.0.0",
    "recharts": "^2.15.0"
  },
  "devDependencies": {
    "@types/node": "^20.17.0",
    "@types/pg": "^8.11.10",
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.49",
    "tailwindcss": "^3.4.17",
    "typescript": "^5.7.3"
  },
  "engines": {
    "node": ">=20"
  },
  "overrides": {
    "next": {
      "postcss": "^8.5.23"
    }
  }
}

PACKAGE LOCK IDENTITY (dependencies not edited): {"name": "benchmark-heaven", "version": "1.0.0", "lockfileVersion": 3}
root package {"name": "benchmark-heaven", "version": "1.0.0", "dependencies": {"next": "^15.5.25", "pg": "^8.13.1", "react": "19.0.0", "react-dom": "19.0.0", "recharts": "^2.15.0"}, "devDependencies": {"@types/node": "^20.17.0", "@types/pg": "^8.11.10", "@types/react": "^19.0.0", "@types/react-dom": "^19.0.0", "autoprefixer": "^10.4.20", "postcss": "^8.4.49", "tailwindcss": "^3.4.17", "typescript": "^5.7.3"}, "engines": {"node": ">=20"}}

EXECUTION RECEIPT rendered/checks.json
{
  "at": "2026-09-11T02:07:14.327Z",
  "base": "http://127.0.0.1:3317",
  "metadata": {
    "og": "https://benchmarkheaven.com/brand/og-image.png",
    "site": "Benchmark Heaven",
    "twitter": "summary_large_image",
    "icon": "/icon.svg",
    "apple": "/apple-icon.png"
  },
  "checks": [
    {
      "name": "overview-light",
      "path": "/",
      "width": 1440,
      "height": 1000,
      "theme": "light",
      "title": "Benchmark Heaven — Model benchmarks & costs",
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "overflow": 0
    },
    {
      "name": "keyboard-skip",
      "passed": true
    },
    {
      "name": "overview-dark",
      "path": "/",
      "width": 1440,
      "height": 1000,
      "theme": "dark",
      "title": "Benchmark Heaven — Model benchmarks & costs",
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "overflow": 0
    },
    {
      "name": "overview-mobile",
      "path": "/",
      "width": 390,
      "height": 844,
      "theme": "light",
      "title": "Benchmark Heaven — Model benchmarks & costs",
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "overflow": 0
    },
    {
      "name": "overview-320",
      "path": "/",
      "width": 320,
      "height": 844,
      "theme": "dark",
      "title": "Benchmark Heaven — Model benchmarks & costs",
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "overflow": 0
    },
    {
      "name": "radar-mobile-dark",
      "path": "/radar",
      "width": 390,
      "height": 844,
      "theme": "dark",
      "title": "Benchmark Heaven — Model benchmarks & costs",
      "violations": [],
      "incomplete": [
        "color-contrast",
        "th-has-data-cells"
      ],
      "overflow": 0
    },
    {
      "name": "compare-dark",
      "path": "/compare",
      "width": 1440,
      "height": 1000,
      "theme": "dark",
      "title": "Benchmark Heaven — Model benchmarks & costs",
      "violations": [],
      "incomplete": [
        "color-contrast",
        "th-has-data-cells"
      ],
      "overflow": 0
    },
    {
      "name": "three-model-selection",
      "passed": true
    },
    {
      "name": "footer-light",
      "path": "/about",
      "width": 1440,
      "height": 1000,
      "theme": "light",
      "title": "Benchmark Heaven — Model benchmarks & costs",
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "overflow": 0
    },
    {
      "path": "/",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/compare",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/benchmarks",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/radar",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/charts",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/scatter",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/providers",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/provider-explorer",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/gateways",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/eu",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/about",
      "status": 200,
      "oldBrandAbsent": true
    },
    {
      "path": "/icon.svg",
      "status": 200,
      "type": "image/svg+xml"
    },
    {
      "path": "/apple-icon.png",
      "status": 200,
      "type": "image/png"
    },
    {
      "path": "/brand/og-image.png",
      "status": 200,
      "type": "image/png"
    },
    {
      "path": "/brand/wordmark.svg",
      "status": 200,
      "type": "image/svg+xml"
    },
    {
      "path": "/brand/variants.svg",
      "status": 200,
      "type": "image/svg+xml"
    },
    {
      "path": "/manifest.webmanifest",
      "status": 200,
      "type": "application/manifest+json"
    }
  ],
  "errors": []
}


EXECUTION RECEIPT dataset-continuity.json
{
  "sameExceptGeneratedAt": true,
  "counts": {
    "models": 835,
    "families": 650,
    "providers": 89,
    "offers": 2786
  },
  "observations": 13908
}


EXECUTION RECEIPT dataset-build.log
Registry: 73 versioned entries, 25 AA field mappings, 55 verified evidence files
✓ dataset.json { models: 835, families: 650, providers: 89, offers: 2786 }


EXECUTION RECEIPT tests.log
lity (0.330614ms)
✔ unscored transport smoke has a price ceiling and cannot select automatically (0.599409ms)
✔ critic excludes every producer family including aliases and explicit model pins (29.608262ms)
✔ worker CLI preserves output on provider failures and accepts a large embedded packet (3152.170375ms)
✔ transport smoke cannot accept arbitrary data work or a reference file (105.420403ms)
ℹ tests 146
ℹ suites 0
ℹ pass 146
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 7778.942476


EXECUTION RECEIPT typecheck.log


EXECUTION RECEIPT build.log

> benchmark-heaven@1.0.0 prebuild
> node scripts/validate-benchmark-scores.mjs

Benchmark source/build guard: { observations: 13908, source_files: 43, self_reported_verified: 1003 }

> benchmark-heaven@1.0.0 build
> next build

   ▲ Next.js 15.5.25

   Creating an optimized production build ...
 ✓ Compiled successfully in 9.7s
   Linting and checking validity of types ...
   Collecting page data ...
   Generating static pages (0/19) ...
   Generating static pages (4/19) 
   Generating static pages (9/19) 
   Generating static pages (14/19) 
 ✓ Generating static pages (19/19)
   Finalizing page optimization ...
   Collecting build traces ...

Route (app)                                 Size  First Load JS
┌ ○ /                                    6.75 kB         121 kB
├ ○ /_not-found                             1 kB         103 kB
├ ○ /about                                 153 B         103 kB
├ ƒ /api/benchmark-scores                  153 B         103 kB
├ ƒ /api/benchmark-view                    153 B         103 kB
├ ƒ /api/benchmarks                        153 B         103 kB
├ ƒ /api/dataset                           153 B         103 kB
├ ƒ /api/health                            153 B         103 kB
├ ƒ /api/meta                              153 B         103 kB
├ ƒ /api/models                            153 B         103 kB
├ ƒ /api/models/[id]                       153 B         103 kB
├ ƒ /api/price-comparison                  153 B         103 kB
├ ƒ /api/providers                         153 B         103 kB
├ ○ /apple-icon.png                          0 B            0 B
├ ○ /benchmarks                          3.16 kB         112 kB
├ ○ /charts                              5.47 kB         218 kB
├ ○ /compare                             1.83 kB         116 kB
├ ○ /eu                                  1.62 kB         116 kB
├ ○ /gateways                            1.61 kB         104 kB
├ ○ /icon.svg                                0 B            0 B
├ ○ /manifest.webmanifest                  153 B         103 kB
├ ƒ /models/[id]                            4 kB         115 kB
├ ○ /provider-explorer                   4.13 kB         115 kB
├ ○ /providers                           6.54 kB         117 kB
├ ○ /radar                                 179 B         115 kB
└ ○ /scatter                             9.73 kB         225 kB
+ First Load JS shared by all             102 kB
  ├ chunks/255-9e5c9994c6807ca2.js       46.1 kB
  ├ chunks/4bd1b696-409494caf8c83275.js  54.2 kB
  └ other shared chunks (total)           2.1 kB


ƒ Middleware                             34.2 kB

○  (Static)   prerendered as static content
ƒ  (Dynamic)  server-rendered on demand



EXECUTION RECEIPT prerender.log
✔ bundled catalog / is rendered once at build time (2.1339ms)
✔ bundled catalog /about is rendered once at build time (0.213656ms)
✔ bundled catalog /charts is rendered once at build time (0.153638ms)
✔ bundled catalog /compare is rendered once at build time (0.118058ms)
✔ bundled catalog /eu is rendered once at build time (0.139297ms)
✔ bundled catalog /gateways is rendered once at build time (0.103338ms)
✔ bundled catalog /provider-explorer is rendered once at build time (0.090308ms)
✔ bundled catalog /providers is rendered once at build time (0.095228ms)
✔ bundled catalog /scatter is rendered once at build time (0.195576ms)
✔ bundled catalog /benchmarks is rendered once at build time (0.270305ms)
✔ bundled catalog /radar is rendered once at build time (0.287195ms)
ℹ tests 11
ℹ suites 0
ℹ pass 11
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 85.059787

ACCESSIBILITY TREE overview-mobile-tree.txt
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Benchmark Heaven":
    - /url: /
  - navigation "Primary":
    - link "Overview":
      - /url: /
    - link "Benchmarks":
      - /url: /benchmarks
    - link "Compare":
      - /url: /compare
    - link "Radar":
      - /url: /radar
    - group: More ▾
  - button "Toggle color theme": Dark
- group: Price & provider filters · adjusted costs
- main:
  - paragraph: Benchmark Heaven / Model intelligence
  - heading "Benchmarks in perspective. Costs in context." [level=1]
  - paragraph: Find the model that meets your benchmark threshold, then compare estimated task costs across providers. Adjusted prices are on by default. Explore versioned results, check their sources, and see where evidence is missing. Raw list prices and fixed input/output blends remain selectable.
  - text: 835 Models 101 Featured 650 Model families 2,786 Provider offers 89 Provider channels
  - textbox "Search model or organization":
    - /placeholder: Search model / org…
  - combobox "Filter organization":
    - option "All orgs" [selected]
    - option "AI21 Labs"
    - option "AI9Stars"
    - option "AionLabs"
    - option "Alibaba"
    - option "Allen Institute for AI"
    - option "Amazon"
    - option "Anthracite"
    - option "Anthropic"
    - option "Apodex"
    - option "Arcee AI"
    - option "Baidu"
    - option "ByteDance Seed"
    - option "Celeris"
    - option "China Mobile"
    - option "Cohere"
    - option "Cursor"
    - option "Deep Cogito"
    - option "DeepSeek"
    - option "Dots Studio"
    - option "Google"
    - option "Gryphe"
    - option "IBM"
    - option "Inception"
    - option "InclusionAI"
    - option "Korea Telecom"
    - option "KwaiKAT"
    - option "Kwaipilot"
    - option "LG AI Research"
    - option "Liquid AI"
    - option "LongCat"
    - option "MBZUAI Institute of Foundation Models"
    - option "Mancer"
    - option "Meta"
    - option "Microsoft"
    - option "MiniMax"
    - option "Mistral"
    - option "Moonshot AI"
    - option "Morph"
    - option "Motif Technologies"
    - option "Multiverse Computing"
    - option "NVIDIA"
    - option "Nanbeige"
    - option "Naver"
    - option "Nex AGI"
    - option "Nous Research"
    - option "OpenAI"
    - option "OpenBMB"
    - option "Other"
    - option "Perceptron"
    - option "Perplexity"
    - option "Poolside"
    - option "Prime Intellect"
    - option "Reka AI"
    - option "Relace"
    - option "SK Telecom"
    - option "Sakana"
    - option "Sao10K"
    - option "Sapiens AI"
    - option "Sarvam"
    - option "ServiceNow"
    - option "StepFun"
    - option "Swiss AI Initiative"
    - option "TII UAE"
    - option "Tencent"
    - option "TheDrummer"
    - option "Thinking Machines"
    - option "Trillion Labs"
    - option "Undi95"
    - option "Upstage"
    - option "Venice"
    - option "Writer"
    - option "Xiaomi"
    - option "Z.ai"
    - option "inclusionAI"
    - option "xAI"
  - text: Max $/task
  - textbox "Max $/task":
    - /placeholder: e.g. 5
  - button "✓ Has benchmark evidence" [pressed]
  - button "✓ Has provider" [pressed]
  - button "✓ Measured task tokens only" [pressed]
  - text: 22 models · provider-filtered
  - paragraph: "Adjusted costs are modeled USD per task: AA output tokens × OpenRouter usage I/O (Chutes global fallback). These are general usage and benchmark proxies for coding-agent work. Missing AA data assumes 1,000 output tokens/task; unknown cache hit assumes 0%; unmeasured additional cache writes assume 0 tokens. Click any underlined price for exact inputs, dates and assumptions. Raw list prices use the selected fixed input/output blend, in USD per million tokens."
  - paragraph: Models without AA task-token measurements are excluded from this ranking. Turn off “Measured task tokens only” to include their assumed task costs.
  - table "Composite (coverage-neutral, dominance-safe percentiles, 0–100) · 5 fixed inputs; Coding Agent v1.4":
    - caption: Composite (coverage-neutral, dominance-safe percentiles, 0–100) · 5 fixed inputs; Coding Agent v1.4
    - rowgroup:
      - 'row "Model Org Composite Cheapest Adjusted $/task ▲ # Channels Top provider channels"':
        - columnheader "Model":
          - button "Model"
        - columnheader "Org":
          - button "Org"
        - columnheader "Composite":
          - button "Composite"
        - columnheader "Cheapest Adjusted $/task ▲":
          - button "Cheapest Adjusted $/task ▲"
        - columnheader "# Channels":
          - button "# Channels"
        - columnheader "Top provider channels"
    - rowgroup:
      - 'row "▸GLM-5.3-Flashopen★ Z.ai 77.4 $0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter 25 DeepInfra/OpenRouter $0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter Relace/OpenRouter $0.18575 $/task: show cost inputs for GLM-5.3-Flash, Relace / OpenRouter Wafer/OpenRouter $0.20754 $/task: show cost inputs for GLM-5.3-Flash, Wafer / OpenRouter"':
        - cell "▸GLM-5.3-Flashopen★":
          - text: ▸
          - link "GLM-5.3-Flash":
            - /url: /models/glm-5.3-flash%3A%3Adefault
          - text: open★
        - cell "Z.ai"
        - cell "77.4"
        - 'cell "$0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter"':
          - 'button "$0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter"': $0.1548 est.
        - cell "25"
        - 'cell "DeepInfra/OpenRouter $0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter Relace/OpenRouter $0.18575 $/task: show cost inputs for GLM-5.3-Flash, Relace / OpenRouter Wafer/OpenRouter $0.20754 $/task: show cost inputs for GLM-5.3-Flash, Wafer / OpenRouter"':
          - text: DeepInfra/OpenRouter
          - 'button "$0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter"': $0.1548 est.
          - text: Relace/OpenRouter
          - 'button "$0.18575 $/task: show cost inputs for GLM-5.3-Flash, Relace / OpenRouter"': $0.18575 est.
          - text: Wafer/OpenRouter
          - 'button "$0.20754 $/task: show cost inputs for GLM-5.3-Flash, Wafer / OpenRouter"': $0.20754 est.
      - 'row "▸MiMo-V2.5-Proopen★ Xiaomi 60.1 $0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter 5 GMICloud/OpenRouter $0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter DeepInfra/OpenRouter $0.27751 $/task: show cost inputs for MiMo-V2.5-Pro, DeepInfra / OpenRouter DigitalOcean/OpenRouter $0.29359 $/task: show cost inputs for MiMo-V2.5-Pro, DigitalOcean / OpenRouter"':
        - cell "▸MiMo-V2.5-Proopen★":
          - text: ▸
          - link "MiMo-V2.5-Pro":
            - /url: /models/mimo-v2.5-pro%3A%3Adefault
          - text: open★
        - cell "Xiaomi"
        - cell "60.1"
        - 'cell "$0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter"':
          - 'button "$0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter"': $0.20757 est.
        - cell "5"
        - 'cell "GMICloud/OpenRouter $0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter DeepInfra/OpenRouter $0.27751 $/task: show cost inputs for MiMo-V2.5-Pro, DeepInfra / OpenRouter DigitalOcean/OpenRouter $0.29359 $/task: show cost inputs for MiMo-V2.5-Pro, DigitalOcean / OpenRouter"':
          - text: GMICloud/OpenRouter
          - 'button "$0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter"': $0.20757 est.
          - text: DeepInfra/OpenRouter
          - 'button "$0.27751 $/task: show cost inputs for MiMo-V2.5-Pro, DeepInfra / OpenRouter"': $0.27751 est.
          - text: DigitalOcean/OpenRouter
          - 'button "$0.29359 $/task: show cost inputs for MiMo-V2.5-Pro, DigitalOcean / OpenRouter"': $0.29359 est.
      - 'row "▸GPT-5.6 Luna★ OpenAI 70.8 $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter 6 Azure/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter OpenAI/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), OpenAI / OpenRouter Azure AI Foundry $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure AI Foundry / Azure AI Foundry"':
        - cell "▸GPT-5.6 Luna★":
          - text: ▸
          - link "GPT-5.6 Luna":
            - /url: /models/gpt-5.6-luna%3A%3Amax
          - text: ★
        - cell "OpenAI"
        - cell "70.8"
        - 'cell "$0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter"':
          - 'button "$0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter"': $0.33111 est.
        - cell "6"
        - 'cell "Azure/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter OpenAI/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), OpenAI / OpenRouter Azure AI Foundry $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azu [rest omitted; full tree on disk]
ACCESSIBILITY TREE overview-dark-tree.txt
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Benchmark Heaven":
    - /url: /
  - navigation "Primary":
    - link "Overview":
      - /url: /
    - link "Benchmarks":
      - /url: /benchmarks
    - link "Compare":
      - /url: /compare
    - link "Radar":
      - /url: /radar
    - group: More ▾
  - button "Toggle color theme": Light
- group: Price & provider filters · adjusted costs
- main:
  - paragraph: Benchmark Heaven / Model intelligence
  - heading "Benchmarks in perspective. Costs in context." [level=1]
  - paragraph: Find the model that meets your benchmark threshold, then compare estimated task costs across providers. Adjusted prices are on by default. Explore versioned results, check their sources, and see where evidence is missing. Raw list prices and fixed input/output blends remain selectable.
  - text: 835 Models 101 Featured 650 Model families 2,786 Provider offers 89 Provider channels
  - textbox "Search model or organization":
    - /placeholder: Search model / org…
  - combobox "Filter organization":
    - option "All orgs" [selected]
    - option "AI21 Labs"
    - option "AI9Stars"
    - option "AionLabs"
    - option "Alibaba"
    - option "Allen Institute for AI"
    - option "Amazon"
    - option "Anthracite"
    - option "Anthropic"
    - option "Apodex"
    - option "Arcee AI"
    - option "Baidu"
    - option "ByteDance Seed"
    - option "Celeris"
    - option "China Mobile"
    - option "Cohere"
    - option "Cursor"
    - option "Deep Cogito"
    - option "DeepSeek"
    - option "Dots Studio"
    - option "Google"
    - option "Gryphe"
    - option "IBM"
    - option "Inception"
    - option "InclusionAI"
    - option "Korea Telecom"
    - option "KwaiKAT"
    - option "Kwaipilot"
    - option "LG AI Research"
    - option "Liquid AI"
    - option "LongCat"
    - option "MBZUAI Institute of Foundation Models"
    - option "Mancer"
    - option "Meta"
    - option "Microsoft"
    - option "MiniMax"
    - option "Mistral"
    - option "Moonshot AI"
    - option "Morph"
    - option "Motif Technologies"
    - option "Multiverse Computing"
    - option "NVIDIA"
    - option "Nanbeige"
    - option "Naver"
    - option "Nex AGI"
    - option "Nous Research"
    - option "OpenAI"
    - option "OpenBMB"
    - option "Other"
    - option "Perceptron"
    - option "Perplexity"
    - option "Poolside"
    - option "Prime Intellect"
    - option "Reka AI"
    - option "Relace"
    - option "SK Telecom"
    - option "Sakana"
    - option "Sao10K"
    - option "Sapiens AI"
    - option "Sarvam"
    - option "ServiceNow"
    - option "StepFun"
    - option "Swiss AI Initiative"
    - option "TII UAE"
    - option "Tencent"
    - option "TheDrummer"
    - option "Thinking Machines"
    - option "Trillion Labs"
    - option "Undi95"
    - option "Upstage"
    - option "Venice"
    - option "Writer"
    - option "Xiaomi"
    - option "Z.ai"
    - option "inclusionAI"
    - option "xAI"
  - text: Max $/task
  - textbox "Max $/task":
    - /placeholder: e.g. 5
  - button "✓ Has benchmark evidence" [pressed]
  - button "✓ Has provider" [pressed]
  - button "✓ Measured task tokens only" [pressed]
  - text: 22 models · provider-filtered
  - paragraph: "Adjusted costs are modeled USD per task: AA output tokens × OpenRouter usage I/O (Chutes global fallback). These are general usage and benchmark proxies for coding-agent work. Missing AA data assumes 1,000 output tokens/task; unknown cache hit assumes 0%; unmeasured additional cache writes assume 0 tokens. Click any underlined price for exact inputs, dates and assumptions. Raw list prices use the selected fixed input/output blend, in USD per million tokens."
  - paragraph: Models without AA task-token measurements are excluded from this ranking. Turn off “Measured task tokens only” to include their assumed task costs.
  - table "Composite (coverage-neutral, dominance-safe percentiles, 0–100) · 5 fixed inputs; Coding Agent v1.4":
    - caption: Composite (coverage-neutral, dominance-safe percentiles, 0–100) · 5 fixed inputs; Coding Agent v1.4
    - rowgroup:
      - 'row "Model Org Composite Cheapest Adjusted $/task ▲ # Channels Top provider channels"':
        - columnheader "Model":
          - button "Model"
        - columnheader "Org":
          - button "Org"
        - columnheader "Composite":
          - button "Composite"
        - columnheader "Cheapest Adjusted $/task ▲":
          - button "Cheapest Adjusted $/task ▲"
        - columnheader "# Channels":
          - button "# Channels"
        - columnheader "Top provider channels"
    - rowgroup:
      - 'row "▸GLM-5.3-Flashopen★ Z.ai 77.4 $0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter 25 DeepInfra/OpenRouter $0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter Relace/OpenRouter $0.18575 $/task: show cost inputs for GLM-5.3-Flash, Relace / OpenRouter Wafer/OpenRouter $0.20754 $/task: show cost inputs for GLM-5.3-Flash, Wafer / OpenRouter"':
        - cell "▸GLM-5.3-Flashopen★":
          - text: ▸
          - link "GLM-5.3-Flash":
            - /url: /models/glm-5.3-flash%3A%3Adefault
          - text: open★
        - cell "Z.ai"
        - cell "77.4"
        - 'cell "$0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter"':
          - 'button "$0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter"': $0.1548 est.
        - cell "25"
        - 'cell "DeepInfra/OpenRouter $0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter Relace/OpenRouter $0.18575 $/task: show cost inputs for GLM-5.3-Flash, Relace / OpenRouter Wafer/OpenRouter $0.20754 $/task: show cost inputs for GLM-5.3-Flash, Wafer / OpenRouter"':
          - text: DeepInfra/OpenRouter
          - 'button "$0.1548 $/task: show cost inputs for GLM-5.3-Flash, DeepInfra / OpenRouter"': $0.1548 est.
          - text: Relace/OpenRouter
          - 'button "$0.18575 $/task: show cost inputs for GLM-5.3-Flash, Relace / OpenRouter"': $0.18575 est.
          - text: Wafer/OpenRouter
          - 'button "$0.20754 $/task: show cost inputs for GLM-5.3-Flash, Wafer / OpenRouter"': $0.20754 est.
      - 'row "▸MiMo-V2.5-Proopen★ Xiaomi 60.1 $0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter 5 GMICloud/OpenRouter $0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter DeepInfra/OpenRouter $0.27751 $/task: show cost inputs for MiMo-V2.5-Pro, DeepInfra / OpenRouter DigitalOcean/OpenRouter $0.29359 $/task: show cost inputs for MiMo-V2.5-Pro, DigitalOcean / OpenRouter"':
        - cell "▸MiMo-V2.5-Proopen★":
          - text: ▸
          - link "MiMo-V2.5-Pro":
            - /url: /models/mimo-v2.5-pro%3A%3Adefault
          - text: open★
        - cell "Xiaomi"
        - cell "60.1"
        - 'cell "$0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter"':
          - 'button "$0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter"': $0.20757 est.
        - cell "5"
        - 'cell "GMICloud/OpenRouter $0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter DeepInfra/OpenRouter $0.27751 $/task: show cost inputs for MiMo-V2.5-Pro, DeepInfra / OpenRouter DigitalOcean/OpenRouter $0.29359 $/task: show cost inputs for MiMo-V2.5-Pro, DigitalOcean / OpenRouter"':
          - text: GMICloud/OpenRouter
          - 'button "$0.20757 $/task: show cost inputs for MiMo-V2.5-Pro, GMICloud / OpenRouter"': $0.20757 est.
          - text: DeepInfra/OpenRouter
          - 'button "$0.27751 $/task: show cost inputs for MiMo-V2.5-Pro, DeepInfra / OpenRouter"': $0.27751 est.
          - text: DigitalOcean/OpenRouter
          - 'button "$0.29359 $/task: show cost inputs for MiMo-V2.5-Pro, DigitalOcean / OpenRouter"': $0.29359 est.
      - 'row "▸GPT-5.6 Luna★ OpenAI 70.8 $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter 6 Azure/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter OpenAI/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), OpenAI / OpenRouter Azure AI Foundry $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure AI Foundry / Azure AI Foundry"':
        - cell "▸GPT-5.6 Luna★":
          - text: ▸
          - link "GPT-5.6 Luna":
            - /url: /models/gpt-5.6-luna%3A%3Amax
          - text: ★
        - cell "OpenAI"
        - cell "70.8"
        - 'cell "$0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter"':
          - 'button "$0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter"': $0.33111 est.
        - cell "6"
        - 'cell "Azure/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Azure / OpenRouter OpenAI/OpenRouter $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), OpenAI / OpenRouter Azure AI Foundry $0.33111 $/task: show cost inputs for GPT-5.6 Luna (max), Az [rest omitted; full tree on disk]
ACCESSIBILITY TREE footer-light-tree.txt
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Benchmark Heaven":
    - /url: /
  - navigation "Primary":
    - link "Overview":
      - /url: /
    - link "Benchmarks":
      - /url: /benchmarks
    - link "Compare":
      - /url: /compare
    - link "Radar":
      - /url: /radar
    - group: More ▾
  - button "Toggle color theme": Dark
- group: Price & provider filters · adjusted costs
- main:
  - heading "About & data sources" [level=1]
  - paragraph: Benchmark Heaven brings together pricing and benchmark data for open-source and frontier LLMs into one comparable view. Prices are normalized to USD per 1M tokens (input and output) unless a platform prices differently (GitHub Copilot's current token/AI-Credit rates and legacy request billing are shown on a separate product axis).
  - heading "Sources" [level=2]
  - list:
    - listitem: OpenRouter — model catalog and per-provider endpoint pricing (live API).
    - listitem: ArtificialAnalysis — Intelligence & Coding indices plus sub-benchmarks (LiveCodeBench, SciCode, Terminal-Bench Hard, τ²-Bench, GPQA, MMLU-Pro) via the v2 API.
    - listitem: AA Coding Agent Index — Composite retains v1.4, last collected 2026-09-09. AA now publishes v1.5 with different benchmark components. We collect it separately and do not mix the versions.
    - listitem: Some AA licensing and model identifiers are retained from earlier source publications. Their original dates are recorded per field in the downloadable dataset.
    - listitem: Intelligence.ai / DesignArena — Agentic Web Dev Frontend & Full-Stack Elo leaderboards.
    - listitem: AWS Bedrock — on-demand token pricing, European regions (eu-central-1 where available).
    - listitem: Azure AI Foundry — retail token meters plus model-card serving-region checks. A billing/resource region alone is not treated as proof that inference stays in the EU. By company policy, only Azure Direct Global DeepSeek V4 Pro and Kimi K2.7 Code are additionally eligible as EU-hosted equivalents; they remain marked Global because inference may occur outside the EU.
    - listitem: Google Vertex AI — pay-as-you-go token pricing for Gemini and Model Garden partner models (Claude, Llama, Mistral, DeepSeek, Qwen); offers are marked EU-hosted only where the model supports a documented European serving location.
    - listitem:
      - text: TensorX, Inceptron, Scaleway, IONOS, Mistral, Nebius, OVHcloud, STACKIT & T-Systems — direct European serverless/managed catalogs. TensorX is the broadest in-EU host for GLM/Kimi/DeepSeek/MiniMax; Inceptron serves GLM/Kimi/MiniMax from Finland; Scaleway and OVHcloud serve from France; STACKIT and T-Systems publish German/EU catalogs. Nebius is EU-capable but mixes EU, US and UK serving regions, so every model offer is checked separately. See the
      - link "EU & Sovereign":
        - /url: /eu
      - text: tab.
    - listitem: GitHub Copilot — current 26-model AI-Credit/token-price catalog plus the 25-model legacy premium-request multiplier table. The UI's separate per-request field applies only to eligible legacy annual Pro/Pro+ plans.
    - listitem: Anthropic / Claude Code — all 11 currently callable first-party API models, their cache/batch/list prices, active promotions and Claude Code Enterprise terms.
  - heading "What are “Featured” models?" [level=2]
  - paragraph: "★ Featured marks the specific models this tool was commissioned to track closely — the current frontier and leading open-weight families that matter most for the price/capability comparison. Filtering to “Featured” (the default on most pages) hides the long tail of older or niche models so the charts and tables stay focused. The featured set is:"
  - list:
    - listitem: • GPT-5.6 Sol/Terra/Luna, GPT-5.5 & GPT-5.4 (incl. Mini/Nano, low→xhigh effort)
    - listitem: • Claude Opus 4.8 / 4.7 / 4.6
    - listitem: • Claude Sonnet 4.6 / 5 & Claude Fable 5
    - listitem: • Kimi K2.5 / K2.6 / K2.7-Coding
    - listitem: • GLM 5.1 / 5.2
    - listitem: • MiniMax M2.5 / M2.7 / M3
    - listitem: • Xiaomi MiMo-V2.5-Pro
    - listitem: • DeepSeek V4 Pro
  - paragraph: Turn the “Featured” filter off on any page to explore all 835 tracked models. Featured status is derived from the model's family, so every reasoning variant of a featured family (e.g. each GPT-5.5 effort level) is included.
  - heading "Snapshot" [level=2]
  - text: "Dataset generated: Fri, 11 Sep 2026 02:00:49 GMT Models: 835 · families: 650 · offers: 2786 · providers: 89 Per-source collection dates:"
  - list:
    - listitem: "openrouter: 2026-09-10"
    - listitem: "artificialanalysis: 2026-09-10"
    - listitem: "designarena: 2026-09-10"
    - listitem: "aws_bedrock: 2026-09-08"
    - listitem: "azure_foundry: 2026-09-08"
    - listitem: "google_vertex: 2026-09-08"
    - listitem: "nebius: 2026-09-08"
    - listitem: "inceptron: 2026-09-08"
    - listitem: "scaleway: 2026-09-08"
    - listitem: "ionos: 2026-09-08"
    - listitem: "mistral: 2026-09-08"
    - listitem: "tensorx: 2026-09-08"
    - listitem: "chutes: 2026-09-08"
    - listitem: "ovhcloud: 2026-09-08"
    - listitem: "stackit: 2026-09-08"
    - listitem: "t_systems_llm_hub: 2026-09-08"
    - listitem: "aa_coding_agents: 2026-09-09"
    - listitem: "github_copilot: 2026-09-08"
    - listitem: "claude_code: 2026-09-08"
    - listitem: "aa_coding_agents_v1_5: 2026-09-10"
    - listitem: "provider_meta: 2026-07-12"
    - listitem: "aa_efficiency: 2026-09-10T20:13:54.198Z"
    - listitem: "openrouter_efficiency: 2026-09-10T20:13:54.306Z"
    - listitem: "chutes_efficiency: 2026-09-10T19:44:35.632Z"
  - heading "Methodology" [level=2]
  - paragraph:
    - text: "Costs default to modeled USD/task, using exact-variant AA output tokens, OpenRouter usage I/O (Chutes global fallback), and exact-endpoint cache-hit rates. Missing values are assumed and flagged: 1,000 output tokens/task, no cache discount, and zero additional cache writes. General traffic and benchmark tasks are proxies for coding-agent usage. Click an underlined price to inspect the full formula, inputs, dates and assumptions. Raw list-price mode uses your chosen fixed blend per million tokens (including 1:1, 3:1, 10:1, 100:1, input-only and output-only). Capability scores are shown as published; AA indices are 0–100, DesignArena values are Elo. The Composite score uses five slots: AA Coding, source-matched AA Coding Agent, AA Intelligence, DesignArena Frontend and DesignArena Full-Stack. AA values are clamped to 0–100. A DesignArena board qualifies at an app-selected minimum of 200 battles, aligned with the source's typical preliminary/reliability threshold; its Elo is converted to the expected score against a fixed Elo 1000 opponent. Each observed slot is converted to its percentile among the current catalog's unique observed values. Every missing slot inherits that model's mean observed percentile, producing a base score exactly equal to the mean of its available percentiles. A final dominance-safe projection prevents missing data from reversing an otherwise unambiguous comparison: when one model covers every reliable slot of another measured model and is no worse in any shared slot, the catalog scores are adjusted by the smallest symmetric amount needed to keep the dominating model at least 0.1 points ahead. The unadjusted base and any adjustment are shown separately in model details. A model with no reliable observed slot receives the neutral fallback 50; its zero evidence coverage remains distinct from a measured score and is excluded from capability charts. Coding Agent results are attached to an exact or explicitly audited model/reasoning identity; every harness result is retained and their median is used. Family-scoped Intelligence.ai / DesignArena results are attached exactly once to the deterministic collapsed-family representative rather than copied to effort siblings. The provenance note explicitly states that this does not identify the tested effort setting. Raw DesignArena score views continue to show Elo. Stable model ids and repositories are preferred over fuzzy names so distinct releases, modes, context tiers and serving routes do not share the wrong price. See the repository README and"
    - code: data/SCRAPING.md
    - text: for how each source is collected and refreshed.
- contentinfo:
  - text: Benchmark Heaven
  - link "Sources & methodology":
    - /url: /about
  - link "Public API":
    - /url: https://github.com/fstandhartinger/model-market-comparison/blob/main/API.md
  - link "GitHub":
    - /url: https://github.com/fstandhartinger/model-market-comparison
  - paragraph: Benchmarks in perspective. Costs in context. Every result has a source; every estimate has assumptions.
  - paragraph: Data from OpenRouter, Artificial Analysis, Intelligence.ai / DesignArena, benchmark maintainers and provider catalogs. Raw token prices are USD per 1M tokens; adjusted task costs are estimates with visible inputs. Source dates vary. Check the [rest omitted; full tree on disk]