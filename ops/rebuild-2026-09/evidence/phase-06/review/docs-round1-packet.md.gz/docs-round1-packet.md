Review our own phase06 documentation and remaining verification-script/config artifacts. Read-only QA round 1. Return raw JSON beginning { and ending }, no Markdown or backticks: artifact_id, artifact_sha256, round, verdict (pass/revise/blocked), coverage_checked, errors_found, findings(id,severity,location,evidence,repair), fixed:[], uncertainties, missing_evidence. Verify claims against master brief and supplied exact execution/critic/source receipts. Every feature claimed must be supported; later phases remain unclaimed. The visual review is already performed separately using actual images and input/output hash receipts; do not claim you saw those pixels in this text-only documentation review. Do not execute sources. Distinguish local execution from live deployment, which is explicitly pending. Check the remaining browser script changes and legacy version labels; the analytics and UI source was reviewed separately.
{
  "artifact_id": "phase06-docs-and-coverage",
  "round": 1,
  "files": {
    "docs/benchmark-explorer.md": "6b8a5a9f06dd509ea3bfa721fece9303275aa8a5450ca729425e23eaf7af3ad0",
    "API.md": "59e5c33ad1df47e82b598ba95b2387d921ddd2f677a97c6542f2d4be3058ead9",
    "README.md": "5ed2d65d4c719dd9d610f2172c792665909f567028a703d49126115f75ad962d",
    "CHANGELOG.md": "1ded69151c40ec21981abe15484ae77c101888d84f1faf68efc6542cd553f419",
    "ops/rebuild-2026-09/COVERAGE.md": "c51b6b7765b7690792994adbca07c56fae255b1f3bbd022f1101925bd2e105c7",
    "ops/rebuild-2026-09/REPORT.md": "9baa7bfff6d77c2d299e29e16dc8a61b406e88b0f2b9418949ef836023189ec2",
    "scripts/check-benchmark-ui.mjs": "75d504d286ccf6cb8f603c30522543e13600b2c109d63ca620047e00245b7271",
    "scripts/check-benchmark-legacy-ui.mjs": "36035a8b75a0e67a2a2968859958b715af0af9427a96f450e72a17dea8ff65b9",
    "tailwind.config.ts": "17b3e38ca73d587a91ce52157a4f31990293a2526d9be36c514d785134abd90a",
    "lib/types.ts": "298dbb7226255a116e3536b861236bcb2ab0f8ee147ddec5b7d063d1549fbf55",
    "test/production/prerender.mjs": "5626cac2a1b132ba618abbceeaf4e23a4541bca5469d80026a2daf7572499314"
  },
  "artifact_sha256": "976a0e5605bba4a5f1b92b3620bb2c8fdcd71d8d101d159f321703a3a5a4f789"
}
PRIMARY COMMISSION
# Master brief — "Benchmark Heaven" rebuild (2026-09-10)

**Owner of this work:** Codex CLI running `gpt-6-astra` at reasoning effort `xhigh`, on the
Sandy Hetzner server (`65.109.49.103`), in `/opt/model-market-comparison`.
**Commissioned by:** Florian, via a Claude Code session on 2026-09-10.
**Repo:** https://github.com/fstandhartinger/model-market-comparison (public, `main`).
**Live today:** https://model-market-comparison.app.mintapis.com → to become **https://benchmarkheaven.com**

You (Astra) are the **owner and quality gate**. You do not have to type every token yourself:
delegate bulk work to cheap/free worker models (§7), but **you** review, verify and are
accountable for every artifact that lands in the repo. Nothing merges that you have not
checked. See §8 for the gauntlet-loop discipline that governs every phase.

Work through the phases in `phases/`, one at a time, in order. `bin/tick.sh` (cron, every
10 min) starts the next phase when the previous one is done; state lives in `state.json`.

---

## 0. Ground rules

1. **Read `10-RECON-FINDINGS.md` first.** A Claude session already did the expensive
   recon on the three hardest data questions. Do not re-discover what is written there.
2. **The app must never be broken on `main`.** Every phase ends with `npm test` green,
   `node scripts/build-dataset.mjs` clean, `npx tsc --noEmit -p .` clean, a commit, a push
   and a verified live deploy. Small commits per phase, not one giant one.
3. **The daily refresh cron must keep working the whole time.** It runs at 05:17 UTC from
   `/opt/mmc-daily/run.sh`. If your rebuild changes the data pipeline, update that prompt
   in the same commit. Never leave the cron pointing at a script that no longer exists.
4. **Data honesty is the product.** Every number in the dataset carries its provenance
   (source, URL, date, and whether it is *measured by a third party*, *self-reported by the
   vendor*, or *derived by us*). A number you cannot attribute does not ship. Estimated or
   imputed values must be flagged as such in the JSON and visibly in the UI.
5. **Never invent a benchmark score.** If a worker model returns a score you cannot verify
   against a primary source, drop the row and log it as unverified. A missing cell is fine;
   a wrong cell destroys the product's reason to exist.
6. **Respect robots.txt, rate limits and bot protection.** Do not circumvent any access
   control, ever. If a source is not reachable politely, mark it unavailable and move on.
7. **Secrets:** on Sandy they live in `/root/.config/dev-secrets.env` and `/etc/environment`.
   Relevant: `OPEN_ROUTER_API_KEY` (note the underscore), `CHUTES_API_KEY`,
   `ARTIF_ANALYSIS_API_KEY` (the fetch script expects `ARTIFICIAL_ANALYSIS_API_KEY` — the
   run scripts already alias it), `TG_BOT_TOKEN`/`TG_CHAT_ID`, `ELEVENLABS_API_KEY`.
   Never echo a secret value into a log, a commit or a Telegram message.
8. **You run on Florian's ChatGPT Pro subscription, never on API-key billing.** The
   rebuild runs as the `flori` user on Sandy, whose `~/.codex/auth.json` is
   `auth_mode: chatgpt`. `run-phase.sh` unsets `OPENAI_API_KEY` before invoking codex and
   refuses to start unless `codex login status` reports ChatGPT. If you ever see codex
   report API-key auth, stop and report it — do not work around it.
9. **Budget discipline.** Subscription capacity is finite and shared with everything else
   Florian runs, and `model_reasoning_effort="xhigh"` across many parallel agents exhausts
   it. Your job is judgement,
   architecture, review and the tricky code. Scraping, bulk extraction, repetitive
   transformation, first drafts of long documents and mechanical refactors go to the free
   workers in §7. If a phase is burning tokens on something mechanical, stop and delegate.

---

## 1. What the product becomes

Today the app compares LLM **prices** and a handful of **benchmark indices** across
**providers**. It should become the most complete, most honest, best-looking public
overview of *model data, provider data, price data and benchmark data* that exists —
rebranded as **Benchmark Heaven**.

Three substantive additions, one UI revamp, one rebrand, plus the automation that keeps
all of it fresh daily.

---

## 2. Feature A — Token & caching-efficiency adjusted costs (default ON)

The app's cost model today assumes one fixed input:output blend. Three things are missing.

### A1 — Realistic input:output ratio (agentic coding workloads)

The base case we want to represent is **typical agentic usage of coding-agent tools**
(Claude Code, Codex, opencode): huge cached-ish input, comparatively small output.

- Preferred: derive a **per-model** empirical ratio. See `10-RECON-FINDINGS.md` §1 —
  Artificial Analysis publishes `canonicalIntelligenceIndexTokenCount`
  (`{input, output, answer, reasoning}`) per model, which is a real measured token budget
  over a whole benchmark run and yields a per-model input:output ratio directly.
- Cross-check against OpenRouter statistics if a per-model aggregate is reachable, and
  against the Chutes API (https://api.chutes.ai/openapi.json) for typical LLM values.
- Fall back to a single documented global ratio if per-model data is missing — but record
  which models use the fallback, and show it in the UI.
- Keep the existing fixed blends available as alternative scenarios the user can pick.

### A2 — Tokens needed per task (verbosity / reasoning overhead)

Two models with the same list price are not equally expensive if one burns 5× the output
tokens to solve the same task. Artificial Analysis measures exactly this: the
"Output Tokens per Intelligence Index Task" chart, i.e.
`intelligenceIndexOutputTokensPerTask = {reasoning, answer, output}` — see
`10-RECON-FINDINGS.md` §1 for the exact extraction, including the caveat that the homepage
payload only ships this for ~24 chart-selected models and how to get it for all.

Ingest per model+variant (reasoning effort matters enormously here) and use it in the
effective-cost formula.

### A3 — Caching efficiency, per **model × provider**

Cached input tokens are cheaper, and how much you actually get cached differs per
inference provider. Collect the cache-hit statistics OpenRouter shows on a model's pricing
section (e.g. https://openrouter.ai/moonshotai/kimi-k3#pricing) **per model+endpoint**,
together with the cache read/write prices we already have in several catalogs.

### A4 — The effective-cost engine

Compose the above into an `effective_cost_per_task` (and per-1M-blended equivalent):

```
effective_cost = (input_tokens_per_task × (1 − cache_hit_rate) × input_price
               +  input_tokens_per_task × cache_hit_rate      × cache_read_price
               +  cache_write_tokens    × cache_write_price
               +  output_tokens_per_task × output_price) 
```

- Every term must degrade gracefully when a component is unknown (documented fallbacks,
  flagged as estimated).
- **Default the UI to the adjusted price**, with a clearly labelled toggle back to raw
  list price, and a per-row explainer showing which inputs produced the adjusted number.
  The point is that a user can answer *"which model is really cheapest at a given minimum
  benchmark score"* — make that question answerable in one screen.
- Unit-test the formula, including the degradation paths.

---

## 3. Feature B — The benchmark universe

Ambition: **the most complete benchmark collection in the AI-Twitter universe.**

### B1 — Benchmark registry

A first-class `data/raw/benchmarks/` registry. Per benchmark:
`id, name, version, family (to group versions), category (Coding | Agentic | Math |
Reasoning | Knowledge | Science | Long-context | Writing | Roleplay | Instruction-following
| Vision | Multilingual | Safety/Alignment | Tool-use | Uncensored | Efficiency | Other),
one_sentence_description (English), scoring (what the number means, range, higher-better),
maintainer/who runs it, source_type (official_leaderboard | vendor_report | x_account |
huggingface | github | discord), primary_url, how_to_collect (an executable recipe),
update_cadence, saturated (bool + note), superseded_by, first_seen, last_verified`.

**Versioning is a hard requirement**: Terminal-Bench 4.0 scores must never be mixed with
3.0 scores. Version is part of the identity, comparisons are only ever within one version,
and the UI must show the version.

### B2 — Discovery

Cast the net wide, then prune:

- Public leaderboards and sites (SimpleBench, EQ-Bench and its suites, UGI Leaderboard,
  Fiction.liveBench, WeirdML, Vending-Bench, Aider polyglot, LiveBench, ARC-AGI, SWE-Bench
  variants, Terminal-Bench, GDPval, τ²-bench, Omniscience, CritPt, MLCR, IT-Bench, …).
  Note that Artificial Analysis's own payload already carries a dozen benchmarks we do not
  yet ingest (`10-RECON-FINDINGS.md` §1) — that is the cheapest possible win, do it first.
- **X/Twitter sweep.** Use the Sandy desktop Chrome (`gui-control-sandy` skill; the
  server's KDE session is reachable and Chrome holds a logged-in profile). **Use the
  `xplainervideo` X account for all searches — explicitly NOT `airesearch12`**, so
  Florian's main research account carries no bot-detection risk. Start with
  `https://x.com/search?q=benchmark&src=typed_query`, and use Grok in the X UI
  (`https://x.com/i/grok`) with prompts such as the one in `phases/phase-04-*.md`.
  Behave like a human user: no scripted scrolling storms, no parallel sessions.
- For each benchmark, record **where its results actually appear** (a leaderboard page, a
  specific X account that publishes them regularly, a HuggingFace space, a GitHub repo) —
  that recipe is what makes the daily refresh cheap forever.
- Prune deliberately: exclude saturated benchmarks (note *why*), pick the newest version,
  and record what you excluded and the reason, so the decision is reviewable.

### B3 — Self-reported scores

Collect vendor-claimed numbers from model-release posts, HuggingFace model cards and tech
reports. Store them **flagged as `self_reported`** with the source URL, alongside
independently measured numbers. Where a third party (e.g. Artificial Analysis) later
measures the same benchmark and the numbers diverge, surface the delta in the UI — that
discrepancy is one of the most interesting things the app can show. A gauntlet critic must
verify every captured number against its primary source before it ships.

### B4 — Composite stays as it is

Do **not** change the existing Composite score's inputs. The current sources are the ones
that are reliably available. New benchmarks are additive; they may power new views and new
sortable columns, but the headline Composite keeps its current definition. (If you have a
strong argument for a second, clearly-labelled experimental composite, propose it in the
final report — do not silently change the existing one.)

### B5 — Missing data must be elegant

Sparse coverage is the normal case. Never impute silently, never show a blank where the
reason matters. Distinguish *not tested*, *tested but not published*, *we could not reach
the source*, and *withheld/contested*. Sorting, filtering and comparison must all behave
sanely with holes, and coverage per model must be visible at a glance.

---

## 4. Feature C — UI revamp

The whole app gets a pass for usability and visual quality, judged by "absolutely perfect
standards". Concretely, at minimum:

1. **Radar charts.** On `/compare`, and as their own tab, where the user picks **up to 4
   models** and sees them overlaid on a radar whose axes are the benchmarks we collect
   (Artificial Analysis, DesignArena, and the new registry). Handle differing scales
   (normalize per axis, state how), handle missing axes honestly, let the user choose which
   axes to plot, keep it readable in light and dark.
2. **Per-model benchmark sheet** — the complete score list for one model, grouped by
   category, with version, source, date, self-reported flag and links.
3. **Per-benchmark view** — the inverse direction: pick a benchmark, get the model ranking,
   filterable, with coverage and provenance.
4. **Model-vs-model comparison** across the full benchmark set.
5. **Anomaly / outlier highlighting.** For every model, surface at a glance where it is
   unusually strong or unusually weak relative to its own overall level (e.g. z-score of a
   benchmark against that model's own profile and against the peer distribution). Show the
   self-reported-vs-measured divergences from §3 B3 here too. Make it explainable: the user
   must be able to see *why* something was flagged.
6. General revamp: information hierarchy, navigation, responsive behaviour, empty/loading
   states, accessibility (keyboard, contrast, focus), fast first paint, and no layout jank.
   Design quality is part of the deliverable, not a nice-to-have.

---

## 5. Rebrand — Benchmark Heaven

- Domain **benchmarkheaven.com** was just bought at Namecheap. Hosting stays on the Sandy
  PaaS (Coolify). You need: DNS A record → `65.109.49.103`, the domain added to the Coolify
  app (uuid `ggbs6upie6tqsousmrkw0vja`), TLS issued, and the old
  `model-market-comparison.app.mintapis.com` host kept working (redirect or serve both).
- There are **no Namecheap API credentials** in the vault. Try the Namecheap web UI in
  Sandy's logged-in Chrome (see the `self-service-provisioning` skill). If login is gated,
  do everything else and hand Florian the exact DNS records to paste, via Telegram.
- Develop real branding: name, logo/mark, favicon, colour system, typography, tone of the
  copy, og-image, README header. It should look like a product, not a rename.
- Update every user-visible mention, `app/layout.tsx` metadata, README, API docs, and the
  fork-sync prompt.

---

## 6. Automation — daily, self-critical, cheap

- Rebuild the daily refresh so it covers the new data (token efficiency, caching stats,
  benchmark registry, self-reported scores) as well as the existing sources.
- Structure each nightly run as a **gauntlet loop** (§8): a cheap worker collects, a critic
  verifies against primary sources, disagreements are resolved or the row is dropped.
- **Worker-model selection must be dynamic.** Continuously discover which OpenRouter models
  are currently free (`:free` suffix) or near-free, and pick from them — but never use a
  model below **Artificial Analysis Intelligence Index 34**, because weak models produce
  catastrophic data. We already have the AA index in our own dataset, so the picker can
  score candidates from our own data. Known-good today: `nex-agi/nex-n2.5-pro:free`,
  `inclusionai/ling-3.0-flash-vl:free`, DeepSeek V4.1 Flash (very cheap), Kimi K3 via
  Chutes (free for us). Ship this as a reusable script + skill, not a hardcoded list.
- Keep the existing Telegram policy: **quiet by default.** No daily "all good" messages.
  Notify only on (a) a new family entering the top 5, (b) a failed run at most once per 7
  days, and — new — (c) a genuinely notable data event (a major new model, or a large
  self-reported-vs-measured divergence). Florian explicitly does not want spam.

---

## 7. Delegation — who does which work

| Work | Runs on | How |
|---|---|---|
| Architecture, schema design, review, tricky code, final say | **you (gpt-6-astra xhigh)** | directly |
| Scraping, bulk extraction, first drafts, mechanical refactors, long boring documents | free/cheap workers | `bin/worker.sh` |
| Critic passes in the gauntlet loop | a *different* model than the one that produced the artifact | `bin/worker.sh --critic` |

`bin/worker.sh` wraps: opencode (Kimi K3 via Chutes — free for us), OpenRouter free models,
and DeepSeek V4.1 Flash. `bin/pick-worker-models.mjs` returns the currently viable free
models filtered by AA Intelligence Index ≥ 34. Prefer the cheapest model that is good
enough for the specific job, and always have a critic of a *different* family check
data-bearing output.

---

## 8. The gauntlet loop

Research the technique properly and write down what you learn (phase 1 deliverable). The
working definition for this project:

> An artifact is not accepted because its author is confident. It is accepted because a
> separate, adversarially-instructed reviewer tried to find what is wrong with it against
> primary sources, and either found nothing or the findings were fixed. Then the loop runs
> again until a round produces no new findings, or a bounded number of rounds is reached.

Rules for this project:

- **Framing is defensive, never offensive.** This is quality assurance of *our own* code
  and *our own* data before it reaches users. Never phrase a critic prompt as breaking,
  attacking, or circumventing anything. (This matters: an aggressively-worded review prompt
  previously triggered a policy flag on the account.)
- The critic must be a **different model** from the producer, and must be given the
  primary sources, not the producer's claims.
- Critic output is structured: `errors_found`, `fixed`, and a report with one line of
  evidence (a URL or a command output) per finding.
- Rounds are bounded (2–3 per artifact) and the residue is written down rather than hidden:
  what is still uncertain goes into the phase report.
- Apply it to **everything**, not just benchmark numbers: prices, UI copy, accessibility,
  the design, the docs.

---

## 9. Definition of done

- [ ] All features in §2–§6 implemented, tested, documented.
- [ ] `npm test` green, typecheck clean, build clean.
- [ ] Committed and pushed to `main` in reviewable commits.
- [ ] Deployed and **verified live** on https://benchmarkheaven.com (and the old host still
      resolving), with today's data.
- [ ] Daily cron rebuilt, gauntlet-based, running on free/cheap workers, verified by an
      actual dry run — not just by reading the script.
- [ ] Skills written and installed for **every** agent runtime and in **both** places
      (this machine and Sandy): Claude Code (`~/.claude/skills/<name>/SKILL.md`), Codex
      (`~/.codex/`), opencode. They must make the recurring data collection cheap and
      repeatable for a future agent that knows nothing about this project.
- [ ] `CHANGELOG.md` and the downstream-consumer docs updated: any app that syncs from this
      repo must be able to find the data after the rebrand — call out explicitly what moved
      (URLs, endpoints, file paths, schema fields) and what did not.
- [ ] A final report at `ops/rebuild-2026-09/REPORT.md`: what was built, what was verified
      and how, what was deliberately left out, what is still uncertain, and the residue list.
- [ ] Telegram update to Florian (German, concise) when done.

---

## 10. Verify the brief itself

Before you start, and again before you declare done: **read §11, the verbatim original
request, and check that every single wish in it is covered** by this brief and by your
implementation. If you find something in the original that this structured brief lost or
softened, the original wins — implement it, and note the discrepancy in the final report.

If something in the original is genuinely ambiguous, make the call a careful colleague
would make, document the assumption, and keep going. Do not block waiting for an answer.
Florian's standing preference: act autonomously and report results, not decision points.

---

## 11. The original request, verbatim (German)

> Ich möchte unsere App um ein feature erweitern:
>
> Tken and caching efficiency adjusted adjusted costs. (per default aktiviert)
>
> Die Idee ist folgende: Die App berücksichtigt ja bereits die unterschiedlichen Tokenkosten und zwar unter der Annahme eines bestimmten Mischpreises von Input/Output Tokens.
> Aber was die App noch nicht berücksichtigt sind drei Dinge
> 1. Das Verhältnis von Input zu Output Tokens, das wir aktuell annehmen ist vielleicht nicht realistisch, oder repräsentativ für das was typischerweise heutzutage passiert. Unser base case, den wir repräsentieren wollen ist typische agentic usage, wie sie üblicherweise für codeing agent tools wie claude code, codex und opencode anfällt. Versuche, aus den Statistiken von OpenRouter.ai irgendwie pro modell herauszubekommen, wie das tatsächliche Verhältnis von input- zu output tokens pro modell ist, und wenn das nicht möglich ist, schau in der api von chutes (siehe https://api.chutes.ai/openapi.json) was typische werte sind für LLMs und nehme diese als Grundlage für alle LLMs.
> 2. Nicht alle Modelle brauchen gleich viele Tokens um eine Aufgabe zu lösen. Es kann vorkommen, dass ein Modell ein vielfaches von Tokens braucht, um die gleiche Aufgabe zu lösen, wie ein anderes Modell. Dementsprechend ist das eine Modell natürlich eigentlich effektiv preiswerter als das andere Modell. Das können wir aus den Daten von ArtifialAnalysis ableiten (wir haben einen api key und die seite kann man auch scrapen). Hier ist ein beispielshaftes diagramm, das uns diese info gibt: https://artificialanalysis.ai/?intelligence-efficiency=output-tokens-per-task#intelligence-efficiency-tabs (und anbei als bild). Lass uns versuchen, diese Werte für jedes Modell bei der Datensammlung und beim Datenupdate zu sammeln, damit wir entsprechend den effective price besser ausrechnen können
> 3. Caching Efficiency - da gecachte input tokens billiger sind als ungecachte ist es wichtig zu wissen, wie viel gecachte tokens man zu erwarten hat. Und da das eine Statistik ist, die von Provider (Inference Provider) zu Provider unterschiedlich ist (je nachdem wie effizient die Provider im Caching sind), müssen wir diese Statistik pro Modell & Provider Paar speichern. Wir können sie von hier scrapen: https://openrouter.ai/moonshotai/kimi-k3#pricing. Du musst herausbekommen, sowohl für diese Info als auch für die Info die wir bei 2. und 1. brauchen, wie man diese Infos am effizientesten erlangen kann und dann skills ablegen (überall: hier, am Sandy Hetzner, für alle Agents, also claude code, codex, opencode, auf user ebene), damit wir in zukunft das sehr effizient machen können und auch nicht so viele tokens dafür brauchen und auch evtl günstigere Modelle für die gleiche Aufgabe (die täglichen Datenupdates) verwenden können.
>
> Meine Idee ist, dass wir all diese Daten sammeln und mit in unseren Datenbestand der Model Market Comparison App einbauen und dann auch bei jedem der regelmäßigen Datenupdates aktualisieren.
>
> Und ich will diese Daten in der App dann so berücksichtigen, dass wir also per default die dementsprechend adjusted prices anzeigen, denn nur so kann der Benutzer wirklich gut verstehen, welches Modell wirklich das günstigste für eine bestimmte Leistungsschwelle (minim benchmark result) ist.
>
> Gib die komplette aufgabe dieses Umbaus an Codex mit GPT-6 Astra xHigh weiter, welches am Sandy Hetzner an dieser Aufgabe arbeiten soll, samt re-test und deploy am Ende. Codex mit GPT-6 Astra xHigh darf dann wiederum einen Teil der weniger komplexen aber tokenintensiven Arbeit weitergeben an opencode mit nex-agi/nex-n2.5-pro:free via OpenRouter (aktuell komplett kostenlos) oder an DeepSeek V4.1 Flash via OpenRouter (sehr billig) oder an Kimi K3 via Chutes (für uns kostenlos), damit wir auch hier Kosten bzw Tokenbudget sparen. Aber GPT-6 Astra soll der Qualitätssicherer bleiben. Und dann Update an mich via /notify-telegram . Claude Code ist hinsichtlich weekly limit fast am Ende, daher möchte ich gerne, dass die Aufgabe so komplett wie möglich an Codex weitergegeben wird.
>
> Außerdem baue in die App noch Radar Charts ein, beispielsweise bei /compare, aber auch als eigenen Tab - wo man bis zu 4 Modelle auswählen kann, die dann in so radar charts angezeigt werden sollen. Die verschiedenen Dimensionen des Radars sind die verschiedenen Benchmarks, die wir sammeln (also z.b. die ArtifialAnalysis Benchmarks und die Design Arena Benchmarks).
>
> Eine weitere Aufgabe ist: Sammle in meinem Twitter Account weitere benchmarks, über die bereits in der Anwendung berücksichtigten. Du kannst mal einfach anfangen mit einer Suche via https://x.com/search?q=benchmark&src=typed_query. Im Chrome Browser mit meinem Google Account ist x.com mit meinem Account airesearch12 eingeloggt, da solltest du einige gute benchmarks finden, die wir auch noch mit einbauen können in die Datensammlung. Mein Anspruch ist, dass wir in unserer App am Ende die vollständigste Benchmark Sammlung des AI Twitter Universums haben. Wir können gerne den Composite Benchmark erst mal so zusammengesetzt lassen wie bisher, denn die bisherigen Quellen sind solche die sehr zuverlässig verfügbar sind, aber es wäre super wichtig, dass wir auch weitere Benchmarks einbauen. Es gibt sehr viele Community Benchmarks auf Twitter. Es funktioniert vermutlich auch gut, wenn du grok über die pberfläche des browsers verwendest (https://x.com/i/grok) und ein Prompt wie dieses absetzt:
> <prompt>
> List a lot of LLM evals that show up in X/Discord/HF feeds when a new model drops. Include official launch-card benchmarks and especially indie/personal ones: EQ-Bench-style suites, SimpleBench, UGI, Fiction.liveBench, WeirdML, Vending-Bench, self-run Aider/OTIS harnesses, writing/slop/RP boards, long-context homebrew, uncensored willingness boards. Group by mainstream vs maintainer-owned. Note how each is scored and who runs it.
> </prompt>
> Du kannst auch gerne weitere prompts absetzen oder mit subagents in die tiefe recherchieren um zu verstehen welche dieser benchmarks wir lieber exkludieren, oder was veraltete weil saturierte benchmarks sind, oder welche version der benchmarks jeweils die neueste ist.
> Wir sollten hier gerne exzessiv vorgehen. recherchiere online wie die gauntlet loop prompting technik funktioniert. Ich will, dass wir sie verwenden, um sicherzustellen, dass wir so viele und so vollständige und so korrekte Daten (gerade auch beim Thema der Benchmark-Listen und ihrer Scores, aber eigentlich hinsichtlich aller aspekte, also auch der anderen daten, der oberfläche, des designs etc) wie möglich verwenden, um unsere Model Market Comparison app zur absolut besten übersicht über alle Model-Daten, Provider-Daten, Preis-Daten und Benchmark-Daten zu machen, die es auf der Welt gibt.
>
> Und natürlcih auch wichtig: all das muss täglich aktualisiert werden können, und hierfür verwenden wir auf dem Sandy Hetzner cron jobs die wir ebenfalls mit Gauntlet Loops zweks kritik und korrketheit starten und damit das nicht so teuer wird, lass uns stetig recherchieren welche Modelle auf OpenRouter gerade kostenlos sind (aktuell zum Beispiel ist es nex-agi/nex-n2.5-pro:free, und auch andere, z.b. inclusionai/ling-3.0-flash-vl:free - aber wichtig ist: lass uns keine Modelle verwenden die extrem schwach sind, z.b. keine unter Artificial Analysis Intelligence Index Ergebnis 34, denn sonst ist das Risiko zu groß, dass wir katastrophale falsche Daten erhalten).
>
> Manche Benchmarks kann man eventuell nur über Twitter finden, indem man die Tweets der entsprechenden User findet, die diese Ergebnisse immer wieder veröffentlichen, andere findet man vielleicht auf bestimmten Webseiten. Fidne das für alle Benchmarks heraus und notieres es auch für die Zukunft. Recherchiere und notiere auch eine kurze Zusammenfassung für jeden Benchmark/Eval, also nur 1 kurzer Satz auf englisch, damit wir in der App anzeigen können, wofür welcher Benchmark steht. Kategorisiere die Benchmarks auch nach Themen, z.b. Coding, Math, Knowledge, Writing, etc.
>
> Unsere App soll dann auch mehrere neue Sektionen über Benchmarkergebnisse erhalten: Zum Beispiel für jedes Modell die vollständige Liste der Benchmark Scores und auch vergleichsmöglichkeiten zwischen modellen und auch sektionen in der oberfläche, die andersrum vorgehen, also wo die benchmarks gelistet sind und man von dort aus eine liste der modelle auswerten kann und sie auflisten kann.
>
> Wir müssen allgemein sehr elegant damit umgehen lernen, wenn benchmark scores für manche modelle vorhanden sind und für andere modelle nicht. auch mit Versionen von benchmarks müssen wir entsprechend vorsichtig umgehen: Terminal Bench 4.0 scores sind natürlich nicht mit Terminal Bench 3.0 Scores zu vermengen etc.
>
> Überhaupt sollte die App grundsätzlich revampt werden und nach absolut perfekten Maßstäben für gute Bedienbarkeit und gute Benutzeroberfläche optimiert werden.
>
> Ich möchte auch, dass in irgendeiner Ansicht der App Auffälligkeiten bei benchmarks markiert und hervorhebt, z.b. wenn ein Modell auffällig gut abschneidet in einem bestimmten benchmark oder wenn sie besonders schlecht abschneidet. Und auch wenn ein benchmarkergebniswert ein ausreißer ist, also bespielsweise: sehr gut in bestimmten Benchmarks, aber dann sehr schlecht in einem anderen. Da soll es für jedes Modell die möglichkeit geben derartige Auffälligkeiten auf einen Blick zu erkennen.
>
> Ich habe gerade bei namecheap.com die domain benchmarkheaven.com gekauft. Lass uns die App so rebranden und dort veröffentlichen (hosting immernoch technisch gesehen über unseren Sandy PaaS, aber die Domain soll die App anzeigen). Auch gutes Branding entwickeln für diesen neuen Produktnamen.
>
> Außerdem sollten wir sef-reported benchmark scores ermitteln und auch abspeichern, aber auch als solche markieren. Wir können hierzu die ganzen Modell-Release Twitter posts der jeweiligen Modellhersteller anschauen, und eventuell finden sich die scores auch in den huggingface model pages der den tech reports. subagents unserer daten update agentensysteme (wie oben beschrieben: idealerweise kostenlose modelle) sollen dann diese initial reporteten daten finden und sammeln und ein gauntlet loop kritiker agent soll dann die korrektheit der erfassten zahlen prüfen. und wenn später die offiziell gemessenen daten von einer anderen quelle (z.b. von ArtificialAnalsysis) von diesen self reported scores abweichen, dann sollten wir das irgendwo in der app flaggen: das sind interessante einblicke.
>
> Ich weiß, das ist jetzt eine große, umfangreiche liste von änderungswünschen, aber mir ist wichtig, dass alles davon vollständig und perfekt umgesetzt wird, gib daher den auftrag vollständig an Codex GPT-6 Astra am Standy Hetzner weiter, etwas besser strukturiert, aber auch zusätzlich mit dem original-prompttext von mir hier, und dem auftrag nachzuprüfen, ob alles vollständig ist.
>
> Am Ende will ich ein Update an mein /notify-telegram und auch ein /explainer-video über das Endergebnis.

**Follow-up message from Florian (2026-09-10), binding:**

> eine Anmerkung noch: damit es für mein wichtiges airesearch12 Twitter Konto ein geringeres
> Risiko gibt, dass mich X als bot identifiziert und sperrt, verwende für die Grok und
> Twitter suchen lieber den xplainervideo X account, der ist ebenfalls am Hetzner Sandy am
> Haupt Chrome eingeloggt

→ Use **xplainervideo** for every X/Grok interaction. Do not use airesearch12.

The explainer video at the end is produced by the Claude session on Florian's machine
(the `explainer-video` skill lives there, with ElevenLabs narration). Your part is to make
sure the final report contains everything that video needs: what changed, what it looks
like, and the numbers worth showing.

FILE docs/benchmark-explorer.md
# Benchmark explorer

`/benchmarks` ranks one benchmark version and published evaluation group. `/compare` and `/radar` share a selection of up to four exact model configurations and a full native-score comparison. Model pages provide every attached observation grouped by category, missing coverage, profile signals, and verified vendor/measured divergences.

The benchmark views include the entire catalog. Price/provider settings apply to price views and model offers, not to which benchmark evidence is visible. The expandable two-model price comparison on `/compare` has a separate, explicitly labelled selection. Its legacy price projection is fetched from `/api/price-comparison` only when the disclosure is opened, so it does not inflate the benchmark page’s first response. A selected-model URL uses repeated `model` parameters; benchmark links use the exact `benchmark` registry identity.

Each registry version is distinct. Harnesses and source-record configuration/split fields create separate evaluation groups, including LongBench CoT and MMMU validation/test. Model-specific prompts, effort, dates and other protocol details remain in the original observation; grouping a published board is not a claim of identical test conditions. Native scores and exact observation IDs remain accessible through Evidence. Source publication dates and capture dates are different fields; missing publication dates are not invented. Vendor protocols are separate from independent measurement unless phase 05 explicitly audited a compatible divergence pair.

Existing AA Coding/Intelligence and DesignArena Frontend/Full-Stack scores are four additive snapshot axes. Their source capture date is the identity because the captured catalog does not establish semantic versions. They do not become newly registered source benchmarks. Coding Agent v1.4 retains its September 9, 2026 source and its median-over-complete-harnesses Composite input. Current v1.5 is exposed separately. Composite arithmetic and all five inputs are unchanged.

## Radar normalization

The radar uses only measured observations (including source-defined derivations from measured values), exactly matched to catalog configurations. Prefer the latest measured observation for each model in the chosen version/group; never select the highest score. Duplicate source identities count once in the peer range. DesignArena results with fewer than 200 battles are shown in native tables but excluded from the radar and peer statistics.

For each axis, normalized value = `100 × (value − catalog_min) / (catalog_max − catalog_min)`. For lower-is-better metrics subtract that value from 100. The current measured catalog sets the range, independently of the user's model selection. The table exposes exact native values and range, peer count, and normalized values rounded to three decimal places. Fewer than two peers, a constant range, unknown direction, low battle count, or a missing score prevents plotting. A measured minimum is a real zero. No missing value becomes a zero, and lines are only drawn between adjacent observed spokes, without filling across gaps. At least three and at most eight axes keep the diagram readable. Distinct dashes, labelled series, and a numeric table complement color.

## Explainable profile signals

These are conservative descriptive heuristics, not significance tests. Source standard errors/trial counts are not consistently available; benchmarks are correlated and selection-biased. Do not interpret a flag as proof of a bad measurement or a model capability guarantee.

- Each eligible axis needs at least 20 independent measured source configurations spanning 10 catalog model families and a nonzero population standard deviation.
- Convert its value to a peer z-score: `(value − peer_mean) / population_sd`, reversing sign when lower is better.
- For the selected model, average eligible z-scores within each benchmark family so multiple versions/harnesses cannot overweight that family.
- Exclude the candidate axis's entire benchmark family. At least five other eligible benchmark families are required. Their equally weighted mean z-score is the model's baseline.
- Flag only if `abs(peer_z) >= 1.5` AND `abs(peer_z − baseline) >= 1.5`, with the peer z and the gap pointing in the same direction. Show unusually strong/weak, original value, units, mean, standard deviation, peer/family counts, directed z, baseline, gap and profile size.

Phase-05 divergences are displayed separately using their actual `self_reported_value`, `measured_value`, `delta`, `relative_percent`, source URLs/dates and protocol. An empty list means no verified compatible pair; it does not mean claims agree with measurements. No live divergence was synthesized for this phase.

## Payloads and verification

`GET /api/benchmark-view?model=<exact-id>&model=<exact-id>` is a compact presentation projection, limited to four requested models; `?axis=<axis-id>` returns one evaluation group's observations. Metadata retains the fixed catalog peer statistics. It is not a replacement for the canonical `/api/benchmark-scores` or `/api/benchmarks` contracts. `/api/benchmark-scores?observation_id=<id>` adds exact observation lookup without changing existing queries. Dataset paths and canonical fields remain unchanged.

Benchmark pages are prerendered for the bundled deployment. Follow-up selection requests are cancellable, loading/error states are explicit, and a failed request can be retried. Themes are applied before paint and persisted when storage is available. Keyboard controls, visible focus, a skip link, reduced motion and scrollable data-table regions are included.

Run the browser receipt script against `npm run build` + `PORT=3316 npm start`:

```
BH_PLAYWRIGHT_PATH=<path-to-playwright-package> BH_AXE_PATH=<path-to-axe.min.js> node scripts/check-benchmark-ui.mjs
```

Optional `BH_UI_URL`, `BH_UI_OUT`, `BH_CHROME` choose the deployed origin, evidence directory and Chrome binary. `scripts/check-benchmark-legacy-ui.mjs` checks the remaining routes in desktop light/dark and mobile light themes, including navigation and native provider selection. These test tools do not enter the application's runtime bundle. The script retains PNGs, keyboard assertions, accessible-tree snapshots, axe results, runtime errors and local unthrottled timing/layout receipts. Automated checks complement manual and different-family screenshot criticism; they are not a full accessibility conformance certification.

FILE API.md
# Public API

All endpoints are **read-only**, return JSON, and are **CORS-enabled** (`Access-Control-Allow-Origin: *`), so they can be called from any site or tool — including directly from a browser.

Base URL (reference deployment): `https://model-market-comparison.app.mintapis.com`

The data is served from Postgres when `DATABASE_URL` is configured, otherwise from the committed `data/dataset.json` snapshot — the API shape is identical either way.

## Endpoints

### `GET /api/benchmarks`

All exact versioned registry entries, source/metric definitions, collection status and
per-benchmark coverage. No family-only version aliases are accepted.

### `GET /api/benchmark-scores`

Filters: `benchmark_id`, `model_id`, `basis` (`measured`, `self_reported`, `derived`),
`offset` (default 0), `limit` (default 100, maximum 500). Returns observations, total,
stored divergences, coverage and collection status. Both identity filters also return
the sparse cell status. Unknown exact versions/models return 404; bad parameters 400.
Derived observations include `source_basis` and formula/inputs. Every score includes
its source URL, dates, immutable hash and locator. Unmatched source subjects have null
catalog model IDs and remain queryable by benchmark.

The full dataset now includes `benchmark_results` with the registry, observations,
missing cells, collection attempts, rejections, divergences and coverage. Model detail
also returns `benchmark_observations`, `benchmark_divergences`, `benchmark_coverage`.
See [ingestion and missing-value contract](docs/benchmark-ingestion.md). Composite
scores and their five existing slots retain their previous API behavior.

### `GET /api/dataset`
The **full dataset** in one response — the canonical machine-readable feed: every model (with benchmarks, scores, all provider offers), the provider directory, source collection dates and counts. Cached 5 min (`Cache-Control: public, max-age=300`).

```jsonc
{
  "generated_at": "2026-07-12T…",
  "counts": { "models": 758, "families": 600, "providers": 85, "offers": 2368 },
  "sources": { "artificialanalysis": "2026-07-12", "openrouter": "2026-07-12", … },
  "models": [ { "id": "glm-5.2::max", "family_key": "glm-5.2", "family_name": "GLM 5.2",
    "org": "Z.ai", "variant": "max", "open_weights": true, "featured": true,
    "benchmarks": { "aa_coding_index": 68.8, "aa_coding_agent_index": 57.9,
      "aa_intelligence_index": 51.1, "aa_livecodebench": …, "aa_scicode": … },
    "designarena": { "frontend": { "elo": 1276, "battles": 4923 },
      "fullstack": { "elo": 1296, "battles": 1848 } },
    "offers": [ { "source": "Inceptron", "provider": "Inceptron", "platform": "Inceptron",
      "input_per_1m": 0.95, "output_per_1m": 3.04, "region": "eu", "unit": "per_1m_token",
      "eu_hosted": true, "non_us": true, "tee": false } ],
    "copilot": null } ],
  "providers": [ { "platform": "Nebius", "provider": "Nebius", "model_count": 25,
    "eu_hosted": true, "non_us": true, "country": "Netherlands" } ]
}
```

### `GET /api/models`
List of models with a single chosen score, the cheapest 10:1-blended cost, and the top-5 cheapest providers per model.
Every row also includes `composite_base` (the pre-projection mean-imputed value) and
`composite_coverage` from 0 to 5 so clients can distinguish the neutral Composite fallback
50 at 0/5 from a measured score.

Query params:
- `score` — one of `composite` | `aa_coding_index` | `aa_coding_agent` | `aa_intelligence_index` | `designarena_frontend` | `designarena_fullstack` (default `aa_coding_index`).
- `featured=1` — only the curated featured set.
- `hasBenchmark=1` — only models with source benchmark evidence. This excludes
  zero-evidence rows even though their `composite` fallback is the neutral 50.

### `GET /api/models/{id}`
One model by `id` (e.g. `glm-5.2::max`) or by `family_key` (e.g. `glm-5.2`): full benchmarks, all token offers, sibling reasoning variants, and the top-5 cheapest providers.

### `GET /api/providers`
The provider/platform directory with per-provider model counts and the `eu_hosted` / `non_us` / `country` flags.

### `GET /api/meta`
Dataset `generated_at`, `counts`, per-source collection dates, and whether the data is served from `postgres` or the bundled snapshot.

### `GET /api/health`
`{ "ok": true, "db": true|false }` — liveness + whether a database is wired.

## Pricing / score conventions
- Token prices are **USD per 1M tokens**, input and output separately. EUR-native snapshots retain the original EUR fields and store the audited ECB conversion rate/date used for USD normalization. An active catalog row may have `null` prices when the provider publishes no per-model rate. Context tiers, OpenRouter endpoint tiers, and managed routes such as Azure Direct versus Fireworks remain separate offers. Current GitHub Copilot usage is token-metered and converted to AI Credits at $0.01/credit; its `current` rates stay on the separate Copilot product axis. `multiplier` / `usd_per_request` apply only to eligible legacy annual Pro/Pro+ request billing.
- **10:1 blended cost** = `(10·input + 1·output) / 11`.
- Score scales: `composite` and the AA indices are 0–100; raw DesignArena score keys return Elo (~1000–1400). The **Coding Agent Index** is the median across all published harnesses for the exact model/reasoning-effort variant (Claude Code / Codex / Cursor CLI / …); every harness result is retained and results are never copied to sibling variants. This existing field retains the dated **v1.4** snapshot. AA's current **v1.5** has different benchmark components and is collected separately at `data/raw/aa-coding-agents-v1.5.json`; it does not replace the Composite input.
- `composite` uses five slots: AA Coding, source-matched AA Coding Agent, AA Intelligence, DesignArena Frontend and DesignArena Full-Stack. AA values are clamped to 0–100. Each DesignArena board needs at least 200 battles and is converted from Elo to its expected score against a fixed Elo 1000 opponent: `100 / (1 + 10^((1000 − Elo) / 400))`. Each observed slot is percentile-normalized over the current catalog's unique observed values. Every missing slot is assigned that model's mean observed percentile, making `composite_base` exactly the arithmetic mean of its available percentiles. With no reliable observed slot the fallback is 50; this fallback is not treated as benchmark evidence for family-representative selection. The returned `composite` adds a deterministic least-squares projection: if a model covers all reliable slots of another measured model and is no worse in each, the final scores preserve that dominance with a 0.1-point margin. `composite_base` exposes the pre-projection value. Family-scoped Intelligence.ai results attach exactly once to the deterministic collapsed-view representative and are labeled with `designarena_attachment_note`.
- Offer-level `eu_hosted` says that this specific model offer is served from an audited EU location. `eu_policy_equivalent` is a separate company-specific classification that makes an offer eligible for the product&apos;s EU filter without asserting technical EU residency; it is currently set only on Azure Direct Global DeepSeek V4 Pro and Kimi K2.7 Code, whose inference may occur outside the EU. Provider-level `eu_hosted` only says the provider has at least some EU-hosted capacity; it must not be used by itself to infer residency for every offer.

## Consumer update — 2026-09-08

The canonical host is `https://model-market-comparison.app.mintapis.com`;
the former Render host is suspended. All route paths remain unchanged.
The reference deployment serves **bundled JSON**, with no runtime database.
No database migration or credentials are needed to consume the public feed.

Prefer `GET /api/dataset` or the Git-tracked `data/dataset.json` for ingestion.
Use `GET /api/models?score=composite` for computed scores (Composite is computed
by app code, not stored as a scalar in the raw dataset). Check **each** date in
`sources`; `generated_at` only proves that a build ran, not that every source refreshed.
The daily job refreshes AA, AA Coding Agents, OpenRouter and DesignArena; curated
provider snapshots have separate audit dates. Do not assume every source refreshes daily.

Additive fields under each AA-backed model's `aa_metadata`:
`available` (boolean), `is_open_weights` and `deprecated` (boolean or null).
During a small upstream publication lag, benchmark rows are retained with null
metadata. Existing top-level booleans remain compatible: `open_weights:false`
means open weights are not established, and `deprecated:false` means not known
retired. Inspect the nullable fields to distinguish unknown from confirmed false.
Do not infer an open license from a lab name.

Exact model IDs and effort variants remain distinct. In particular, scores for
`qwen3.8-max` must not be copied to `qwen3.8-max-0902`, whose current evidence
is pricing only. Nullable direct Azure Astra prices are not zero; OpenRouter's
Azure offers are separate priced routes.

See [CHANGELOG.md](CHANGELOG.md) and [September audit](data/research/refresh-2026-09-08.md).

### Phase 01 additions (2026-09-10)

Existing URLs, file paths and score meanings remain unchanged. `sources.aa_coding_agents`
is the actual last collection date of the retained v1.4 snapshot, not today's date.
`sources.aa_coding_agents_v1_5` tracks the newly collected version. `source_status`
explains this separation. The v1.5 raw rows carry exact source IDs, components and
provenance; they will enter versioned benchmark views in phases 04–06.

`models[].aa_metadata.retained_fields` records `source`, `collected_at` and `reason`
for each metadata field retained from an older AA publication after the current
leaderboard stopped providing it. A snapshot refresh does not advance those field dates.

### Phase 02 additions — token and caching evidence (2026-09-10)

**All existing URLs, files, fields, prices and Composite inputs retain their meanings.**
Read the additions from `GET /api/dataset` or `data/dataset.json`. The full model
returned by `/api/models/{id}` includes `token_efficiency`; the compact `/api/models`
listing keeps its existing shape. Adjusted-cost computation/UI is a later phase.

An observation has `{ value, source, url, collected_at, basis }`. `value` can be a
number or the documented token-count object. `basis` is `measured` (AA benchmarks
or OpenRouter workload telemetry), `self_reported` (Chutes' own counters or catalog
prices), `derived` (explicit arithmetic), or `assumed` (applying a global workload
ratio to a different model). `source_basis` records the input classification for
derived/assumed values. Missing observations are **null**, never zero.

| JSON path | Meaning |
|---|---|
| `models[].token_efficiency.aa.tokens_per_task.value` | AA `intelligenceIndexOutputTokensPerTask`: `{ reasoning, answer, output }`, output tokens per Intelligence Index task for the exact AA UUID/effort. |
| `models[].token_efficiency.aa.canonical_token_counts.value` | AA `canonicalIntelligenceIndexTokenCount`: `{ input, output, answer, reasoning }`, totals over its canonical benchmark run. |
| `models[].token_efficiency.aa.benchmark_input_output_ratio` | Canonical input/output quotient, explicitly `interpretation: benchmark_proxy`. It is not observed user usage and is not the workload fallback. |
| `models[].token_efficiency.input_output_ratio` | Preferred empirical OpenRouter workload ratio, otherwise the Chutes global fallback. Includes `fallback`, `scope`, `window`, and a `fallback_reason`/`evidence_ref` when assumed. |
| `models[].token_efficiency.attempts` | Source attempts/outcomes, including missing API usage fields, exact-ID gaps, uncollected pages, incomplete windows and fallback evidence. Null attempt dates mean no fetch occurred. |
| `efficiency.global_io_ratio` | Chutes ratio plus source totals, seven completed UTC dates, cohort selection and returned/included/excluded-row coverage. |
| `efficiency.openrouter_endpoints[or_model_id][endpoint_tag]` | Exact pair registry: provider name, endpoint UUID when verified, cache-hit observation and cache read/write price observations. |
| `efficiency.aa_unmatched.value` | Collected AA rows whose UUID is not yet in the model catalog. Kept with provenance; never attached to a similarly named model. |
| `efficiency.coverage` | Explicit model/pair denominators and coverage counts. `schema_version` is 1. |

Workload selection uses exact published OpenRouter IDs or an unambiguous sole
offered SKU. Model pages provide `appStats.state.data.model_chart`; weekly rankings
extend coverage through an **exact canonical-slug join**, with `:free` kept separate.
Both use `sum(total_prompt_tokens) / sum(total_completion_tokens)`. The seven-day
page window excludes today; incomplete windows remain unavailable. These statistics
cover all apps/effort configurations on that SKU, not an isolated coding-agent cohort.
No family-name join or AA benchmark ratio substitutes for workload observations.

The Chutes ratio uses token-positive chute/day rows from `/invocations/stats/llm`
over the previous seven completed UTC days, including published anonymized aggregates.
It sums input and output independently, rather than averaging ratios. Raw counters
are self-reported; the global quotient is derived; its assignment to another model
is assumed. This is general Chutes traffic, not a coding-agent-only sample.

An endpoint entry's `cache_hit_rate.value` is a fraction from 0 to 1, taken from
OpenRouter `providerSummaries[].cacheHitRate`. The source `endpointId` is joined to
the model page's endpoint `id`, then to its exact `provider_slug` routing tag. The
effective-pricing API's **base** `providerSlug` is not an endpoint tag. Display names
such as Fireworks, Fireworks US and Fireworks Fast cannot establish equivalence.
Duplicate tags or identity conflicts get null cache observations and an explicit
status. Missing statistics are sparse coverage, not a zero hit rate.

OpenRouter does not publish the underlying cache-rate numerator/denominator or
the exact summary interval in this response. `summary_window` is null;
`chart_date_range` describes the accompanying chart only. Do not assume it defines
the summary interval. Cache read/write observations use **USD per million tokens**,
converted from the dated public endpoint catalog. Existing offer prices remain
unchanged; page-scraped price observations also remain in the raw snapshot.

New sources: `aa_efficiency`, `openrouter_efficiency`, `chutes_efficiency`.
The OpenRouter source date is the collector run, **not** a claim that every page
was refreshed. Individual dates survive rotation and failed fetches. Workload
observations older than 30 days fall back to Chutes; retained cache observations
and a stale Chutes fallback expose `stale: true` after 30 days. Consumers should
inspect observation dates/status, not just `generated_at`.

```js
const ds = await (await fetch('/api/dataset')).json();
const model = ds.models.find(m => m.id === selectedModelId);
const io = model.token_efficiency.input_output_ratio;
const offer = model.offers.find(o => o.or_model_id && o.endpoint_tag);
const cache = offer && ds.efficiency.openrouter_endpoints[offer.or_model_id]?.[offer.endpoint_tag];
// io.value = input tokens per output token; io.fallback says whether it is assumed.
// cache?.cache_hit_rate?.value is null/absent when unknown, with status explaining why.
```

Raw files: `data/raw/aa-efficiency.json`, `openrouter-efficiency.json`,
`chutes-efficiency.json`. Run `npm run data:efficiency` for independent refreshes.
`fetch-live.mjs aa` also refreshes AA efficiency; `fetch-live.mjs or` refreshes the
weekly ranking, four model pages in rotation and the Chutes fallback. The three
recipes are under `ops/rebuild-2026-09/skills/` for phase-09 installation.

Production continues to use bundled JSON. Optional Postgres installations should
run `node scripts/seed-db.mjs`: its idempotent `dataset_meta.extensions` JSONB
addition preserves the new top-level fields (and existing source-status metadata).
An old seed falls back to the bundled snapshot until reseeded.

### Effective-cost UI (phase 03)

The UI now defaults to modeled **USD/task**. Raw API `input_per_1m`, `output_per_1m` and cache fields retain their existing USD/million units and paths; no raw field was renamed or silently converted. Consumers can import the pure `effectiveCost` / `fixedCost` functions from `lib/effective-cost.mjs`. `effective_cost_per_task` and `effective_cost_per_1m_tokens` are separate return fields, with resolved inputs, dollar terms and explicit assumptions. See [effective-cost policy](docs/effective-cost.md) for all fallbacks and workload limitations. The UI settings key is now `mmc.settings.v6`; adjusted costs and the retained fixed-blend alternatives are global and persisted.

### Benchmark exploration (phase 06)

The canonical dataset/benchmark endpoints keep their existing fields. `GET /api/benchmark-scores` additionally accepts `observation_id` for exact row lookup, composable with `benchmark_id`, `model_id` and pagination.

`GET /api/benchmark-view?model=<id>` (repeat up to four) supplies a bounded UI projection with versioned axes, sources and fixed catalog peer statistics. `?axis=<id>` instead selects one published evaluation group including unmatched source identities. These presentation IDs include version, unit and harness/configuration and may change if source protocol metadata changes; use registry IDs and observation IDs from the canonical APIs for integrations. The view is additive and never changes Composite. See [explorer methodology](docs/benchmark-explorer.md).

FILE README.md
# Model Market Comparison

Compare **open-source and frontier LLMs** by capability and price in one place.
Capability comes from [ArtificialAnalysis](https://artificialanalysis.ai) (Coding,
Coding Agent & Intelligence indices) and [Intelligence.ai / DesignArena](https://intelligence.ai)
(Agentic Web Dev Frontend & Full-Stack Elo). Prices are aggregated across **OpenRouter**
inference providers, **AWS Bedrock**, **Azure AI Foundry**, **Google Vertex AI**,
**Nebius**, **Inceptron**, **TensorX**, **Scaleway**, **IONOS**, **Mistral**, **Chutes**,
**OVHcloud**, **STACKIT**, **T-Systems LLM Hub**,
**GitHub Copilot**, and the **Anthropic / Claude Code** list price — normalized to
USD per 1M tokens.

> 📋 Product spec: [PRD.md](PRD.md) · 🗂️ Data schema: [data/SCHEMA.md](data/SCHEMA.md) ·
> 🔄 Data collection & refresh: [data/SCRAPING.md](data/SCRAPING.md) ·
> 🔌 Public API: [API.md](API.md) · 🚀 Deploy / migrate / env vars: [DEPLOYMENT.md](DEPLOYMENT.md) · 📜 Data/URL changes for consumers: [CHANGELOG.md](CHANGELOG.md)


## Benchmark exploration

Explore [benchmark rankings](https://model-market-comparison.app.mintapis.com/benchmarks), compare up to four exact model configurations on [Compare](https://model-market-comparison.app.mintapis.com/compare), or use the standalone [Radar](https://model-market-comparison.app.mintapis.com/radar). Model pages include complete benchmark sheets, source links and dates, missing coverage, and explainable profile signals. Every comparison keeps benchmark versions separate. [Methodology and limitations](docs/benchmark-explorer.md).


## Features

- **Price & provider filters** (apply to price comparisons and model offers; benchmark exploration uses its own filters, persisted): selectable **score**,
  min-score, **One variant for Reasoning models** (collapse GPT/Claude/GLM/Kimi to one),
  **Featured**, **Hide deprecated** (on by default), **Exclude Chinese providers**, **EU-hosted / approved equivalent only**, **Non-US provider only**,
  **TEE / confidential only**, plus
  provider- and model-checklist filters.
- **Selectable scores**: **Composite** (five percentile slots with model-mean imputation plus a dominance-safe projection, 0–100, default), ArtificialAnalysis
  **Coding Index**, **Coding Agent Index** (median across published harnesses for the exact model/effort variant), **Intelligence Index**,
  and DesignArena **Frontend** / **Full-Stack** Elo.
- **Overview** — fully sortable table with per-column filters, **Has benchmark evidence**
  for Composite (or **Has score** for a direct metric) / **Has provider**
  toggles, and Excel-style **data bars** on score & cost.
- **Compare** — pick two models (A/B) head-to-head; scores & cheapest price shown big with
  the winner highlighted, plus each model's cheapest providers side by side.
- **Cost vs Capability** — scatter: **x = cost** (cheapest 10:1 blended $/1M, axis inverted
  so cheaper is right), **y = capability**, circle = closed / square = open, with a
  **Pareto frontier** line of best-value models.
- **Charts** — capability leaderboard, cheapest-model ranking, open vs closed comparisons.
- **Model detail** — top-5 cheapest providers and all offers by platform within the
  active global filter scope, full benchmark breakdown, reasoning-variant comparison,
  current GitHub Copilot token/AI-Credit prices and legacy per-request cost.
- **Providers per Model** — searchable model picker → that model's providers ranked by price.
- **Provider explorer** — pick one provider → every model it offers; click a model to compare
  that provider's price against all others (ranked, with its price-rank in the field).
- **Gateways** — 35+ LLM gateways/routers/aggregators compared on EU routing capability,
  self-host/local, open-source license, HQ and pricing.
- **EU & Sovereign** — which providers are EU-hosted/sovereign and which SOTA models they
  actually serve (incl. TEE/confidentiality notes + a separate dedicated/BYOC-only list).
  Interactive EU filtering requires evidence on the exact model offer; provider-level
  dedicated/BYOC capability alone never turns a global route into an EU-hosted one. The
  only policy exceptions are Azure Direct Global DeepSeek V4 Pro and Kimi K2.7 Code:
  they qualify as company-approved equivalents without being relabeled as technically EU-resident.
- **Public read-only JSON API** (CORS-enabled) — `/api/dataset` (full export),
  `/api/models`, `/api/models/[id]`, `/api/providers`, `/api/meta`, `/api/health`. See [API.md](API.md).

Featured models include **GPT-6 Astra**, **GLM-5.3 Flash**, **Qwen3.8 Max** (including the separately priced 0902 release), Muse Spark 1.3, and GPT-5.6 Sol/Terra/Luna, GPT-5.5 / GPT-5.4 (with Mini and
low/medium/high/xhigh settings), Claude Opus 4.8 / 4.7 / 4.6, Sonnet 4.6 / 5,
**Fable 5**, Kimi K2.5 / K2.6 /
K2.7-Coding, GLM 5.1 / 5.2, MiniMax M2.5 / M2.7 / M3, Xiaomi MiMo-V2.5-Pro and
DeepSeek V4 Pro.

## Stack

Next.js (App Router, TypeScript) · Recharts · PostgreSQL · live at [model-market-comparison.app.mintapis.com](https://model-market-comparison.app.mintapis.com) (Sandy/Coolify, snapshot mode).

The app reads from Postgres when `DATABASE_URL` is set (seeded from
`data/dataset.json`) and otherwise serves the committed snapshot, so it always
renders even without a database.

## Local development

```bash
npm install
npm run dev          # http://localhost:3000  (uses bundled data/dataset.json)
```

### Refresh the data

```bash
export ARTIFICIAL_ANALYSIS_API_KEY=aa_…    # for the AA fetch
npm run data:refresh                        # fetch live APIs + rebuild dataset.json
# with a database:
export DATABASE_URL=postgres://…
npm run db:seed
```

See [data/SCRAPING.md](data/SCRAPING.md) for per-source details (incl. how to update
the manually scraped AWS / Azure / Copilot / Claude snapshots).

## Deploy / migrate

Full guide incl. **required env vars / secrets**, Postgres setup, Docker and **Azure**
hosting: [DEPLOYMENT.md](DEPLOYMENT.md). In short — the only runtime secret is the
optional `DATABASE_URL` (the app falls back to the bundled `data/dataset.json` snapshot
without it); `ARTIFICIAL_ANALYSIS_API_KEY` is needed only to refresh data, not at runtime.
A [`render.yaml`](render.yaml) Blueprint and a [`Dockerfile`](Dockerfile) are included.

## Methodology & caveats

10:1 blended cost = `(10·input + 1·output) / 11` per 1M tokens. EU residency is
audited per offer/model/region; an EU-capable provider does not make its US or global
routes EU-hosted. Separately, `eu_policy_equivalent` admits only Azure Direct Global
DeepSeek V4 Pro and Kimi K2.7 Code to the EU filter under this company&apos;s legal/business
classification; inference may occur outside the EU and the flag is not a technical residency
guarantee. The Composite uses five capability slots: AA Coding,
source-matched AA Coding Agent, AA Intelligence, DesignArena Frontend and DesignArena
Full-Stack. AA values are clamped to 0–100. A DesignArena board qualifies with at least
200 battles (an app minimum aligned with the source&apos;s typical preliminary/reliability threshold) and its Elo is converted to the expected score against a fixed Elo 1000
opponent: `100 / (1 + 10^((1000 − Elo) / 400))`. Each observed slot is then converted
to its empirical percentile among the current catalog&apos;s unique observed values. Every
missing slot is assigned that model&apos;s mean percentile across its observed slots. The
base is therefore exactly the mean of its available percentiles, so missing slots cannot
move it. A deterministic least-squares projection then enforces shared-evidence dominance:
if one model covers every reliable slot of another measured model and is
no worse in any shared slot (strictly better in at least one), it remains at least 0.1 points
ahead. This is the smallest symmetric catalog-wide adjustment satisfying those constraints;
the base and adjustment are exposed separately in model details and the models API. A model
with no reliable observed slot receives the neutral fallback 50. Coverage
is tracked separately so this fallback is not mistaken for benchmark evidence when choosing
a family representative, applying **Has benchmark evidence**, or building capability charts and the
Pareto frontier. GitHub Copilot&apos;s
current token/AI-Credit rates and legacy annual-plan
request multipliers are kept separate from provider API offers.
Model identities are joined conservatively across sources; modes, releases, pricing tiers
and hosting routes remain separate unless a stable source id/repository proves equivalence.
When Intelligence.ai publishes only a bare product identity, that family-scoped result is
attached exactly once to the deterministic active representative used by collapsed views,
with an explicit provenance note that it does not identify the tested effort setting.
Figures may still change upstream —
**verify before relying on them**. Not affiliated with any provider.

FILE CHANGELOG.md
# Changelog

For downstream consumers (forks, apps syncing data from this repo or the live API):
the **data locations have not moved**. What changed recently is the hosting URL and
some app internals — details per release below.

## 2026-09-10 — Phase 04: benchmark discovery

- Added a versioned benchmark registry with verified publication routes, scoring semantics,
  provenance and an exclusion ledger, including public and independent writing/RP boards.
- Retained AA's previously discarded benchmark fields as raw observations with a fail-closed
  extractor. Coding Agent Index v1.4 and v1.5 remain separate; the legacy date is unchanged.
- Dataset builds validate registry evidence. Public API scores and Composite inputs are unchanged.

## 2026-09-10 — Phase 03: effective task costs

- Comparisons default to modeled USD/task, combining exact-variant task tokens, usage I/O and exact-endpoint cache statistics, with every fallback explained.
- Raw list prices and six fixed I/O scenarios remain selectable; settings move to `mmc.settings.v6`.
- The explorer starts at cheapest adjusted cost and measured task-token data; minimum benchmark scores make the cost/capability question directly filterable.
- Every selected price has a keyboard/touch explainer; charts and averages expose their constituent prices.
- Retired a Sol override that mixed first-party list rates with OpenRouter cached rates. Raw API units and data paths remain unchanged. See [cost policy and five-model checks](docs/effective-cost.md).

## Where to find the data (canonical, stable)

- **In the repo** (updated ~daily by an automated refresh commit to `main`):
  - `data/dataset.json` — the full built dataset (models, families, offers, scores, sources).
  - `data/raw/*.json` — per-source snapshots (ArtificialAnalysis, OpenRouter, DesignArena, per-provider catalogs, `manual.json` overrides).
  - `data/gateways.json` — gateway comparison data.
- **Live API** (same JSON shapes as the repo, CORS `*`; see [API.md](API.md)):
  - Base URL: **`https://model-market-comparison.app.mintapis.com`**
  - `GET /api/dataset` · `GET /api/models` · `GET /api/providers` · `GET /api/meta` · `GET /api/health`

## 2026-09-10 — rebuild phase 02

- Add `models[].token_efficiency` with dated AA output-tokens-per-task/canonical benchmark counts and workload I/O evidence. Exact OpenRouter usage takes priority; the Chutes global fallback is explicitly assumed. AA ratios remain benchmark proxies.
- Add `efficiency.openrouter_endpoints[or_model_id][endpoint_tag]` with provider names, exact endpoint identities, cache-hit statistics, dated cache read/write prices and sparse-coverage statuses. Base provider labels never join endpoint telemetry.
- Add explicit coverage, unmatched AA rows, provenance and failed/uncollected-attempt records. Preserve all historical metadata field dates, existing prices, score meanings, URLs and file locations.
- Add three atomic collectors, parser/identity/failure tests and reusable collection skills. Daily refresh gains AA efficiency, one weekly OpenRouter ranking plus four model pages in rotation, and seven completed days of Chutes aggregate usage.
- Optional Postgres seeding adds `dataset_meta.extensions` to retain additive metadata; production continues to serve bundled JSON. See [API.md](API.md#phase-02-additions--token-and-caching-evidence-2026-09-10) for the full schema. Adjusted costs and UI follow in subsequent phases.

## 2026-09-10 — rebuild phase 01

- Repair AA metadata parsing for slug-based Flight records and retain historical identifiers/licensing with their original per-field source dates. Refresh AA, OpenRouter and DesignArena; restore all 68 v1.4 Coding Agent rows.
- AA changed the Coding Agent benchmark to v1.5. Collect it into `data/raw/aa-coding-agents-v1.5.json` with strict validation and atomic writes. Preserve the existing Composite and v1.4 collection date; explain the separation in `/about` and `source_status`.
- Track daily runner/prompt in `ops/daily/`; use the tested collector and subscription-only Codex auth. No data URLs or existing score fields moved.

## 2026-09-08

- **New featured models:** GPT-6 Astra, GLM-5.3 Flash, Muse Spark 1.3, Qwen3.8 Max 0902
  (`FEATURED_RE` in `scripts/build-dataset.mjs`).
- Provider catalogs refreshed, including the previously unfinished AWS/Azure/Vertex,
  Claude direct, Copilot and T-Systems checks. AA / DesignArena / OpenRouter /
  Coding-Agent snapshots refreshed. See [audit details](data/research/refresh-2026-09-08.md).
- `scripts/fetch-live.mjs`: the ArtificialAnalysis fetch now tolerates up to 3 API models
  whose leaderboard metadata hasn't rolled out yet (ships them with null metadata instead
  of aborting the refresh). Empty/broken feeds and larger mismatches still fail.
  `aa_metadata.available`, `aa_metadata.is_open_weights` and `aa_metadata.deprecated`
  expose missing metadata; existing top-level booleans stay compatible.
- Cron was active at 05:17 UTC daily; today's failed fetch was the blocker. Its server
  prompt now builds before testing, so production prerender checks use current output.
- **Auto-deploy verified:** GitHub pushes now trigger Coolify via webhook; older
  documentation saying pushes do not deploy was stale. Explicit redeploy is a fallback.
- **No DB/schema migration**: production serves bundled JSON without `DATABASE_URL`.
  Routes and repo file paths are unchanged. Check individual `sources` dates, not
  just `generated_at`. The daily cron refreshes the four live benchmark/router sources;
  manual provider catalogs retain separate audit dates.
- Copilot: 29 current token entries / 19 legacy multiplier entries. Claude direct:
  13 callable models; Opus 4.1 retired, Fable/Mythos 5.1 cache pricing captured,
  cancelled Sonnet 5 price increase removed.
- Azure Astra is documented but direct prices remain null until a named Retail meter
  is published. OpenRouter Azure prices remain separate. Qwen3.8 Max 0902 has prices
  but no exact benchmark yet; no score copied from bare Qwen3.8 Max.

## 2026-08-26

- **Hosting/base URL changed:** the reference deployment moved from Render
  (`model-market-comparison.onrender.com`, suspended 2026-08-25) to
  **`https://model-market-comparison.app.mintapis.com`** (Sandy/Coolify). All API routes
  and JSON shapes are unchanged — only the host is new. See [DEPLOYMENT.md](DEPLOYMENT.md).
- **Filters removed:** the "Hide GPT-5.5 / Opus 4.8" and "Hide Fable" global toggles are
  gone; `isHiddenModel` no longer exists in `lib/cost.ts`. Persisted settings key bumped
  `mmc.settings.v4` → **`mmc.settings.v5`**.
- Deep catalog audit (AWS Bedrock EU-Geo Claude prices corrected, FX refresh, delistings);
  featured-set regex hardened with `(?!-)` lookaheads; `scripts/top5.mjs` added
  (top-5-by-Composite snapshot used by the daily refresh notifier).

## Earlier

The daily data-refresh commits ("Refresh …") only touch `data/` (and occasionally test
pins) and never change API routes or file locations. For app-level history before this
file existed, see `git log`.

## 2026-09-11 — Phase 06 benchmark explorer

- Added `/benchmarks` rankings, a standalone `/radar`, and up to four exact configurations on `/compare`, with source scales, versioned evaluation groups, selectable axes and explicit sparse coverage.
- Added complete per-model benchmark sheets, conservative explainable profile signals, and protocol-compatible divergence displays.
- Revamped navigation, light/dark themes, keyboard focus and disclosures; retained adjusted-cost and provider comparisons. Coding Agent v1.4 and its September 9 Composite source remain unchanged; v1.5 is separately visible.
- Added the compact benchmark presentation endpoint and exact observation lookup; canonical source/dataset fields and paths remain compatible. No benchmark value was changed or invented.

FILE ops/rebuild-2026-09/COVERAGE.md
# Original-request coverage — Benchmark Heaven

> Phase 01 audit: DeepSeek first draft, corrected and reviewed by Astra.
> Status convention: **Planned** = not yet completed. **Phase 1 verified** = the foundations documented in `REPORT.md`; later product work is still planned.
> “Completion evidence required” is an acceptance criterion, not an observation.
> Phase 1 execution and deployment evidence is in `REPORT.md`; future evidence requirements below are not completion claims.

Phase 1 foundations and phases 02–05 have release evidence in `REPORT.md`. Phase 06 verification is recorded below; its live release receipt is required before `DONE`. Later-phase obligations remain planned. This table only updates the wishes verified by the current phase; the report carries prior phase detail.

---

## Every wish in §11 and its binding follow-up

| ID | Original wish (abbreviated) | Phase(s) | Completion evidence required | Status |
|---|---|---|---|---|
| W1 | Token & caching-efficiency adjusted costs, **default ON** | 2, 3, 8 | `data/dataset.json` contains I/O ratio, tokens/task, cache-hit/cache-price fields with provenance; effective-cost formula per §2-A4 implemented with unit tests; UI default shows adjusted price with toggle; daily refresh updates the inputs; deploy verified | Planned |
| W2 | Realistic input:output ratio; base case = agentic coding (Claude Code/Codex/opencode); try OpenRouter per-model first, Chutes API otherwise | 2, 3 | Per-model ratio with explicit basis (OpenRouter observation, Chutes global fallback, or explicitly labelled AA benchmark proxy); OpenRouter attempt documented; Chutes fallback flagged; existing fixed blends remain selectable; UI explains which basis was used | Planned |
| W3 | Tokens-per-task verbosity from AA “Output Tokens per Intelligence Index Task”; collect per model during collection and updates | 2, 8 | AA `intelligenceIndexOutputTokensPerTask` captured for the maximum politely reachable model set; coverage caveat recorded; daily refresh re-collects; parser tests cover missing/malformed payloads | Planned |
| W4 | Caching efficiency per **model × provider**; cache-hit rate scraped from OpenRouter pricing pages; cache read/write prices stored | 2, 8 | Store keyed by `(or_model_id, provider/endpoint)` with `cache_hit_rate`, `cache_read_price`, `cache_write_price`, provenance; partial coverage designed; tests | Planned |
| W5 | All new data integrated into the Model Market Comparison dataset and refreshed on every regular update | 2, 8 | Schema/API/CHANGELOG updated; daily job refreshes these fields; end-to-end dry run output is shown in the phase report | Planned |
| W6 | Default UI shows adjusted prices; user can answer “cheapest model at min benchmark score” | 3, 6 | Adjusted price is default; toggle to raw list price exists; one-screen min-score filter with adjusted cost; per-row explainer of assumptions; five-model sanity check documented | Phase 3 price task retained and Phase 6 browser-verified; release pending |
| W7 | Complete rebuild task handed to Codex GPT-6 Astra xHigh on Sandy Hetzner, with re-test and deploy at end | 1, 9 | Phase statuses in `/opt/benchmarkheaven/state/`; final verification checklist in `REPORT.md`; live deploy on benchmarkheaven.com verified | Phase 1 verified; rest planned |
| W8 | Astra may delegate token-heavy work to free/cheap workers; Astra stays quality gate | 1, 8 | `bin/worker.sh` verified end-to-end against all three backends; `bin/pick-worker-models.mjs` returns AA-index-filtered list; daily job uses dynamic worker selection; critic rounds documented | Phase 1 verified; rest planned |
| W9 | Final update via `/notify-telegram` | 8, 9 | Telegram notification sent at completion; daily quiet policy implemented | Planned |
| W10 | Claude Code near weekly limit → task goes as completely as possible to Codex | 1, 9 | Execution logs show Codex drives all rebuild phases; Claude is only used for the explainer-video handoff; no main rebuild work assigned to Claude | Phase 1 verified; rest planned |
| W11 | Radar charts on `/compare` and as own tab; up to 4 models; axes = collected benchmarks (AA, DesignArena, registry) | 6 | Radar implemented and rendered in both places; axis selection; normalization method documented; missing axes handled honestly; keyboard accessible | Phase 6 implemented; four-model/axis/keyboard and rendered evidence verified; release pending |
| W12 | Collect further benchmarks from Twitter; start with `https://x.com/search?q=benchmark&src=typed_query`; use logged-in Chrome | 4, 9 | Registry entries from sweep; “where results appear” captured; logs show **xplainervideo**, never airesearch12 | Planned |
| W13 | Goal: most complete benchmark collection of the AI Twitter universe; exclusions documented | 4, 5, 8 | Broad registry populated; saturated/superseded and excluded benchmarks recorded with reasons; coverage visible in UI | Planned |
| W14 | Composite may stay as-is; current Composite sources are reliable; new benchmarks additive | 4, 5, 6 | Existing Composite definition unchanged; regression guard added; new benchmarks only in new views/columns, not in Composite | Phase 6 verified: unchanged Composite bytes/inputs, dated v1.4 and separate v1.5 |
| W15 | Use Grok in X UI with the specified prompt; run more prompts/subagents to prune, detect saturation, and check versions | 4 | Grok session records; excluded-benchmark list with reasons; version-currency notes | Planned |
| W16 | Research gauntlet-loop technique online; use it for data, UI, design, docs; aim for world-best overview | 1–9 | `ops/rebuild-2026-09/GAUNTLET.md`; critic rounds per phase; residue documented; bounded rounds per artifact | Phase 1 verified; rest planned |
| W17 | Daily updates via Sandy cron with gauntlet loops; continuously discover free OpenRouter models; never use models below AA Intelligence Index 34 | 8 | Daily job rebuilt and dry-run end-to-end; dynamic picker filters AA ≥ 34; worker/cost log; Telegram quiet policy | Planned |
| W18 | For every benchmark, record where results actually appear (Tweets, websites, HF, GitHub) | 4, 8 | Registry `how_to_collect` / `primary_url` fields populated; recipes executed by daily refresh | Planned |
| W19 | One-sentence English summary + category per benchmark | 4 | Registry `one_sentence_description` and `category` fields populated | Planned |
| W20 | New UI sections: per-model full score list, model-vs-model comparison, inverse per-benchmark view listing models | 6 | Pages/routes implemented; scores shown with version, source, date, self-reported flag, links; sparse coverage handled | Phase 6 implemented and browser-verified; release pending |
| W21 | Handle missing scores elegantly; never mix benchmark versions (Terminal-Bench 4.0 ≠ 3.0) | 4, 5, 6 | Sparse-data states distinguished; version identity enforced; version shown in UI; version-isolation tests | Phase 6 verified: version/group isolation, explicit missing states, no zero imputation |
| W22 | General app revamp to “absolutely perfect standards” | 6 | Usability/accessibility checklist; critic review against rendered output/screenshots; performance checks | Phase 6 checklist and rendered/keyboard/performance verification; critic/release acceptance in REPORT.md |
| W23 | Anomaly/outlier highlighting per model; explainable; guard against noise | 6 | Anomaly view implemented; method described (e.g. z-score vs own profile and peer distribution); small-sample guard | Phase 6 measured-peer/profile heuristics implemented and tested; release pending |
| W24 | Rebrand to Benchmark Heaven; domain benchmarkheaven.com; hosting stays on Sandy PaaS; real branding | 7, 9 | DNS A record; Coolify domain/TLS; old host still works; brand assets; metadata/README updated | Planned |
| W25 | Collect self-reported benchmark scores; mark them as such; critic verifies; flag divergence vs measured later | 5, 6 | `basis: self_reported` rows with source URL; critic verification log; divergence surfaced in UI | Phase 5 sources retained; Phase 6 claim flags and pair UI implemented; zero verified live pairs, no invented deltas |
| W26 | Pass structured brief + verbatim original prompt to Codex; re-verify completeness | 1, 9 | `COVERAGE.md` maintained; Phase 9 re-reads §11 line by line; discrepancies reported in `REPORT.md` | Phase 1 verified; rest planned |
| W27 | At the end: update via `/notify-telegram` **and** an `/explainer-video` about the end result | 9 + handoff to local Claude session | Telegram sent; explainer-video brief handed to Claude session; actual video delivery confirmed; a blocked handoff remains incomplete | Planned |
| W28 | Efficient collection recipes saved as user-level skills everywhere: local machine and Sandy, Claude Code, Codex and opencode | 2, 8, 9 | Token/I/O/cache collection skills written; installed in each of the six runtime/machine combinations; discovery and successful invocation receipts; repository copies alone do not count | Planned |
| F1 | Binding follow-up: use **xplainervideo** for all X/Grok interactions, **NOT airesearch12** | 4, 9 | Operational logs and final audit show only xplainervideo; no airesearch12 usage in any phase artifact | Planned |

---

## Corrections applied to the phase instructions

1. **I/O source priority (phase 02):** §11 explicitly asks for OpenRouter per-model empirical usage, then Chutes typical LLM usage. The structured brief promoted AA benchmark token ratios to the default. Restore the original priority. AA ratios remain useful cross-checks or clearly labelled benchmark proxies if actual usage is unavailable; never describe them as observed user workloads. The worker draft also put AA ahead of Chutes; owner corrected that error.
2. **Selectable blends (phase 03):** preserve existing fixed blends as alternative scenarios, in addition to the adjusted default and raw-price toggle.
3. **Provider identity (phase 02):** retain provider name along with model ID and endpoint tag; do not join unrelated endpoints just because their provider labels match.
4. **Composite/version protection (phases 04–06, 08):** the 2026-09-10 source moved Coding Agent Index from v1.4 to v1.5. Keep v1.4 dated and separate for the unchanged Composite. Collect v1.5 separately and ingest into versioned new views. No implicit score migration. Every radar axis, ranking and comparison displays its benchmark version.
5. **Skills on both machines (phase 09):** repository copies/handoff are intermediate artifacts. Completion requires installation and discovery evidence for Claude Code, Codex and opencode on Sandy AND Florian's machine. If a machine is unavailable, mark the installation incomplete with the specific blocker.
6. **Explainer video delivery (phase 09):** the master brief assigns production to Florian's local Claude session, while the original asks for a delivered video. Prepare an explicit video brief, deliver that handoff, and verify the video reaches Florian. A prepared brief alone is not completion. Record an outstanding blocker honestly rather than mark the entire rebuild complete.
7. **Unknown AA worker scores (phase 01/08):** the fixed known-answer smoke test verifies transport, not AA qualification, including the requested free and near-free backends. It has a price/token cap and accepts no custom task. Models with no AA score remain excluded from unattended data-bearing work. Known scores below 34 are excluded even from pinned and smoke paths.

All original wishes have phase owners. No new product features are claimed complete by this phase-01 mapping. Phase 09 must re-check every row against the actual deployed product and delivery receipts. The binding xplainervideo correction supersedes the original airesearch12 account reference everywhere, including vendor-release searches in phase 05.

FILE ops/rebuild-2026-09/REPORT.md
## Phase 06 — benchmark explorer, radar and explainable profile signals (2026-09-11)

Built `/benchmarks`, `/radar`, a new benchmark workspace on `/compare`, and the complete per-model benchmark sheet. Up to four exact model configurations share a radar and the full comparison table. Rankings expose benchmark version, evaluation group, evidence type, model/open-weight/unmatched filters and coverage denominators. Model sheets retain every attached observation grouped by category, source URL, original observation date, publication date when known, measured/self-reported/derived flag, exact ID and full protocol link. Missing, uncollected and contested evidence stays explicit. The 73 registered versions and four existing dated index snapshots remain distinct; Coding Agent v1.4 stays dated September 9 in Composite, with v1.5 separately navigable.

Radar axes use the fixed matched measured catalog minimum/maximum, reversing lower-is-better metrics. The native values and range are exact; normalized display values are rounded to three decimals. Users can select 3–8 versioned axes. Up to four labelled colors/dash patterns remain distinguishable, and adjacent spokes connect only when both measurements exist. Missing values, low-battle DesignArena rows, constant ranges, unknown direction and insufficient peers never become fabricated zeros. Numeric tables and keyboard-scrollable graphic regions complement the SVG. See [methodology](../../docs/benchmark-explorer.md).

Profile signals compare a directed peer z-score with a leave-one-benchmark-family-out baseline. Each eligible axis requires at least 20 measured source configurations across 10 catalog model families; a model needs five other eligible benchmark families. Both the absolute peer z and baseline gap must reach 1.5 in the same direction. Versions/harnesses cannot multiply a benchmark family's baseline weight. Why disclosures expose value, mean, population deviation, peer/family counts, z, baseline, gap and profile size. These are descriptive heuristics, not significance tests. Phase-05 compatible vendor/measured deltas render separately with both values and sources. **There are zero verified live pairs**; the empty state explicitly says agreement cannot be assessed.

The shared layout now has compact primary navigation, a More menu, a skip link, a persistent prepaint light/dark theme, visible focus, reduced motion and a collapsible price-filter bar with explicit scope. Existing adjusted-cost views remain available. Provider/model directory selections now have native keyboard buttons; scatter has equivalent model links in its accessible table. The independent legacy A/B price comparison loads on demand from `/api/price-comparison`. Default benchmark projection is **300,881 bytes**, rather than embedding the full price projection. `/api/benchmark-view` serves selection/group projections with fixed peer statistics; `/api/benchmark-scores` adds exact observation lookup. No source score, Composite input or daily collection path changed; the generated dataset differs only in `generated_at`.

Delegation: Kimi's agent attempt timed out without landed work; oversized GLM shell drafts exhausted their output allowance. A bounded GLM 5.3 Flash evidence-component draft and a DeepSeek V4 Flash CSS draft were usable starting points. Astra corrected schema assumptions, basis flags, exact source links, color-variable handling, native controls, payload size, SVG hydration and responsive containment, and reviewed all landed files. Ten completed producer/critic receipts before documentation review report **$0.425570** in returned charges, including superseded review-format rounds; incomplete-call charges and owner subscription usage are excluded.

Gauntlet: the worker transport now accepts actual PNG/JPEG bytes for qualified vision critics, with eight-image/per-file/aggregate limits and image hashes. The independent **Google Gemini 3.7 Flash** critic passed the analytics/API/image-transport artifact in round 3, the core UI in round 2, model evidence in round 1 and legacy UI in round 2. Earlier analytic and two UI outputs failed the JSON reporting contract; they are retained as failed-format reviews, not clean rounds. The final rounds have no unresolved product findings. The visual packets include **24 image attachments**, the prechosen [usability/accessibility checklist](evidence/phase-06/UI-CHECKLIST.md), a previous-release reference, actual code, primary observation extracts, accessible trees, keyboard assertions, axe receipts and timing measurements. [Owner acceptance](evidence/phase-06/owner-acceptance.json) verifies every final source, image, input and output hash and records exact coverage.

Owner browser checks found and fixed mobile grid overflow, React SVG hydration/title errors, low-contrast badges, indistinguishable inline links and missing keyboard equivalents in older directory rows. Final [core browser checks](evidence/phase-06/rendered-final/browser-checks.json) cover 11 states; [legacy checks](evidence/phase-06/legacy-rendered-final/checks.json) cover 21 states across all seven remaining routes. Both report zero runtime errors and zero axe violations. Evidence includes four-model selection/removal, keyboard axis limits, source and anomaly disclosures, More navigation, provider selection, scatter-table links, a deliberate HTTP503/retry, legacy A/B selection, empty ranking filters and separate v1.5 navigation. [Additional checks](evidence/phase-06/runtime-checks.json) verify exact measured/vendor API observations, invalid-axis 404, mobile filter popovers and keyboard radar scrolling.

Final local validation: `node scripts/build-dataset.mjs`, **146/146 tests**, `npx tsc --noEmit -p .`, production build, **11/11 prerender checks**, and `git diff --check` pass. The adapter test preserves all **13,908 observations**; independent raw AA/DesignArena comparisons verify all **971 existing index values**. Source-build guards still verify 43 source files and 1,003 effective self-reports. Fresh 390px mobile navigations on unthrottled local Chrome recorded FCP/LCP of 96–288 ms and CLS below 0.00001. These are laboratory receipts, not public-network or field guarantees; same-navigation audit measurements after intentional filters/resizes are not claimed as initial-load CLS.

Limits: screenshots and keyboard execution supplement automated checks; zero axe violations is not a complete WCAG conformance certificate. Axe's incomplete contrast/table cases were inspected through rendered output and source. Radar reflow is checked at 320px, while legacy pages are checked at 390px and 1440px. Diagram/table scrolling is contained; full tables can be long. The earlier unmatched-identity and source-availability limits remain visible. No live divergence is fabricated to demonstrate a populated pair. Domain, branding and later daily automation remain phases 07–09. Release verification follows the implementation push; `DONE` remains withheld until the pushed deployment is checked.

FILE scripts/check-benchmark-ui.mjs
// Run against a production server. Browser tooling may be provided outside app dependencies.
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.BH_PLAYWRIGHT_PATH || 'playwright');
const base = process.env.BH_UI_URL || 'http://127.0.0.1:3316';
const out = process.env.BH_UI_OUT || 'ops/rebuild-2026-09/evidence/phase-06/rendered';
await mkdir(out, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.BH_CHROME || '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox'] });
const receipt = { base, at: new Date().toISOString(), environment: 'Headless system Chrome on Sandy, local production HTTP unless URL overrides; no network/CPU throttling', pages: [], interactions: [], screenshots: [] };
const errors = [];
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, colorScheme: 'dark', reducedMotion: 'reduce' });
page.on('pageerror', (e) => errors.push(e.message));
await page.addInitScript(() => {
  window.__bhPerf = { cls: 0, lcp: null };
  new PerformanceObserver((list) => { for (const e of list.getEntries()) if (!e.hadRecentInput) window.__bhPerf.cls += e.value; }).observe({ type: 'layout-shift', buffered: true });
  new PerformanceObserver((list) => { for (const e of list.getEntries()) window.__bhPerf.lcp = e.startTime; }).observe({ type: 'largest-contentful-paint', buffered: true });
});
async function shot(name, locator = null) {
  const file = `${out}/${name}.png`;
  if (locator) await locator.screenshot({ path: file }); else await page.screenshot({ path: file });
  const bytes = await readFile(file); receipt.screenshots.push({ file, sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length, viewport: page.viewportSize(), theme: await page.locator('html').getAttribute('data-theme') });
}
async function loaded() { await page.waitForLoadState('networkidle'); }
async function seriesCount(n) { await page.waitForFunction((expected) => document.querySelector('[aria-label="Chart legend"]')?.children.length === expected, n); }
async function audit(name) {
  await loaded();
  await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  const metrics = await page.evaluate(() => ({ ...window.__bhPerf, fcp: performance.getEntriesByName('first-contentful-paint')[0]?.startTime, documentWidth: document.documentElement.scrollWidth, viewport: innerWidth, reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches }));
  assert.ok(metrics.documentWidth <= metrics.viewport + 1, `${name}: document overflow ${JSON.stringify(metrics)}`);
  let axe = null;
  if (process.env.BH_AXE_PATH) { await page.addScriptTag({ path: process.env.BH_AXE_PATH }); axe = await page.evaluate(async () => { const r = await axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a','wcag2aa','wcag21aa','best-practice'] } }); return { violations: r.violations.map((v) => ({ id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.slice(0, 12).map((n) => ({ target: n.target, failure: n.failureSummary })) })), incomplete: r.incomplete.map((v) => v.id), passes: r.passes.length }; }); }
  await writeFile(`${out}/${name}-aria.txt`, await page.locator('body').ariaSnapshot());
  receipt.pages.push({ name, url: page.url(), metrics, axe });
}
try {
  await page.goto(`${base}/compare`); await loaded();
  await page.keyboard.press('Tab'); assert.match(await page.locator(':focus').innerText(), /Skip to main/);
  await page.keyboard.press('Enter'); assert.equal(await page.locator(':focus').getAttribute('id'), 'main-content');
  receipt.interactions.push('Tab reaches skip link; Enter focuses main content');
  await page.evaluate(() => { document.activeElement?.blur(); window.scrollTo(0, 0); });
  await audit('compare-dark'); await shot('compare-dark');
  await shot('radar-dark', page.getByRole('region', { name: 'Benchmark radar', exact: true }));
  await page.getByRole('combobox', { name: 'Model C', exact: true }).selectOption('gpt-5.6-terra::high'); await seriesCount(3);
  await page.getByRole('combobox', { name: 'Model D', exact: true }).selectOption('grok-4.6::high'); await seriesCount(4);
  assert.equal(await page.getByRole('list', { name: 'Chart legend' }).locator('li').count(), 4);
  await shot('radar-four', page.getByRole('region', { name: 'Benchmark radar', exact: true }));
  await page.getByRole('button', { name: /Remove GPT-5.6 Terra/ }).focus(); await page.keyboard.press('Enter'); await seriesCount(3);
  assert.equal(await page.getByRole('list', { name: 'Chart legend' }).locator('li').count(), 3);
  receipt.interactions.push('Native model selects add C/D to four series; focused Remove + Enter reduces to three');
  const axisSummary = page.locator('summary').filter({ hasText: 'Radar axes' }); await axisSummary.focus(); await page.keyboard.press('Enter');
  const checks = axisSummary.locator('..');
  while (await checks.locator('input:checked').count() < 8) { const c = checks.locator('input:not(:checked):not(:disabled)').first(); await c.focus(); await page.keyboard.press('Space'); }
  assert.equal(await checks.locator('input:checked').count(), 8); assert.ok(await checks.locator('input:disabled').count() > 0);
  receipt.interactions.push('Keyboard Space selects radar axes; eight-axis cap disables remaining choices');
  await axisSummary.focus(); await page.keyboard.press('Enter');
  const evidence = page.locator('#full-comparison summary').filter({ hasText: /^Evidence$/ }).first(); await evidence.focus(); await page.keyboard.press('Enter'); assert.equal(await evidence.locator('..').getAttribute('open'), '');
  await shot('compare-evidence', page.locator('#full-comparison').locator('table').locator('tbody').first());
  receipt.interactions.push('Keyboard Enter opens a numeric source evidence disclosure');
  await page.getByRole('button', { name: /theme/i }).click(); assert.equal(await page.locator('html').getAttribute('data-theme'), 'light');
  await audit('compare-light'); await shot('radar-light', page.getByRole('region', { name: 'Benchmark radar', exact: true }));
  await page.goto(`${base}/radar`); await loaded(); await audit('radar-light');
  await page.setViewportSize({ width: 390, height: 844 }); await page.evaluate(() => window.scrollTo(0, 0)); await audit('radar-mobile'); await shot('radar-mobile'); await page.locator('#benchmark-radar').evaluate((el) => window.scrollTo(0, scrollY + el.getBoundingClientRect().top - 16)); await shot('radar-mobile-chart');
  await page.setViewportSize({ width: 320, height: 844 }); await audit('radar-320');
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(`${base}/benchmarks`); await loaded(); await audit('ranking-light'); await shot('ranking-light');
  await page.getByRole('combobox', { name: 'Benchmark and version', exact: true }).selectOption('aa-coding-agent-index::1.5'); await loaded();
  assert.match(await page.locator('main').innerText(), /Version 1.5/); await shot('ranking-v1-5');
  await page.getByLabel('Search models', { exact: true }).fill('no-such-model-638173'); assert.ok(await page.getByText('No results in this view', { exact: true }).isVisible());
  receipt.interactions.push('Version selector exposes v1.5 separately; no-match search displays explicit empty state');
  await page.getByLabel('Search models', { exact: true }).fill('');
  await page.setViewportSize({ width: 390, height: 844 }); await audit('ranking-mobile'); await shot('ranking-mobile');
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(`${base}/models/gpt-5.6-sol%3A%3Ahigh`); await loaded();
  await page.locator('#benchmark-sheet').scrollIntoViewIfNeeded(); await audit('model-sheet'); await shot('model-sheet');
  const why = page.locator('#benchmark-sheet summary').filter({ hasText: /^Why$/ }).first();
  if (await why.count()) { await why.focus(); await page.keyboard.press('Enter'); await shot('anomaly-why'); receipt.interactions.push('Model sheet anomaly Why opens through keyboard; input values and directed z are rendered'); }
  await page.goto(`${base}/models/qwen3-235b-a22b-thinking-2507%3A%3Areasoning`); await loaded();
  const claim = page.locator('#benchmark-sheet').getByText('self-reported', { exact: true }).first(); await claim.scrollIntoViewIfNeeded(); await shot('self-reported-sheet');
  await page.goto(`${base}/`); await loaded(); await audit('overview-light'); await shot('overview-light');
  await page.setViewportSize({ width: 390, height: 844 }); await audit('overview-mobile'); await shot('overview-mobile');
  await page.getByRole('button', { name: /theme/i }).click(); await page.waitForFunction(() => document.documentElement.dataset.theme === 'dark'); await audit('overview-dark-mobile');
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(`${base}/compare`); await loaded();
  let fail = true;
  await page.route('**/api/benchmark-view?*', (route) => fail ? route.fulfill({ status: 503, contentType: 'application/json', body: '{}' }) : route.continue());
  await page.getByRole('combobox', { name: 'Model C', exact: true }).selectOption('gpt-5.6-terra::high'); await page.getByRole('button', { name: 'Retry loading', exact: true }).waitFor({ state: 'visible' });
  assert.ok(await page.getByRole('button', { name: 'Retry loading', exact: true }).isVisible());
  fail = false; await page.getByRole('button', { name: 'Retry loading', exact: true }).click(); await seriesCount(3);
  assert.equal(await page.getByRole('list', { name: 'Chart legend' }).locator('li').count(), 3);
  receipt.interactions.push('Injected local HTTP503 shows retry; retry loads three models without stale or fabricated scores');
  await page.unroute('**/api/benchmark-view?*');
  const summary = page.locator('summary').filter({ hasText: 'Price & provider comparison' }); await summary.focus(); await page.keyboard.press('Enter');
  await page.getByRole('button', { name: /Select GPT-5.6 Sol \(high\) for comparison/ }).click(); await page.getByRole('button', { name: /Select Grok 4.6 \(high\) for comparison/ }).click();
  receipt.interactions.push('Legacy two-model price/provider comparison remains selectable');
  receipt.errors = errors; assert.equal(errors.length, 0, 'browser runtime errors');
  receipt.verdict = receipt.pages.some((p) => p.axe?.violations.length) ? 'needs-accessibility-fixes' : 'pass';
} catch (error) { await shot('failure'); await writeFile(`${out}/failure-aria.txt`, await page.locator('body').ariaSnapshot()); receipt.failure = error.stack; receipt.verdict = 'failed'; process.exitCode = 1; }
finally { await writeFile(`${out}/browser-checks.json`, JSON.stringify(receipt, null, 2)+'\n'); await browser.close(); }
console.log(JSON.stringify({ verdict: receipt.verdict, failure: receipt.failure, pages: receipt.pages.map((p) => ({ name:p.name, violations:p.axe?.violations.map((v) => v.id), metrics:p.metrics })), interactions:receipt.interactions.length, screenshots:receipt.screenshots.length },null,2));

FILE scripts/check-benchmark-legacy-ui.mjs
import { createRequire } from 'node:module';
import { writeFile, mkdir } from 'node:fs/promises';
const require=createRequire(import.meta.url); const {chromium}=require(process.env.BH_PLAYWRIGHT_PATH || 'playwright');
const base=process.env.BH_UI_URL || 'http://127.0.0.1:3316'; const out=process.env.BH_UI_OUT || 'ops/rebuild-2026-09/evidence/phase-06/legacy-rendered';await mkdir(out,{recursive:true});
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox']});
const context=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
await context.addInitScript(()=>{localStorage.setItem('bh-theme','light');window.__bhPerf={cls:0,lcp:null};new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)window.__bhPerf.cls+=e.value}).observe({type:'layout-shift',buffered:true});new PerformanceObserver(list=>{window.__bhPerf.lcp=list.getEntries().at(-1).startTime}).observe({type:'largest-contentful-paint',buffered:true});});
const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));const results=[];
for(const route of ['/charts','/scatter','/providers','/provider-explorer','/eu','/gateways','/about']){
 await page.setViewportSize({width:1440,height:1000});await page.goto(base+route);await page.waitForLoadState('networkidle');
 for(const [width,theme] of [[1440,'light'],[390,'light'],[1440,'dark']]){
 await page.evaluate(t=>document.documentElement.dataset.theme=t,theme);
 await page.setViewportSize({width,height:width===1440?1000:844});await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 await page.addScriptTag({path:process.env.BH_AXE_PATH});
 const result=await page.evaluate(async()=>{const a=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','best-practice']}});return {overflow:document.documentElement.scrollWidth-innerWidth,violations:a.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.slice(0,8).map(n=>({target:n.target,summary:n.failureSummary}))})),incomplete:a.incomplete.map(v=>v.id),metrics:{...window.__bhPerf,fcp:performance.getEntriesByName('first-contentful-paint')[0]?.startTime}}});
 results.push({route,width,theme,...result});console.log(route,width,theme,result.overflow,result.violations.map(x=>x.id));
 await page.screenshot({path:out+'/'+route.slice(1)+'-'+width+'-'+theme+'.png'});if(width===1440 && theme==='light')await writeFile(out+'/'+route.slice(1)+'-aria.txt',await page.locator('body').ariaSnapshot());
 }
}
const interactions=[];
await page.setViewportSize({width:390,height:844});await page.goto(base+'/');await page.waitForLoadState('networkidle');
const more=page.locator('nav summary');await more.focus();await page.keyboard.press('Enter');await page.keyboard.press('Tab');if(!(await page.locator(':focus').getAttribute('href')))throw Error('More navigation not reachable by Tab');await page.keyboard.press('Enter');await page.waitForLoadState('networkidle');interactions.push('More disclosure Enter + Tab reaches a secondary navigation link and Enter navigates');
await page.goto(base+'/provider-explorer');await page.waitForLoadState('networkidle');const provider=page.getByRole('button',{pressed:false}).filter({hasText:'Chutes'}).first();if(await provider.count()){const handle=await provider.elementHandle();await handle.focus();await page.keyboard.press('Enter');await page.waitForFunction(el=>el.getAttribute('aria-pressed')==='true',handle);interactions.push('Provider directory selection by focus + Enter updates aria-pressed');}
const model=page.locator('main button[aria-expanded]').filter({hasText:'GPT'}).first();if(await model.count()){const handle=await model.elementHandle();await handle.focus();await page.keyboard.press('Enter');await page.waitForFunction(el=>el.getAttribute('aria-expanded')==='true',handle);interactions.push('Model offer comparison opens using Enter');}
await page.goto(base+'/scatter');await page.waitForLoadState('networkidle');const table=page.locator('summary').filter({hasText:'Model prices and scores'});await table.focus();await page.keyboard.press('Enter');if(await table.locator('..').locator('a[href^="/models/"]').count()===0)throw Error('Scatter table missing equivalent links');interactions.push('Scatter accessible table opens with Enter and exposes model links');
await writeFile(out+'/checks.json',JSON.stringify({at:new Date().toISOString(),base,environment:'Unthrottled system Chrome on local production build; each route navigation loads at desktop width, then same-document theme and viewport changes',errors,interactions,results},null,2));await browser.close();

if(errors.length || results.some(r=>r.overflow>1 || r.violations.length))process.exitCode=1;

FILE tailwind.config.ts
import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "rgb(var(--ink) / <alpha-value>)", panel: "rgb(var(--panel) / <alpha-value>)", line: "rgb(var(--line) / <alpha-value>)",
        accent: "rgb(var(--accent) / <alpha-value>)", accent2: "rgb(var(--accent2) / <alpha-value>)", warn: "rgb(var(--warn) / <alpha-value>)",
      },
      fontFamily: { mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"] },
    },
  },
  plugins: [],
} satisfies Config;

FILE lib/types.ts
import type { BenchmarkResults } from "./benchmark-scores.mjs";
export interface Benchmarks {
  aa_intelligence_index?: number | null;
  aa_coding_index?: number | null;
  aa_coding_agent_index?: number | null;
  aa_math_index?: number | null;
  aa_livecodebench?: number | null;
  aa_scicode?: number | null;
  aa_terminalbench_hard?: number | null;
  aa_tau2?: number | null;
  aa_gpqa?: number | null;
  aa_mmlu_pro?: number | null;
}

export interface EfficiencyProvenance {
  source: string;
  url: string;
  collected_at: string;
  basis: "measured" | "self_reported" | "derived" | "assumed";
  source_basis?: "measured" | "self_reported" | "derived" | "assumed";
  scope?: string;
  formula?: string;
}

export interface EfficiencyObservation<T = number> extends EfficiencyProvenance {
  value: T;
  window?: { start_date: string; end_date: string };
  stale?: boolean;
}

export interface EfficiencyAttempt {
  source: string;
  url: string | null;
  collected_at: string | null;
  status: string;
  reason?: string;
  or_model_id?: string | null;
  dimension?: string;
  http_status?: number;
}

export interface TokenEfficiency {
  aa: {
    status: "available" | "not_published_in_collected_payload" | "not_in_aa";
    source_model_id: string | null;
    source_slug: string | null;
    source_variant: string | null;
    tokens_per_task: EfficiencyObservation<{ reasoning: number; answer: number; output: number }> | null;
    canonical_token_counts: EfficiencyObservation<{ input: number; output: number; answer: number; reasoning: number }> | null;
    benchmark_input_output_ratio: (EfficiencyObservation & { interpretation: "benchmark_proxy" }) | null;
  };
  input_output_ratio: EfficiencyObservation & {
    fallback: boolean;
    or_model_id?: string;
    fallback_reason?: string;
    evidence_ref?: string;
    configuration_scope?: string;
    source_updated_at?: string | null;
  };
  attempts: EfficiencyAttempt[];
}

export interface EndpointEfficiency {
  or_model_id: string;
  endpoint_tag: string;
  provider: string;
  endpoint_id: string | null;
  cache_hit_rate: (EfficiencyObservation & {
    total_tokens: number;
    source_provider_name: string;
    source_provider_slug: string;
    summary_window: null;
    chart_date_range: { first: string; last: string } | null;
    definition: string;
  }) | null;
  cache_read_per_1m: EfficiencyObservation | null;
  cache_write_per_1m: EfficiencyObservation | null;
  status: string;
  attempts: EfficiencyAttempt[];
}

export interface EfficiencyDataset {
  schema_version: 1;
  global_io_ratio: EfficiencyObservation & {
    totals: { total_input_tokens: number; total_output_tokens: number; total_requests: number };
    coverage: { returned_rows: number; included_rows: number; excluded_rows: number; included_chutes: number; days: number; selection: string; completeness: string };
  };
  openrouter_endpoints: Record<string, Record<string, EndpointEfficiency>>;
  aa_unmatched: EfficiencyObservation<Array<{ source_id: string; slug: string; name: string; variant: string | null;
    tokens_per_task: { reasoning: number; answer: number; output: number };
    canonical_token_counts: { input: number; output: number; answer: number; reasoning: number };
    derived: { basis: "derived"; input_output_ratio: number; reasoning_output_share: number | null } }>> & { reason: string };
  coverage: Record<string, number>;
}

export interface DesignArenaEntry {
  elo?: number | null;
  winRate?: number | null;
  battles?: number | null;
  modelId?: string;
}

export interface Offer {
  source: string;
  provider: string;
  platform: string;
  input_per_1m: number | null;
  output_per_1m: number | null;
  cache_read_per_1m?: number | null;
  cache_write_per_1m?: number | null;
  internal_reasoning_per_1m?: number | null;
  input_per_1m_eur?: number | null;
  output_per_1m_eur?: number | null;
  currency?: string;
  region: string;
  unit: string; // "per_1m_token" | "per_request"
  estimated?: boolean;
  notes?: string;
  or_model_id?: string;
  or_canonical_slug?: string | null;
  or_hugging_face_id?: string | null;
  status?: number | null;
  endpoint_tag?: string | null;
  quantization?: string | null;
  context_length?: number | null;
  max_completion_tokens?: number | null;
  provider_model_id?: string | null;
  catalog_status?: string | null;
  hosting_class?: string | null;
  pricing_tier?: string | null;
  route_type?: string | null;
  tee?: boolean; // runs in a Trusted Execution Environment (confidential compute)
  eu_hosted?: boolean; // this specific offer/model is served from an EU region
  eu_policy_equivalent?: boolean; // company-approved EU-filter equivalent; not a technical residency guarantee
  non_us?: boolean; // provider company is not US-based (copied from provider metadata)
}

export interface CopilotTokenPricing {
  input_per_1m: number | null;
  cached_input_per_1m: number | null;
  cache_write_per_1m: number | null;
  output_per_1m: number | null;
  release_status?: string;
  feature_status?: string;
  category?: string;
  long_context?: Record<string, unknown> | null;
  promotion_ends_at?: string | null;
  standard_pricing_from?: string | null;
  standard_input_per_1m?: number | null;
  standard_cached_input_per_1m?: number | null;
  standard_cache_write_per_1m?: number | null;
  standard_output_per_1m?: number | null;
  notes?: string;
}

export interface CopilotPricing {
  multiplier: number | null;
  usd_per_request: number | null;
  notes?: string;
  current?: CopilotTokenPricing;
  fast_mode?: CopilotTokenPricing;
}

export interface ModelRow {
  id: string;
  family_key: string;
  family_name: string;
  display_name: string;
  org: string;
  variant: string;
  open_weights: boolean;
  release_date: string | null;
  deprecated?: boolean;
  aa_model_id?: string | null;
  aa_metadata?: {
    available?: boolean;
    is_open_weights?: boolean | null;
    deprecated?: boolean | null;
    is_reasoning?: boolean | null;
    commercial_allowed?: boolean | null;
    license_name?: string | null;
    license_url?: string | null;
    huggingface_url?: string | null;
    source_huggingface_url?: string | null;
    metadata_correction?: string;
    openrouter_api_id?: string | null;
    context_window_tokens?: number | null;
    retained_fields?: Record<string, { source: string; collected_at: string; reason: string }>;
  };
  openrouter_metadata?: {
    id?: string | null;
    canonical_slug?: string | null;
    hugging_face_id?: string | null;
    context_window_tokens?: number | null;
  };
  coding_agent_results?: { harness: string; score: number; source_model_name?: string }[];
  featured: boolean;
  has_benchmark: boolean;
  has_pricing: boolean;
  benchmarks: Benchmarks;
  aa_reference_price: { input_per_1m?: number | null; output_per_1m?: number | null; blended_3to1?: number | null };
  aa_speed: { output_tps?: number | null; ttft_s?: number | null };
  designarena: { frontend?: DesignArenaEntry; fullstack?: DesignArenaEntry };
  copilot: CopilotPricing | null;
  offers: Offer[];
  manual_notes?: string;
  benchmark_override_note?: string;
  designarena_attachment_note?: string;
  token_efficiency?: TokenEfficiency;
}

export interface Dataset {
  benchmark_results: BenchmarkResults;
  generated_at: string;
  counts: { models: number; families: number; providers: number; offers: number };
  sources: Record<string, string>;
  efficiency?: EfficiencyDataset;
  source_status?: Record<string, { version: string; status: string; collected_at?: string; note?: string; count?: number; path?: string; url?: string }>;
  models: ModelRow[];
  providers: {
    platform: string; provider: string; model_count: number;
    eu_hosted?: boolean; eu_dedicated?: boolean; non_us?: boolean; hyperscaler?: boolean;
    country?: string | null; note?: string; coming_soon?: boolean;
  }[];
}

export type ScoreKey =
  | "composite"
  | "aa_coding_index"
  | "aa_coding_agent"
  | "aa_intelligence_index"
  | "designarena_frontend"
  | "designarena_fullstack";

export const SCORE_LABELS: Record<ScoreKey, string> = {
  composite: "Composite (coverage-neutral, dominance-safe percentiles, 0–100)",
  aa_coding_index: "ArtificialAnalysis — Coding Index",
  aa_coding_agent: "ArtificialAnalysis — Coding Agent Index v1.4 (median harness)",
  aa_intelligence_index: "ArtificialAnalysis — Intelligence Index",
  designarena_frontend: "DesignArena — Agentic Web Dev (Frontend) Elo",
  designarena_fullstack: "DesignArena — Agentic Web Dev (Full-Stack) Elo",
};

FILE test/production/prerender.mjs
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

// Run explicitly after npm run build (without DATABASE_URL). This tests the
// production artifact, not a source-code spelling of the cache policy.
const manifest = JSON.parse(readFileSync('.next/prerender-manifest.json', 'utf8'));
for (const route of ['/', '/about', '/charts', '/compare', '/eu', '/gateways', '/provider-explorer', '/providers', '/scatter', '/benchmarks', '/radar']) {
  test(`bundled catalog ${route} is rendered once at build time`, () => {
    assert.ok(manifest.routes[route], `${route} must not repeat catalog SSR per request`);
    assert.equal(manifest.routes[route].initialRevalidateSeconds, false);
  });
}

EXACT EVIDENCE owner-acceptance.json
{
  "at": "2026-09-11T01:10:57.171Z",
  "accepted_artifacts": [
    {
      "artifact_id": "phase06-analytics",
      "round": 3,
      "artifact_sha256": "88505eb8a41b424137c374e788ad0e1799b4902942b9812374dcd5ce84c59913",
      "model": "google/gemini-3.7-flash",
      "aa": 36.9,
      "files_verified": [
        "lib/benchmark-view.mjs",
        "lib/benchmark-view.d.mts",
        "lib/benchmark-data.ts",
        "app/api/benchmark-view/route.ts",
        "app/api/benchmark-scores/route.ts",
        "test/benchmark-view.test.mjs",
        "ops/rebuild-2026-09/bin/worker-images.mjs",
        "ops/rebuild-2026-09/bin/worker-runner.mjs",
        "test/worker-images.test.mjs",
        "app/api/price-comparison/route.ts"
      ],
      "image_count": 0,
      "input_hash_verified": true,
      "output_hash_verified": true,
      "coverage": [
        "lib/benchmark-view.mjs: radar normalization arithmetic, zero-handling, direction inversion, and uninformative range withholding",
        "lib/benchmark-view.mjs: latest observation selection prioritizing measured and latest date without selecting highest score",
        "lib/benchmark-view.mjs: peer distribution calculation with low-sample and duplicate source suppression",
        "lib/benchmark-view.mjs: profile anomaly thresholds (minPeers=20, minFamilies=10, minProfile=5, peerZ=1.5, profileGap=1.5) and family-level baseline aggregation",
        "lib/benchmark-view.mjs: cohort separation by harness, split, and configuration (e.g. CoT, Polyglot edit formats)",
        "lib/benchmark-view.mjs: dated snapshot axes for AA index and DesignArena without semantic version invention",
        "lib/benchmark-view.d.mts: type definitions matching presentation adapter exports and interfaces",
        "lib/benchmark-data.ts: in-memory caching of benchmark view against dataset reference",
        "app/api/benchmark-view/route.ts: query parsing, axis 404 validation, model slicing, and cache header preservation",
        "app/api/benchmark-scores/route.ts: pagination bounds (1-500), observation_id filtering, basis validation, and cell/coverage lookup",
        "app/api/price-comparison/route.ts: on-demand legacy client dataset endpoint",
        "ops/rebuild-2026-09/bin/worker-images.mjs: image input size gating (4MB per file, 16MB aggregate), 8-image cap, magic-byte MIME validation, and hash receipts",
        "ops/rebuild-2026-09/bin/worker-runner.mjs: image critic integration and producer/critic family isolation checks",
        "test/benchmark-view.test.mjs: test coverage for peer distribution, normalization, profile signals, cohorts, and non-mutation of raw dataset",
        "test/worker-images.test.mjs: vision critic payload, MIME validation, and gate enforcement test coverage"
      ],
      "uncertainties": []
    },
    {
      "artifact_id": "phase06-ui-core",
      "round": 2,
      "artifact_sha256": "4b4531caaabae391855799683b0d1613c36da47978d50bf7f88e62eaf89eaa05",
      "model": "google/gemini-3.7-flash",
      "aa": 36.9,
      "files_verified": [
        "components/BenchmarkRadar.tsx",
        "components/BenchmarkCompare.tsx",
        "components/BenchmarkRanking.tsx",
        "components/CompositeNote.tsx",
        "components/ComparePricePanel.tsx",
        "app/compare/page.tsx",
        "app/radar/page.tsx",
        "app/benchmarks/page.tsx",
        "app/globals.css",
        "components/Nav.tsx",
        "components/ThemeToggle.tsx",
        "app/layout.tsx",
        "components/GlobalFilters.tsx",
        "lib/score-label.ts"
      ],
      "image_count": 8,
      "input_hash_verified": true,
      "output_hash_verified": true,
      "coverage": [
        "Primary navigation structure, active page attributes, theme toggle, and skip-link behavior (Nav.tsx, ThemeToggle.tsx, app/layout.tsx, compare-dark accessible tree)",
        "Compare view 0-4 model native controls, remove/search interactions, and isolated on-demand price comparison disclosure (BenchmarkCompare.tsx, ComparePricePanel.tsx, compare-dark.png screenshot)",
        "Benchmark radar rendering across 3-8 selectable versioned axes, series dashes and color definitions, catalog normalization min/max, unclosed polygon gaps for missing data, and accompanying scrollable table with range metadata (BenchmarkRadar.tsx, radar-four.png, radar-light.png, radar-mobile-top.png screenshots)",
        "Rankings view evaluation groups/harnesses, native unit and direction rendering, honest denominators, tie ranking within filtered groups, and evidence filtering (BenchmarkRanking.tsx, ranking-light.png, ranking-v1-5.png, ranking-mobile.png screenshots)",
        "Isolation of legacy Composite inputs and Coding Agent v1.4 from active v1.5 navigation (CompositeNote.tsx, score-label.ts, tests.log, legacy-source-check.json)",
        "Audit-based evaluation of routes not attached as full screenshots (compare-light, radar-320, model-sheet, overview-light/mobile) via browser-checks.json, runtime-checks.json, and accessibility tree receipts",
        "Reflow and horizontal containment: 320px viewport verified for the radar route; 1440px and 390px viewports verified across legacy and core pages without document horizontal overflow",
        "Color contrast and automated axe test passes (0 violations across 11 page states in browser-checks.json; noted that automated scanning does not constitute full WCAG certification)",
        "146 unit and integration test assertions passing without errors or skips (tests.log)"
      ],
      "uncertainties": [
        "Initial paint timings (FCP/LCP) and layout shift values are verified from local unthrottled production Chrome runs rather than live public field telemetry.",
        "320px viewport reflow verification is specifically evidenced for the radar view via browser-checks.json and accessible tree receipts, while legacy routes are verified at 1440px and 390px."
      ]
    },
    {
      "artifact_id": "phase06-ui-evidence",
      "round": 1,
      "artifact_sha256": "3dc1cdfde70810d979a17d0a2b59d66feabaa93cd202ced2c273e100990b8f00",
      "model": "google/gemini-3.7-flash",
      "aa": 36.9,
      "files_verified": [
        "components/BenchmarkEvidence.tsx",
        "components/BenchmarkSheet.tsx",
        "app/models/[id]/page.tsx",
        "components/ModelExplorer.tsx",
        "components/CompareView.tsx",
        "lib/benchmark-view.mjs",
        "app/globals.css",
        "components/Nav.tsx",
        "components/ThemeToggle.tsx",
        "app/layout.tsx",
        "components/GlobalFilters.tsx",
        "lib/score-label.ts"
      ],
      "image_count": 8,
      "input_hash_verified": true,
      "output_hash_verified": true,
      "coverage": [
        "Benchmark sheet page rendering and layout (components/BenchmarkSheet.tsx, app/models/[id]/page.tsx)",
        "Anomaly explanation heuristics and disclosure rendering (components/BenchmarkEvidence.tsx, anomaly-why.png, deterministic anomaly test inputs)",
        "Vendor self-reported observations and badges (self-reported-sheet.png, components/BenchmarkEvidence.tsx)",
        "Measured vs vendor divergence empty state and compatibility messaging (model-sheet.png, docs/benchmark-explorer.md)",
        "Full comparison evidence table with multi-model observation cards and exact IDs (compare-evidence.png, components/CompareView.tsx)",
        "Overview desktop light and mobile responsive views (overview-light.png, overview-mobile.png, radar-mobile.png)",
        "Top navigation, active page announcement, and collapsible Price/Provider filters (components/Nav.tsx, components/GlobalFilters.tsx, app/layout.tsx)",
        "Accessible tree hierarchy, skip link target, and automated axe scan receipts (browser-checks.json, accessible tree excerpts)",
        "Contrast, badge styling, and table horizontal scroll regions (app/globals.css, components/BenchmarkSheet.tsx)"
      ],
      "uncertainties": [
        "Axe receipt lists incomplete status for color-contrast and th-has-data-cells across multiple pages, which relies on visual/code inspection rather than full automated certification.",
        "Reported FCP, LCP, and CLS metrics were measured on unthrottled localhost Chrome rather than geographically distributed end-user network conditions."
      ]
    },
    {
      "artifact_id": "phase06-ui-legacy",
      "round": 2,
      "artifact_sha256": "402ed83aa74cd271a3427f081922f2dda8efb53a65ee18fe9fcab1977f6af706",
      "model": "google/gemini-3.7-flash",
      "aa": 36.9,
      "files_verified": [
        "components/ProviderExplorer.tsx",
        "components/ProvidersView.tsx",
        "components/CostCapabilityScatter.tsx",
        "components/ChartsBoard.tsx",
        "components/GatewaysView.tsx",
        "components/ui.tsx",
        "app/about/page.tsx",
        "app/eu/page.tsx",
        "app/charts/page.tsx",
        "app/globals.css",
        "components/Nav.tsx",
        "components/ThemeToggle.tsx",
        "app/layout.tsx",
        "components/GlobalFilters.tsx",
        "lib/score-label.ts"
      ],
      "image_count": 8,
      "input_hash_verified": true,
      "output_hash_verified": true,
      "coverage": [
        "Primary header navigation with Overview, Benchmarks, Compare, Radar, More dropdown, active route indication, skip link, and ThemeToggle",
        "Global price & provider filter disclosure with ScoreSelect, NumFilter min score, Adjusted/Raw toggle, fixed I/O blend selector, feature/collapse/residency toggles, and multi-select dropdowns",
        "Charts page (/charts) with capability leaderboard, cheapest models bar chart, open vs closed comparison, and keyboard-accessible price/cost tables (rendered 1440px light visual inspected; 1440px dark and 390px light verified via browser checks receipt)",
        "Cost vs Capability scatter (/scatter) with log/linear cost axis toggle, Pareto frontier halo and connection line, legend by org and weight type, and accessible data table (rendered 1440px light visual inspected; 1440px dark and 390px light verified via browser checks receipt)",
        "Providers per Model view (/providers) with single-model offers ranking, peer rank across models, model picker, data bars, and constituent expansions (rendered 390px light visual inspected; 1440px light/dark verified via browser checks receipt)",
        "Provider explorer (/provider-explorer) two-pane directory with search, sort options (by #models, EU first, A-Z), filter checkboxes, and model offer comparisons (rendered 1440px dark and 390px light visuals inspected; 1440px light verified via browser checks receipt)",
        "EU & Sovereign cloud view (/eu) with SOTA open-model table, company-policy equivalents, sovereign provider catalog, and proprietary exclusions (rendered 1440px light visual inspected; 1440px dark and 390px light verified via browser checks receipt)",
        "Gateways view (/gateways) with search, EU routing badges, filter toggles, and metadata listings (rendered 390px light visual inspected; 1440px light/dark verified via browser checks receipt)",
        "About & data sources view (/about) with tracked source citations, featured models definitions, dataset snapshot metadata, and calculation methodology (rendered 1440px light visual inspected; 1440px dark and 390px light verified via browser checks receipt)",
        "Responsive layout validation confirming zero document overflow across all legacy routes at 1440px and 390px in checks.json receipt (noting 320px reflow evidence is scoped to radar)",
        "Accessibility check results (zero automated axe violations across routes in receipt, acknowledging automated scans do not certify complete WCAG conformance)"
      ],
      "uncertainties": []
    }
  ],
  "completed_worker_receipts": [
    {
      "file": "evidence-components-draft.txt.meta.json",
      "model": "z-ai/glm-5.3-flash",
      "cost": 0.00974660445
    },
    {
      "file": "styles-draft.txt.meta.json",
      "model": "deepseek/deepseek-v4-flash-0731",
      "cost": 0.00064137744
    },
    {
      "file": "review/analytics-round1.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0239092425
    },
    {
      "file": "review/analytics-round2.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0276766875
    },
    {
      "file": "review/analytics-round3.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0271094175
    },
    {
      "file": "review/ui-core-round1.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0591883875
    },
    {
      "file": "review/ui-core-round2.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0606674475
    },
    {
      "file": "review/ui-evidence-round1.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.0655887375
    },
    {
      "file": "review/ui-legacy-round1.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.07445196
    },
    {
      "file": "review/ui-legacy-round2.json.meta.json",
      "model": "google/gemini-3.7-flash",
      "cost": 0.07659036
    }
  ],
  "recorded_completed_call_cost_usd": 0.42557022188999993,
  "cost_note": "Includes superseded format rounds; incomplete/failed worker charges are not included. Astra subscription usage is separate.",
  "scope_notes": [
    "Critics received actual image bytes through image-capable transport. Owner recomputed source/image/input/output hashes.",
    "Zero axe violations in 11 new/overview states plus 21 legacy states is not full accessibility conformance.",
    "320px automated reflow evidence is for radar. Legacy reflow is verified at390px/1440px. All shipped routes are represented in source, audit and attached screenshots across the three visual artifacts.",
    "No live protocol-compatible divergence exists. Empty state and schema rendering were reviewed; numerical pair arithmetic has synthetic phase05 tests.",
    "No unresolved code or pixel finding; no phase07 branding or phase08 automation completion is claimed."
  ]
}
EXACT EVIDENCE dataset-continuity.json
{
  "verified_at": "2026-09-11T01:12:48.252Z",
  "comparison": "Full prior committed dataset equals rebuilt dataset after removing only generated_at",
  "generated_at": [
    "2026-09-10T23:52:39.039Z",
    "2026-09-11T01:03:42.649Z"
  ],
  "models": 835,
  "observations": 13908,
  "unchanged": true
}
EXACT EVIDENCE runtime-checks.json
{
  "at": "2026-09-11T01:07:17.344Z",
  "api": [
    {
      "id": "aa:0081ab31-d10a-44a0-a10d-eee5533fec65:aime25",
      "status": 200,
      "exactObservationEqualsDataset": true
    },
    {
      "id": "vendor:Qwen/Qwen3-235B-A22B-Thinking-2507:tau2-bench::2/retail",
      "status": 200,
      "exactObservationEqualsDataset": true
    },
    {
      "invalidAxisStatus": 404
    }
  ],
  "mobileFirstNavigationMetrics": [
    {
      "path": "/",
      "cls": 0.000009596225909524688,
      "lcp": 288,
      "fcp": 288,
      "viewport": 390,
      "documentWidth": 390
    },
    {
      "path": "/compare",
      "cls": 0.000009596225909524688,
      "lcp": 144,
      "fcp": 144,
      "viewport": 390,
      "documentWidth": 390
    },
    {
      "path": "/radar",
      "cls": 0.000009596225909524688,
      "lcp": 96,
      "fcp": 96,
      "viewport": 390,
      "documentWidth": 390
    },
    {
      "path": "/benchmarks",
      "cls": 0.000009596225909524688,
      "lcp": 140,
      "fcp": 140,
      "viewport": 390,
      "documentWidth": 390
    }
  ],
  "environment": "Unthrottled local production Chrome; separate fresh mobile navigations; other browser checks may share server CPU",
  "interactions": [
    "390px global price filters + model-family dropdown opened by keyboard; search accepts input; no document overflow",
    "390px provider dropdown opened by keyboard; no document overflow",
    "Radar graphic horizontal scrolling works with keyboard ArrowRight"
  ]
}
EXACT EVIDENCE legacy-source-check.json
{
  "checked": 971,
  "aa_date": "2026-09-10",
  "da_date": "2026-09-10",
  "sources": [
    {
      "path": "data/raw/artificialanalysis.json",
      "sha256": "8705b2494f71b651f5c72c5c5bebadf21fbcd6c60fa910356b102df37e5c3254"
    },
    {
      "path": "data/raw/designarena.json",
      "sha256": "45ca12c7791f1b8d51d9e4297188ca37202e18bb65cb0c7e1746f5aac52199cd"
    }
  ]
}
EXACT EVIDENCE tests.log

> model-market-comparison@1.0.0 test
> node --test test/

✔ full Coding Agent board resolves Flight references and preserves exact model/harness names (7.618276ms)
✔ Coding Agent rejects partial, malformed, ambiguous, changed-version and invalid-score payloads (14.695261ms)
✔ failed live fetch or partial parse never overwrites the previous snapshot (16.950158ms)
✔ metadata parsing does not depend on first key or erase escaped quotes (0.453821ms)
✔ efficiency parse extracts slug, UUID, variant, measured fields and derived ratios (27.740973ms)
✔ efficiency parse resolves Flight references for efficiency fields (16.240551ms)
✔ efficiency parse rejects missing, malformed, partial and invalid payloads (87.303342ms)
✔ failed or partial refresh never overwrites the previous snapshot (5043.103752ms)
✔ live fetcher records attempts and only accepts the first successful probe (2510.864319ms)
✔ AA stops on restrictive robots and 429 without probing alternate pages (1.990532ms)
✔ a newly published API model keeps scores with explicitly unknown metadata (2.08323ms)
✔ broken leaderboard parsing or widespread drift cannot replace a good snapshot (0.785506ms)
✔ slug metadata joins UUID API rows; retained fields keep their original provenance across refreshes (1.505892ms)
✔ AA discovery preserves exact identity, zero, null, negative score, version fields and references (3.610351ms)
✔ AA discovery rejects incomplete, conflicting and nonnumeric source data (2.676119ms)
✔ AA source continuity rejects field loss even when model count is unchanged (2.312997ms)
✔ accepted registry is complete and exact version lookup never falls back to family (29.98791ms)
✔ Coding Agent legacy observation date and current source version remain isolated (2.995123ms)
✔ schema rejects sourceless, nonfinite, mismatched-scale and unversioned scores (4.553263ms)
✔ divergence isolates versions, effort, harness, audited compatibility and sources (2.896645ms)
✔ sparse cells do not infer not-tested from absence; coverage counts cells once (1.966363ms)
✔ source and critic receipts must match; any edited self-report loses approval (20.073669ms)
✔ Composite slot list and v1.4 source identity are frozen; registry scores cannot enter it (20.518701ms)
✔ the actual npm build hook refuses a score without a source before Next runs (433.210193ms)
✔ radar preserves zero, reverses lower-better, and withholds missing or uninformative ranges (1.200417ms)
✔ observation selection prefers measured and latest, never highest or vendor-derived claims (0.347873ms)
✔ peer distribution excludes unmatched identities, claims, low battle counts, and duplicate source identities (2.827326ms)
✔ profile flags require both relative strength and peer deviation and expose independently computable inputs (7.757683ms)
✔ tiny peer groups, narrow family coverage, and insufficient model profile never trigger flags (1.723148ms)
✔ explicit CoT settings, dataset splits, and harnesses create separate evaluation axes (0.350384ms)
✔ actual source adapter keeps all version identities, values and dated legacy inputs, without mutating data (1056.501407ms)
✔ Chutes sums paired token counts, excludes zero-token rows, preserves zero and scope (10.850184ms)
✔ Chutes rejects empty, malformed, duplicate, incomplete and impossible aggregates (1.05474ms)
✔ Chutes uses seven completed UTC days across month/year boundaries (4.687052ms)
✔ observed slots use per-source percentiles and clamp AA values (23.868607ms)
✔ all-missing and non-finite rows receive the neutral fallback (1.130829ms)
✔ unreliable DesignArena boards are omitted before model-mean imputation (0.564449ms)
✔ DesignArena boards are independent percentile slots instead of a variable average (0.763926ms)
✔ missing slots inherit the model's mean observed percentile (0.337914ms)
✔ the mean-imputed base stays exact while the symmetric projection fixes a coverage inversion (0.876544ms)
✔ the dominance guard also covers a model with exactly one reliable result (0.751726ms)
✔ long dominance-like catalogs cannot add recursive score margins (68.573828ms)
✔ an exact clone cannot move any existing score (4.147881ms)
✔ row order cannot affect composite scores (1.258596ms)
✔ improving an observed score never lowers the model's composite (1015.322139ms)
✔ scores remain bounded for extreme valid inputs (1.0574ms)
✔ every catalog row receives a finite bounded Composite (437.787157ms)
✔ DeepSeek V4 Pro's attached Frontend evidence and stronger shared AA scores keep it above Flash (419.17112ms)
✔ GLM-5.2 stays above sparse open contenders; fully-measured Kimi K3 may lead (473.89775ms)
✔ GPT-5.6 Sol's observed-percentile mean ranks above GLM-5.2 (289.154519ms)
✔ Fable 5's exact max evidence and family-scoped high evidence both stay above GLM-5.2 (412.883359ms)
✔ EU scope filters the route before deduplicating a provider (4.076942ms)
✔ EU policy equivalence admits a Global offer without relabeling technical residency (0.452871ms)
✔ real client projection keeps exactly the two approved Azure routes in Featured + Open + EU scope (336.557319ms)
✔ EU plus TEE requires both flags on the same offer (0.190676ms)
✔ provider exclusions are honored before price ranking (0.274555ms)
✔ non-US filtering composes with offer-level EU filtering (0.227496ms)
✔ scoped catalog listings retain active unpriced models without entering price ranks (0.293704ms)
✔ provider-level dedicated capability never turns a non-EU offer into an EU offer (0.225226ms)
✔ client projection includes exact effort tokens and shared endpoint observations (211.927586ms)
✔ adjusted is modelCost default and uses per-model OR ratio before global or AA proxy (0.919303ms)
✔ model I/O fallback selects global Chutes before benchmark proxy, rejects stale measurements (0.51084ms)
✔ cache rates require platform + exact SKU + exact endpoint + same provider, with no stale borrowing (0.432452ms)
✔ alternate route representative changes with actual adjusted price, retaining EU scope (0.281074ms)
✔ no efficiency copying across effort variants; raw mode ignores telemetry; scoped reference does not leak (0.272644ms)
✔ DB-backed requests opt out of prerender even on an in-process dataset cache hit (1.57035ms)
✔ DB load preserves additive dataset metadata and rejects old seeds without efficiency or benchmark results (22.989913ms)
✔ dataset has models, families and offers (6.889669ms)
✔ every published source snapshot is current for this refresh (0.284925ms)
✔ all brief-required model families are present (0.796305ms)
✔ product names are not mistaken for reasoning-effort variants (0.744925ms)
✔ moving aliases and safe provider prefixes do not split model families (0.737396ms)
✔ open-weights filter metadata excludes audited proprietary families (1.972142ms)
✔ OpenRouter aliases merge free tiers and exclude router/music pseudo-models (0.857323ms)
✔ featured set covers the requested families (0.399582ms)
✔ benchmarks never silently coerce null to 0 (2.972753ms)
✔ offers carry numeric per-1M pricing or are explicitly null (11.483632ms)
✔ every offer carries audited residency and provider-origin flags (7.207522ms)
✔ EU residency is specific to the model offer, not inherited from the provider (0.301994ms)
✔ only the two approved Azure Direct Global offers receive the EU policy equivalence (2.151079ms)
✔ global and EU routes from one provider are both retained (0.471001ms)
✔ mixed-region OpenRouter providers never inherit an EU flag from company metadata (1.786386ms)
✔ EU-capable gateway providers mark only their explicitly European OpenRouter routes (2.13317ms)
✔ context-price tiers and distinct managed routes survive dataset deduplication (1.681128ms)
✔ audited July provider prices survive the merged dataset (0.672508ms)
✔ privacy routing is not mislabeled as trusted execution (6.514166ms)
✔ current Copilot token catalog and legacy request table stay distinct (0.824024ms)
✔ confirmed non-US provider metadata reaches the provider directory (0.205116ms)
✔ Claude first-party snapshot contains every currently callable model (0.211836ms)
✔ Coding Agent snapshot is fresh and internally consistent (0.131587ms)
✔ Coding Agent source rows retain their exact effort variants (0.860903ms)
✔ freshly built dataset attaches Coding Agent scores only to exact variants (1.424853ms)
✔ GLM-5.2 keeps all qualified source evidence on the reasoning max row (0.430662ms)
✔ family-scoped Intelligence.ai evidence attaches once to deterministic Overview representatives (1.247327ms)
✔ DeepSeek V4 Pro DesignArena rows mirror the source and sit on the max representative only (0.672897ms)
✔ Intelligence.ai registry display names resolve opaque and revisioned leaderboard ids (1.136488ms)
✔ all Artificial Analysis rows and official weight flags survive exactly once (4.620372ms)
✔ audited upstream repository corrections preserve source provenance (0.303004ms)
✔ audited provider checkpoint aliases join their benchmark families (0.814575ms)
✔ canonical organizations are consistent across source aliases (0.369043ms)
✔ every COMPLETE Coding Agent harness result is retained and the summary is its median (0.520051ms)
✔ DesignArena board rows attach once and never clone across effort siblings (1.703958ms)
✔ every current OpenRouter text SKU remains represented after free-tier deduplication (5.359378ms)
✔ AA rows receive only their exact OpenRouter SKU or a repository-verified replacement for a stale alias (2.905705ms)
✔ all published providers have metadata and no generated normalization ghosts remain (0.771695ms)
✔ September frontier additions retain prices, exact efforts and conservative metadata (0.619578ms)
✔ four terms use USD/million units, and equivalent has explicit own-token denominator (3.589692ms)
✔ twice the output/task doubles workload cost, while per-million equivalent stays unchanged (2.242057ms)
✔ unknown statistics earn no caching discount and every missing dimension is flagged (0.287624ms)
✔ missing read price charges full input even with 100% cache hits (0.308924ms)
✔ missing write price substitutes input price if explicit write tokens exist (0.216026ms)
✔ partial list price fallback is explicit; entirely unknown never ranks as free (0.353293ms)
✔ free prices, zero prompt ratio, and real zero cache statistics are retained (0.243155ms)
✔ invalid rates, quantities and nonnumeric data fall back, never clamp or coerce silently (0.324284ms)
✔ all fixed blends calculate independently of task/cache data and preserve fallback and zero (1.302066ms)
✔ efficiency joins an exact workload SKU; sibling/ambiguous rows use labelled Chutes fallback (75.815891ms)
✔ stale workload observations fall back without changing retained source dates (80.181777ms)
✔ duplicate endpoint tags and mismatched provider identities never receive a cache rate (77.287482ms)
✔ built efficiency observations match dated raw identities, exact values and explicit coverage (318.852335ms)
✔ OpenRouter keeps exact endpoint tags despite identical provider labels, and sums workload tokens (9.246814ms)
✔ OpenRouter accepts explicit missing usage and reports incomplete/zero-output windows (0.621468ms)
✔ OpenRouter rejects malformed Flight, wrong identities, duplicate endpoints/days and invalid counts (3.397586ms)
✔ OpenRouter cache prices distinguish zero and missing, reject coercion and nonfinite values (1.681128ms)
✔ OpenRouter cache joins UUID to exact routing tag, never base provider slug; zero is observed (1.465853ms)
✔ OpenRouter cache rejects malformed rates, duplicate UUIDs and inconsistent provider maps (0.407572ms)
✔ OpenRouter weekly rankings preserve exact free SKU identity and source last-activity date (1.016161ms)
✔ Pareto frontier keeps cost/capability tradeoffs and removes dominated interiors (2.1161ms)
✔ Pareto frontier handles cost, score, and exact ties correctly (21.825445ms)
✔ Pareto frontier is deterministic, order independent, and supports empty/singleton filters (4.501255ms)
✔ Pareto helper agrees with the strict minimize-cost/maximize-score definition (4.495474ms)
✔ public source parsers preserve zero, reject malformed values and isolate protocols (96.858061ms)
✔ collapse picks the strongest measured GPT effort for the selected score (1.458812ms)
✔ collapse keeps DeepSeek Coding-Agent evidence instead of an unmeasured max row (0.297305ms)
✔ collapse prefers an explicit GLM max result over a generic default alias (0.217376ms)
✔ neutral Composite fallback cannot replace a measured family representative (0.295085ms)
✔ collapsed representative fallback is deterministic and prefers a measured Claude effort (0.266525ms)
✔ hide-deprecated hides whole families, not individual variants (1.289576ms)
✔ a fully deprecated family has no selectable model while hiding is active (0.237375ms)
✔ vision critic sends actual local pixels with hashed receipts, without weakening model or payload gates (15.80401ms)
✔ AA fallback requires exact version and matching organization (1.930964ms)
✔ explicit maximum-effort mapping cannot hide a weak or missing sibling (1.326024ms)
✔ missing or malformed prices never become free eligibility (0.337333ms)
✔ unscored transport smoke has a price ceiling and cannot select automatically (0.371763ms)
✔ critic excludes every producer family including aliases and explicit model pins (13.058202ms)
✔ worker CLI preserves output on provider failures and accepts a large embedded packet (2875.865898ms)
✔ transport smoke cannot accept arbitrary data work or a reference file (125.88205ms)
ℹ tests 146
ℹ suites 0
ℹ pass 146
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 7802.437622

EXACT EVIDENCE prerender.log
✔ bundled catalog / is rendered once at build time (3.467524ms)
✔ bundled catalog /about is rendered once at build time (0.179336ms)
✔ bundled catalog /charts is rendered once at build time (0.134658ms)
✔ bundled catalog /compare is rendered once at build time (0.139638ms)
✔ bundled catalog /eu is rendered once at build time (0.250495ms)
✔ bundled catalog /gateways is rendered once at build time (0.101988ms)
✔ bundled catalog /provider-explorer is rendered once at build time (0.108668ms)
✔ bundled catalog /providers is rendered once at build time (0.090658ms)
✔ bundled catalog /scatter is rendered once at build time (0.183617ms)
✔ bundled catalog /benchmarks is rendered once at build time (0.241116ms)
✔ bundled catalog /radar is rendered once at build time (0.314724ms)
ℹ tests 11
ℹ suites 0
ℹ pass 11
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 168.247775

EXACT EVIDENCE build-final.log

> model-market-comparison@1.0.0 prebuild
> node scripts/validate-benchmark-scores.mjs

Benchmark source/build guard: { observations: 13908, source_files: 43, self_reported_verified: 1003 }

> model-market-comparison@1.0.0 build
> next build

   ▲ Next.js 15.5.19

   Creating an optimized production build ...
 ✓ Compiled successfully in 8.4s
   Linting and checking validity of types ...
   Collecting page data ...
   Generating static pages (0/17) ...
   Generating static pages (4/17) 
   Generating static pages (8/17) 
   Generating static pages (12/17) 
 ✓ Generating static pages (17/17)
   Finalizing page optimization ...
   Collecting build traces ...

Route (app)                                 Size  First Load JS
┌ ○ /                                    6.75 kB         121 kB
├ ○ /_not-found                             1 kB         103 kB
├ ○ /about                                 150 B         102 kB
├ ƒ /api/benchmark-scores                  150 B         102 kB
├ ƒ /api/benchmark-view                    150 B         102 kB
├ ƒ /api/benchmarks                        150 B         102 kB
├ ƒ /api/dataset                           150 B         102 kB
├ ƒ /api/health                            150 B         102 kB
├ ƒ /api/meta                              150 B         102 kB
├ ƒ /api/models                            150 B         102 kB
├ ƒ /api/models/[id]                       150 B         102 kB
├ ƒ /api/price-comparison                  150 B         102 kB
├ ƒ /api/providers                         150 B         102 kB
├ ○ /benchmarks                          3.16 kB         112 kB
├ ○ /charts                              5.47 kB         217 kB
├ ○ /compare                             1.83 kB         116 kB
├ ○ /eu                                  1.62 kB         116 kB
├ ○ /gateways                            1.61 kB         104 kB
├ ○ /icon.svg                                0 B            0 B
├ ƒ /models/[id]                            4 kB         115 kB
├ ○ /provider-explorer                   4.13 kB         115 kB
├ ○ /providers                           6.54 kB         117 kB
├ ○ /radar                                 179 B         115 kB
└ ○ /scatter                             9.73 kB         225 kB
+ First Load JS shared by all             102 kB
  ├ chunks/255-69a4a78fac9becef.js         46 kB
  ├ chunks/4bd1b696-409494caf8c83275.js  54.2 kB
  └ other shared chunks (total)           2.1 kB


ƒ Middleware                             34.2 kB

○  (Static)   prerendered as static content
ƒ  (Dynamic)  server-rendered on demand


EXACT EVIDENCE rendered-final/browser-checks.json
{
  "base": "http://127.0.0.1:3316",
  "at": "2026-09-11T01:05:28.745Z",
  "environment": "Headless system Chrome on Sandy, local production HTTP unless URL overrides; no network/CPU throttling",
  "pages": [
    {
      "name": "compare-dark",
      "url": "http://127.0.0.1:3316/compare#main-content",
      "metrics": {
        "cls": 0.000001211208767361111,
        "lcp": 876,
        "fcp": 812,
        "documentWidth": 1440,
        "viewport": 1440,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast",
          "th-has-data-cells"
        ],
        "passes": 49
      }
    },
    {
      "name": "compare-light",
      "url": "http://127.0.0.1:3316/compare?model=gpt-5.6-sol%3A%3Ahigh&model=claude-sonnet-5%3A%3Ahigh&model=grok-4.6%3A%3Ahigh",
      "metrics": {
        "cls": 0.015608748010706018,
        "lcp": 876,
        "fcp": 812,
        "documentWidth": 1440,
        "viewport": 1440,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast",
          "th-has-data-cells"
        ],
        "passes": 49
      }
    },
    {
      "name": "radar-light",
      "url": "http://127.0.0.1:3316/radar",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 304,
        "fcp": 184,
        "documentWidth": 1440,
        "viewport": 1440,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast",
          "th-has-data-cells"
        ],
        "passes": 49
      }
    },
    {
      "name": "radar-mobile",
      "url": "http://127.0.0.1:3316/radar",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 304,
        "fcp": 184,
        "documentWidth": 390,
        "viewport": 390,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast",
          "th-has-data-cells"
        ],
        "passes": 50
      }
    },
    {
      "name": "radar-320",
      "url": "http://127.0.0.1:3316/radar",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 304,
        "fcp": 184,
        "documentWidth": 320,
        "viewport": 320,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast",
          "th-has-data-cells"
        ],
        "passes": 50
      }
    },
    {
      "name": "ranking-light",
      "url": "http://127.0.0.1:3316/benchmarks",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 168,
        "fcp": 168,
        "documentWidth": 1440,
        "viewport": 1440,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast"
        ],
        "passes": 46
      }
    },
    {
      "name": "ranking-mobile",
      "url": "http://127.0.0.1:3316/benchmarks?benchmark=aa-coding-agent-index%3A%3A1.5",
      "metrics": {
        "cls": 0.08061966540678048,
        "lcp": 168,
        "fcp": 168,
        "documentWidth": 390,
        "viewport": 390,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast"
        ],
        "passes": 47
      }
    },
    {
      "name": "model-sheet",
      "url": "http://127.0.0.1:3316/models/gpt-5.6-sol%3A%3Ahigh",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 892,
        "fcp": 892,
        "documentWidth": 1440,
        "viewport": 1440,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast"
        ],
        "passes": 44
      }
    },
    {
      "name": "overview-light",
      "url": "http://127.0.0.1:3316/",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 220,
        "fcp": 220,
        "documentWidth": 1440,
        "viewport": 1440,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast"
        ],
        "passes": 46
      }
    },
    {
      "name": "overview-mobile",
      "url": "http://127.0.0.1:3316/",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 220,
        "fcp": 220,
        "documentWidth": 390,
        "viewport": 390,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast"
        ],
        "passes": 47
      }
    },
    {
      "name": "overview-dark-mobile",
      "url": "http://127.0.0.1:3316/",
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 220,
        "fcp": 220,
        "documentWidth": 390,
        "viewport": 390,
        "reducedMotion": true
      },
      "axe": {
        "violations": [],
        "incomplete": [
          "color-contrast"
        ],
        "passes": 47
      }
    }
  ],
  "interactions": [
    "Tab reaches skip link; Enter focuses main content",
    "Native model selects add C/D to four series; focused Remove + Enter reduces to three",
    "Keyboard Space selects radar axes; eight-axis cap disables remaining choices",
    "Keyboard Enter opens a numeric source evidence disclosure",
    "Version selector exposes v1.5 separately; no-match search displays explicit empty state",
    "Model sheet anomaly Why opens through keyboard; input values and directed z are rendered",
    "Injected local HTTP503 shows retry; retry loads three models without stale or fabricated scores",
    "Legacy two-model price/provider comparison remains selectable"
  ],
  "screenshots": [
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/compare-dark.png",
      "sha256": "18f8979667dcf44b832caf36302c549b8eae10f830a1efdd7c795489bf334ac3",
      "bytes": 157697,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "dark"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/radar-dark.png",
      "sha256": "a3253fb8baab13994f0a88fe448828abae20fa4517731a0a0c6a234e2aef90d2",
      "bytes": 219907,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "dark"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/radar-four.png",
      "sha256": "473f1baffb89af3518a71a2cecb65513053a6cb1844e87c572770bdd32c7432e",
      "bytes": 276746,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "dark"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/compare-evidence.png",
      "sha256": "649890eef410c975a6b7925ab43e298a48d638914b773639169eb999b2e06114",
      "bytes": 168123,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "dark"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/radar-light.png",
      "sha256": "28dafc9f7d1ddc7d826451d8e31ddb72ae7ba2a975850b32ccc96cc6879c3439",
      "bytes": 280403,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/radar-mobile.png",
      "sha256": "f7e3da34320225131d7b3bb52f0adc491a2b4a751770f59919bc579be4c17d48",
      "bytes": 57473,
      "viewport": {
        "width": 390,
        "height": 844
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/radar-mobile-chart.png",
      "sha256": "68c4f9d7cc3f50063aeef3d253733454b29ddc0de03c743d1984cd5cb982f964",
      "bytes": 53728,
      "viewport": {
        "width": 390,
        "height": 844
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/ranking-light.png",
      "sha256": "0a07caa7968344adefb04750e2a47b63604903b6dcb50da866897ddfcdb02c3c",
      "bytes": 127379,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/ranking-v1-5.png",
      "sha256": "504139c2e55184ba514c3658ce08877cfbd86c2f749f5f537d1276d2470f6af6",
      "bytes": 98080,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/ranking-mobile.png",
      "sha256": "1d96c429b9adf86a9364a3c0f07682f8d40bde6c39d0712143e7c98bdcbce044",
      "bytes": 55879,
      "viewport": {
        "width": 390,
        "height": 844
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/model-sheet.png",
      "sha256": "cf4c440e045980e5f98953cb0b88406ed0fee01daedd180667eb2e7cff77b210",
      "bytes": 115556,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/anomaly-why.png",
      "sha256": "86d811c8d7f37cb0ae2ea06dcacee04babb1a9e05cd9b6fa7b4025ca19ea26aa",
      "bytes": 115945,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/self-reported-sheet.png",
      "sha256": "5e01892bf22b083a10ee01da1fa13b9c30a1e52e8c113f5b87a8a27e34020a5b",
      "bytes": 172131,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/overview-light.png",
      "sha256": "d501e57df69c610cf6f7f13d5c20c1c18c8db7458245c6c39878494ff50edcb7",
      "bytes": 168701,
      "viewport": {
        "width": 1440,
        "height": 1000
      },
      "theme": "light"
    },
    {
      "file": "ops/rebuild-2026-09/evidence/phase-06/rendered-final/overview-mobile.png",
      "sha256": "c82e19166166d72381bcc3fe3d7f85e09c5b1e01085293091936254ca68d8d2b",
      "bytes": 64668,
      "viewport": {
        "width": 390,
        "height": 844
      },
      "theme": "light"
    }
  ],
  "errors": [],
  "verdict": "pass"
}

EXACT EVIDENCE legacy-rendered-final/checks.json
{
  "at": "2026-09-11T01:06:16.559Z",
  "base": "http://127.0.0.1:3316",
  "environment": "Unthrottled system Chrome on local production build; each route navigation loads at desktop width, then same-document theme and viewport changes",
  "errors": [],
  "interactions": [
    "More disclosure Enter + Tab reaches a secondary navigation link and Enter navigates",
    "Provider directory selection by focus + Enter updates aria-pressed",
    "Scatter accessible table opens with Enter and exposes model links"
  ],
  "results": [
    {
      "route": "/charts",
      "width": 1440,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 764,
        "fcp": 764
      }
    },
    {
      "route": "/charts",
      "width": 390,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 764,
        "fcp": 764
      }
    },
    {
      "route": "/charts",
      "width": 1440,
      "theme": "dark",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 764,
        "fcp": 764
      }
    },
    {
      "route": "/scatter",
      "width": 1440,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 360,
        "fcp": 360
      }
    },
    {
      "route": "/scatter",
      "width": 390,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 360,
        "fcp": 360
      }
    },
    {
      "route": "/scatter",
      "width": 1440,
      "theme": "dark",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 360,
        "fcp": 360
      }
    },
    {
      "route": "/providers",
      "width": 1440,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 336,
        "fcp": 336
      }
    },
    {
      "route": "/providers",
      "width": 390,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 336,
        "fcp": 336
      }
    },
    {
      "route": "/providers",
      "width": 1440,
      "theme": "dark",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 336,
        "fcp": 336
      }
    },
    {
      "route": "/provider-explorer",
      "width": 1440,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 388,
        "fcp": 388
      }
    },
    {
      "route": "/provider-explorer",
      "width": 390,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 388,
        "fcp": 388
      }
    },
    {
      "route": "/provider-explorer",
      "width": 1440,
      "theme": "dark",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 388,
        "fcp": 388
      }
    },
    {
      "route": "/eu",
      "width": 1440,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 416,
        "fcp": 416
      }
    },
    {
      "route": "/eu",
      "width": 390,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 416,
        "fcp": 416
      }
    },
    {
      "route": "/eu",
      "width": 1440,
      "theme": "dark",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 416,
        "fcp": 416
      }
    },
    {
      "route": "/gateways",
      "width": 1440,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 200,
        "fcp": 200
      }
    },
    {
      "route": "/gateways",
      "width": 390,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 200,
        "fcp": 200
      }
    },
    {
      "route": "/gateways",
      "width": 1440,
      "theme": "dark",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 200,
        "fcp": 200
      }
    },
    {
      "route": "/about",
      "width": 1440,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 60,
        "fcp": 60
      }
    },
    {
      "route": "/about",
      "width": 390,
      "theme": "light",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 60,
        "fcp": 60
      }
    },
    {
      "route": "/about",
      "width": 1440,
      "theme": "dark",
      "overflow": 0,
      "violations": [],
      "incomplete": [
        "color-contrast"
      ],
      "metrics": {
        "cls": 0.0000012856565875771604,
        "lcp": 60,
        "fcp": 60
      }
    }
  ]
}
REMAINING TRACKED DIFF
diff --git a/lib/types.ts b/lib/types.ts
index 3cd3cb0..8a81637 100644
--- a/lib/types.ts
+++ b/lib/types.ts
@@ -235,7 +235,7 @@ export type ScoreKey =
 export const SCORE_LABELS: Record<ScoreKey, string> = {
   composite: "Composite (coverage-neutral, dominance-safe percentiles, 0–100)",
   aa_coding_index: "ArtificialAnalysis — Coding Index",
-  aa_coding_agent: "ArtificialAnalysis — Coding Agent Index (median harness)",
+  aa_coding_agent: "ArtificialAnalysis — Coding Agent Index v1.4 (median harness)",
   aa_intelligence_index: "ArtificialAnalysis — Intelligence Index",
   designarena_frontend: "DesignArena — Agentic Web Dev (Frontend) Elo",
   designarena_fullstack: "DesignArena — Agentic Web Dev (Full-Stack) Elo",
diff --git a/tailwind.config.ts b/tailwind.config.ts
index e777059..c11a85c 100644
--- a/tailwind.config.ts
+++ b/tailwind.config.ts
@@ -4,8 +4,8 @@ export default {
   theme: {
     extend: {
       colors: {
-        ink: "#0e1116", panel: "#161b22", line: "#272e3a",
-        accent: "#5b9dff", accent2: "#7ee0c0", warn: "#ffb454",
+        ink: "rgb(var(--ink) / <alpha-value>)", panel: "rgb(var(--panel) / <alpha-value>)", line: "rgb(var(--line) / <alpha-value>)",
+        accent: "rgb(var(--accent) / <alpha-value>)", accent2: "rgb(var(--accent2) / <alpha-value>)", warn: "rgb(var(--warn) / <alpha-value>)",
       },
       fontFamily: { mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"] },
     },
diff --git a/test/production/prerender.mjs b/test/production/prerender.mjs
index 42990b3..15dc64b 100644
--- a/test/production/prerender.mjs
+++ b/test/production/prerender.mjs
@@ -5,7 +5,7 @@ import test from 'node:test';
 // Run explicitly after npm run build (without DATABASE_URL). This tests the
 // production artifact, not a source-code spelling of the cache policy.
 const manifest = JSON.parse(readFileSync('.next/prerender-manifest.json', 'utf8'));
-for (const route of ['/', '/about', '/charts', '/compare', '/eu', '/gateways', '/provider-explorer', '/providers', '/scatter']) {
+for (const route of ['/', '/about', '/charts', '/compare', '/eu', '/gateways', '/provider-explorer', '/providers', '/scatter', '/benchmarks', '/radar']) {
   test(`bundled catalog ${route} is rendered once at build time`, () => {
     assert.ok(manifest.routes[route], `${route} must not repeat catalog SSR per request`);
     assert.equal(manifest.routes[route].initialRevalidateSeconds, false);
