import { cp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
const [wt, run, out] = process.argv.slice(2);
await rm(out, { recursive: true, force: true });
await mkdir(join(out, 'scripts'), { recursive: true }); await mkdir(join(out, 'data/raw'), { recursive: true });
await cp(join(wt, 'lib'), join(out, 'lib'), { recursive: true });
for (const f of ['fetch-live.mjs', 'fetch-aa-efficiency.mjs']) await cp(join(wt, 'scripts', f), join(out, 'scripts', f));
await cp('/opt/model-market-comparison/data/raw/openrouter.json', join(out, 'data/raw/openrouter.json'));
await cp(join(wt, 'data/raw/source-change-approvals.json'), join(out, 'data/raw/source-change-approvals.json'));
const hook = join(out, 'replay-fetch.mjs');
await writeFile(hook, `import { readFileSync } from 'node:fs';import { gunzipSync } from 'node:zlib';import { basename, join } from 'node:path';import { createHash } from 'node:crypto';
const run=${JSON.stringify(run)};const manifest=readFileSync(join(run,'sources/live-manifest.jsonl'),'utf8').trim().split('\\n').map(JSON.parse);
const q=new Map();for(const e of manifest.filter(e=>e.url.startsWith('https://openrouter.ai/api/v1/models'))){const l=q.get(e.url)||[];l.push(e);q.set(e.url,l);}
globalThis.fetch=async(url)=>{const l=q.get(String(url));if(!l?.length)throw new Error('OFFLINE REPLAY: unexpected request '+url);const e=l.shift(),raw=gunzipSync(readFileSync(join(run,'sources',basename(e.file))));
if(createHash('sha256').update(raw).digest('hex')!==e.sha256)throw new Error('hash mismatch');return new Response(raw,{status:e.status??200,headers:{'content-type':'application/json'}});};`);
const r = spawnSync(process.execPath, ['--import', hook, join(out, 'scripts/fetch-live.mjs'), 'or-prices'], { cwd: out, encoding: 'utf8', timeout: 60000,
  env: { PATH: process.env.PATH, BH_OR_WITHDRAWAL_RECHECK_MS: '0', BH_EVIDENCE_DIR: '' } });
await writeFile(join(out, 'collector.log'), r.stdout + r.stderr);
const snap = JSON.parse(await readFile(join(out, 'data/raw/openrouter.json'), 'utf8'));
console.log(JSON.stringify({ exit: r.status, collected_at: snap.collected_at, models: snap.count, withdrawn_endpoints_run: snap.withdrawal_run?.withdrawn_endpoints?.length, reviewed: snap.withdrawal_run?.reviewed_endpoint_withdrawals, withdrawals_total: snap.withdrawals?.endpoints?.length, stderr_tail: r.stderr.slice(-300) }));
