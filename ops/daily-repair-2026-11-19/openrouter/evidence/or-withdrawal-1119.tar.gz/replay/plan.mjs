import { readFileSync } from 'node:fs';
const wt = process.argv[2];
const { planOpenRouterWithdrawals, openRouterEndpointSetDigest } = await import(`${wt}/lib/live-source.mjs`);
const prev = JSON.parse(readFileSync(process.argv[3], 'utf8'));
const cand = JSON.parse(readFileSync(process.argv[4], 'utf8'));
const models = cand.models;
const plan = planOpenRouterWithdrawals({ previous: prev, models, endpointsById: new Map(Object.entries(cand.endpointsById)), date: '2026-11-19' });
const keys = plan.run.withdrawn_endpoints.map((e) => `${e.model_id} ${e.identity}`);
console.log(JSON.stringify({ digest: openRouterEndpointSetDigest(prev.models), error: plan.error, n: keys.length, models_withdrawn: plan.run.withdrawn_models.length, keys }));
